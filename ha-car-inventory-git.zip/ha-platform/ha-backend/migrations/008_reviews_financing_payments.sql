-- =====================================================================
-- Migration 008 — Reviews, Financing, Payments
-- =====================================================================

-- ---------------------------- REVIEWS ---------------------------------
CREATE TABLE reviews (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reviewer_id   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  -- review target: exactly one of seller_id / dealer_id / vehicle_id
  seller_id     UUID REFERENCES sellers(id) ON DELETE CASCADE,
  dealer_id     UUID REFERENCES dealers(id) ON DELETE CASCADE,
  vehicle_id    UUID REFERENCES vehicles(id) ON DELETE CASCADE,
  rating        SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title         VARCHAR(150),
  body          TEXT,
  status        review_status NOT NULL DEFAULT 'PENDING',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_review_single_target CHECK (
    (num_nonnulls(seller_id, dealer_id, vehicle_id) = 1)
  )
);
CREATE INDEX idx_reviews_seller ON reviews(seller_id) WHERE seller_id IS NOT NULL;
CREATE INDEX idx_reviews_dealer ON reviews(dealer_id) WHERE dealer_id IS NOT NULL;
CREATE INDEX idx_reviews_status ON reviews(status);
CREATE TRIGGER trg_reviews_updated_at BEFORE UPDATE ON reviews
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE review_responses (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id   UUID NOT NULL UNIQUE REFERENCES reviews(id) ON DELETE CASCADE,
  responder_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body        TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE review_reports (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id   UUID NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
  reported_by UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason      VARCHAR(100) NOT NULL,
  details     TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_review_reports_review ON review_reports(review_id);

CREATE TABLE review_moderation (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id   UUID NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
  moderator_id UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  action      moderation_action_type NOT NULL,
  reason      TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_review_moderation_review ON review_moderation(review_id);

-- --------------------------- FINANCING ---------------------------------
CREATE TABLE financing_requests (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id      UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  buyer_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  down_payment_amount BIGINT NOT NULL CHECK (down_payment_amount >= 0),
  loan_amount     BIGINT NOT NULL CHECK (loan_amount >= 0),
  currency        currency_code NOT NULL DEFAULT 'USD',
  term_months     SMALLINT NOT NULL CHECK (term_months > 0),
  annual_interest_rate_bps INT NOT NULL,  -- basis points (e.g. 1250 = 12.50%), integer not float
  status          VARCHAR(30) NOT NULL DEFAULT 'SUBMITTED',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_financing_requests_buyer ON financing_requests(buyer_id);
CREATE INDEX idx_financing_requests_vehicle ON financing_requests(vehicle_id);

CREATE TABLE financing_calculations (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  financing_request_id UUID NOT NULL REFERENCES financing_requests(id) ON DELETE CASCADE,
  monthly_payment_amount BIGINT NOT NULL,
  total_interest_amount  BIGINT NOT NULL,
  total_repayment_amount BIGINT NOT NULL,
  currency          currency_code NOT NULL,
  computed_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_financing_calc_request ON financing_calculations(financing_request_id);

-- --------------------------- PAYMENTS -----------------------------------
-- Never store raw card numbers. Card-holder data stays with the PSP
-- (Stripe/Adyen/etc.); we store only their tokenized customer/method IDs.
CREATE TABLE payment_customers (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  psp_provider      VARCHAR(30) NOT NULL,       -- 'stripe','adyen'...
  psp_customer_id   VARCHAR(100) NOT NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (psp_provider, psp_customer_id)
);

CREATE TABLE payment_methods (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_customer_id UUID NOT NULL REFERENCES payment_customers(id) ON DELETE CASCADE,
  psp_payment_method_id VARCHAR(100) NOT NULL,   -- tokenized reference only
  brand             VARCHAR(20),                 -- 'visa','mastercard' (display only)
  last4             CHAR(4),                     -- last 4 digits only, PCI-safe
  exp_month         SMALLINT,
  exp_year          SMALLINT,
  is_default        BOOLEAN NOT NULL DEFAULT false,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_payment_methods_customer ON payment_methods(payment_customer_id);

CREATE TABLE subscription_plans (
  id            SERIAL PRIMARY KEY,
  code          VARCHAR(50) NOT NULL UNIQUE,   -- 'DEALER_BASIC','DEALER_PRO','SELLER_FEATURED_LISTING'
  name          VARCHAR(100) NOT NULL,
  price_amount  BIGINT NOT NULL,
  currency      currency_code NOT NULL DEFAULT 'USD',
  billing_interval VARCHAR(20) NOT NULL,        -- 'monthly','yearly'
  is_active     BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE subscriptions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_id         INT NOT NULL REFERENCES subscription_plans(id) ON DELETE RESTRICT,
  status          subscription_status NOT NULL DEFAULT 'TRIALING',
  psp_subscription_id VARCHAR(100),
  current_period_start TIMESTAMPTZ NOT NULL,
  current_period_end   TIMESTAMPTZ NOT NULL,
  cancel_at_period_end BOOLEAN NOT NULL DEFAULT false,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_subscriptions_user ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);
CREATE TRIGGER trg_subscriptions_updated_at BEFORE UPDATE ON subscriptions
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE invoices (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subscription_id UUID REFERENCES subscriptions(id) ON DELETE SET NULL,
  status          invoice_status NOT NULL DEFAULT 'DRAFT',
  amount_due      BIGINT NOT NULL,
  amount_paid     BIGINT NOT NULL DEFAULT 0,
  currency        currency_code NOT NULL DEFAULT 'USD',
  due_date        DATE,
  issued_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  paid_at         TIMESTAMPTZ
);
CREATE INDEX idx_invoices_user ON invoices(user_id);

CREATE TABLE payments (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id      UUID REFERENCES invoices(id) ON DELETE SET NULL,
  payment_customer_id UUID NOT NULL REFERENCES payment_customers(id) ON DELETE RESTRICT,
  payment_method_id UUID REFERENCES payment_methods(id) ON DELETE SET NULL,
  amount          BIGINT NOT NULL,
  currency        currency_code NOT NULL,
  status          payment_status NOT NULL DEFAULT 'PENDING',
  psp_payment_intent_id VARCHAR(100),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_payments_customer ON payments(payment_customer_id);
CREATE INDEX idx_payments_status ON payments(status);
CREATE TRIGGER trg_payments_updated_at BEFORE UPDATE ON payments
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE payment_transactions (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id    UUID NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
  type          VARCHAR(30) NOT NULL,        -- 'AUTHORIZATION','CAPTURE','REFUND','CHARGEBACK'
  amount        BIGINT NOT NULL,
  currency      currency_code NOT NULL,
  psp_transaction_id VARCHAR(100),
  raw_response  JSONB,                       -- store PSP response for audit, never card data
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_payment_transactions_payment ON payment_transactions(payment_id);

CREATE TABLE refunds (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id    UUID NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
  amount        BIGINT NOT NULL,
  currency      currency_code NOT NULL,
  reason        TEXT,
  status        payment_status NOT NULL DEFAULT 'PENDING',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_refunds_payment ON refunds(payment_id);

-- Raw webhook events from the PSP, kept for replay/audit/debugging
CREATE TABLE payment_webhooks (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  psp_provider  VARCHAR(30) NOT NULL,
  event_type    VARCHAR(100) NOT NULL,
  psp_event_id  VARCHAR(150) NOT NULL,
  payload       JSONB NOT NULL,
  processed_at  TIMESTAMPTZ,
  received_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (psp_provider, psp_event_id)          -- idempotency guard
);
CREATE INDEX idx_payment_webhooks_unprocessed ON payment_webhooks(received_at) WHERE processed_at IS NULL;
