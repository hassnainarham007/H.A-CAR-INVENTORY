-- =====================================================================
-- Migration 006 — Vehicles (the heart of the marketplace)
-- =====================================================================

CREATE TABLE vehicles (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- ownership: exactly one of seller_id / dealer_id is set (enforced below)
  seller_id         UUID REFERENCES sellers(id) ON DELETE CASCADE,
  dealer_id         UUID REFERENCES dealers(id) ON DELETE CASCADE,

  vin               VARCHAR(17) UNIQUE,                 -- nullable: not all markets require VIN
  stock_number      VARCHAR(50),

  make_id           INT NOT NULL REFERENCES vehicle_makes(id) ON DELETE RESTRICT,
  model_id          INT NOT NULL REFERENCES vehicle_models(id) ON DELETE RESTRICT,
  trim_id           INT REFERENCES vehicle_trims(id) ON DELETE SET NULL,
  year              SMALLINT NOT NULL CHECK (year BETWEEN 1900 AND 2100),

  -- money: integer minor units + explicit currency, never float
  price_amount      BIGINT NOT NULL CHECK (price_amount >= 0),
  price_currency    currency_code NOT NULL DEFAULT 'USD',
  is_negotiable     BOOLEAN NOT NULL DEFAULT false,

  mileage           INT CHECK (mileage >= 0),
  mileage_unit      mileage_unit NOT NULL DEFAULT 'KM',

  condition_id      INT NOT NULL REFERENCES conditions(id) ON DELETE RESTRICT,
  body_type_id      INT NOT NULL REFERENCES body_types(id) ON DELETE RESTRICT,
  fuel_type_id      INT NOT NULL REFERENCES fuel_types(id) ON DELETE RESTRICT,
  transmission_id   INT NOT NULL REFERENCES transmissions(id) ON DELETE RESTRICT,
  drive_type_id     INT REFERENCES drive_types(id) ON DELETE SET NULL,

  engine            VARCHAR(100),
  engine_displacement_cc INT,
  horsepower        INT,
  torque_nm         INT,
  doors             SMALLINT,
  seats             SMALLINT,

  exterior_color_id INT REFERENCES colors(id) ON DELETE SET NULL,
  interior_color_id INT REFERENCES colors(id) ON DELETE SET NULL,

  fuel_economy_l_100km NUMERIC(5,2),

  description       TEXT,
  -- generated tsvector for full-text search (make/model kept in vehicles via join,
  -- so we index description + a denormalized search_text column kept in sync by app/trigger)
  search_text       TEXT,
  search_vector     TSVECTOR,

  location_id       BIGINT REFERENCES locations(id) ON DELETE SET NULL,

  status            vehicle_status NOT NULL DEFAULT 'DRAFT',
  verification_status verification_status NOT NULL DEFAULT 'UNVERIFIED',

  view_count        BIGINT NOT NULL DEFAULT 0,   -- denormalized cache, source of truth = vehicle_views

  published_at      TIMESTAMPTZ,
  sold_at           TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at        TIMESTAMPTZ,

  CONSTRAINT chk_vehicle_owner_exactly_one CHECK (
    (seller_id IS NOT NULL AND dealer_id IS NULL) OR
    (seller_id IS NULL AND dealer_id IS NOT NULL)
  )
);

-- ---- Core search / filter indexes ----
CREATE INDEX idx_vehicles_make        ON vehicles(make_id)       WHERE deleted_at IS NULL;
CREATE INDEX idx_vehicles_model       ON vehicles(model_id)      WHERE deleted_at IS NULL;
CREATE INDEX idx_vehicles_year        ON vehicles(year)          WHERE deleted_at IS NULL;
CREATE INDEX idx_vehicles_price       ON vehicles(price_amount)  WHERE deleted_at IS NULL;
CREATE INDEX idx_vehicles_mileage     ON vehicles(mileage)       WHERE deleted_at IS NULL;
CREATE INDEX idx_vehicles_location    ON vehicles(location_id)   WHERE deleted_at IS NULL;
CREATE INDEX idx_vehicles_body_type   ON vehicles(body_type_id)  WHERE deleted_at IS NULL;
CREATE INDEX idx_vehicles_fuel_type   ON vehicles(fuel_type_id)  WHERE deleted_at IS NULL;
CREATE INDEX idx_vehicles_transmission ON vehicles(transmission_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_vehicles_seller      ON vehicles(seller_id)     WHERE deleted_at IS NULL;
CREATE INDEX idx_vehicles_dealer      ON vehicles(dealer_id)     WHERE deleted_at IS NULL;
CREATE INDEX idx_vehicles_verification ON vehicles(verification_status);

-- Partial index: the "ACTIVE" listing browse/search path is by far the hottest query.
CREATE INDEX idx_vehicles_active_browse ON vehicles(status, published_at DESC)
  WHERE status = 'ACTIVE' AND deleted_at IS NULL;

-- Composite index for the classic "make+model+year range+price range" filter combo
CREATE INDEX idx_vehicles_make_model_year_price ON vehicles(make_id, model_id, year, price_amount)
  WHERE deleted_at IS NULL;

-- Full-text search (PostgreSQL FTS now; same search_vector column can later
-- be shipped to Elasticsearch/OpenSearch as a migration path, no schema change needed)
CREATE INDEX idx_vehicles_search_vector ON vehicles USING GIN (search_vector);
-- Trigram index for fuzzy partial matches (e.g. "corola" -> "Corolla")
CREATE INDEX idx_vehicles_description_trgm ON vehicles USING GIN (description gin_trgm_ops);

CREATE OR REPLACE FUNCTION vehicles_search_vector_update() RETURNS TRIGGER AS $$
BEGIN
  NEW.search_vector :=
    setweight(to_tsvector('english', coalesce(NEW.search_text,'')), 'A') ||
    setweight(to_tsvector('english', coalesce(NEW.description,'')), 'B');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_vehicles_search_vector
  BEFORE INSERT OR UPDATE OF search_text, description ON vehicles
  FOR EACH ROW EXECUTE FUNCTION vehicles_search_vector_update();

CREATE TRIGGER trg_vehicles_updated_at BEFORE UPDATE ON vehicles
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------
CREATE TABLE vehicle_images (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id  UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  url         TEXT NOT NULL,
  media_type  media_type NOT NULL DEFAULT 'EXTERIOR',
  sort_order  SMALLINT NOT NULL DEFAULT 0,
  is_primary  BOOLEAN NOT NULL DEFAULT false,
  width       INT,
  height      INT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_vehicle_images_vehicle ON vehicle_images(vehicle_id, sort_order);
CREATE UNIQUE INDEX uq_vehicle_primary_image ON vehicle_images(vehicle_id) WHERE is_primary;

CREATE TABLE vehicle_videos (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id  UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  url         TEXT NOT NULL,
  thumbnail_url TEXT,
  duration_seconds INT,
  sort_order  SMALLINT NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_vehicle_videos_vehicle ON vehicle_videos(vehicle_id);

-- Features are a many-to-many: a shared catalog (e.g. "Sunroof", "Leather Seats")
CREATE TABLE features (
  id       SERIAL PRIMARY KEY,
  name     VARCHAR(100) NOT NULL UNIQUE,
  category VARCHAR(50)                     -- 'Safety','Comfort','Technology'...
);

CREATE TABLE vehicle_features (
  vehicle_id  UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  feature_id  INT NOT NULL REFERENCES features(id) ON DELETE CASCADE,
  PRIMARY KEY (vehicle_id, feature_id)
);
CREATE INDEX idx_vehicle_features_feature ON vehicle_features(feature_id);

-- Flexible key/value specs that don't warrant their own column
-- (e.g. "Trunk Capacity", "Battery Range" for EVs, "Towing Capacity")
CREATE TABLE vehicle_specifications (
  id          BIGSERIAL PRIMARY KEY,
  vehicle_id  UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  spec_key    VARCHAR(100) NOT NULL,
  spec_value  VARCHAR(255) NOT NULL,
  UNIQUE (vehicle_id, spec_key)
);

-- Ownership / accident / service history events
CREATE TABLE vehicle_history (
  id          BIGSERIAL PRIMARY KEY,
  vehicle_id  UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  event_type  VARCHAR(50) NOT NULL,        -- 'OWNERSHIP_CHANGE','ACCIDENT','SERVICE','REGISTRATION'
  event_date  DATE,
  description TEXT,
  source      VARCHAR(100),                -- e.g. 'Dealer Report', 'Government Registry'
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_vehicle_history_vehicle ON vehicle_history(vehicle_id, event_date DESC);

CREATE TABLE vehicle_documents (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id  UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  document_type VARCHAR(50) NOT NULL,      -- 'REGISTRATION','TITLE','INSPECTION_REPORT'
  document_url  TEXT NOT NULL,
  uploaded_by   UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_vehicle_documents_vehicle ON vehicle_documents(vehicle_id);

CREATE TABLE vehicle_inspections (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id    UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  inspector_name VARCHAR(150),
  inspected_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  overall_score SMALLINT CHECK (overall_score BETWEEN 0 AND 100),
  report_url    TEXT,
  notes         TEXT
);
CREATE INDEX idx_vehicle_inspections_vehicle ON vehicle_inspections(vehicle_id);

-- Platform-level "verified listing" badge workflow (separate from inspections)
CREATE TABLE vehicle_verifications (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id    UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  status        verification_status NOT NULL DEFAULT 'PENDING',
  reviewed_by   UUID REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at   TIMESTAMPTZ,
  notes         TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_vehicle_verifications_vehicle ON vehicle_verifications(vehicle_id);
