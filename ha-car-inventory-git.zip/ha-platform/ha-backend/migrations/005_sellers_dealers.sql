-- =====================================================================
-- Migration 005 — Sellers & Dealers
-- =====================================================================

CREATE TABLE sellers (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  seller_type     seller_type NOT NULL DEFAULT 'PRIVATE',
  verification_status verification_status NOT NULL DEFAULT 'UNVERIFIED',
  rating_avg      NUMERIC(3,2) NOT NULL DEFAULT 0,   -- denormalized cache, recomputed from reviews
  rating_count    INT NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sellers_verification ON sellers(verification_status);
CREATE TRIGGER trg_sellers_updated_at BEFORE UPDATE ON sellers
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE seller_profiles (
  seller_id     UUID PRIMARY KEY REFERENCES sellers(id) ON DELETE CASCADE,
  display_name  VARCHAR(150),
  about         TEXT,
  location_id   BIGINT REFERENCES locations(id) ON DELETE SET NULL,
  response_time_minutes INT,   -- rolling average, computed async
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE seller_verifications (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id     UUID NOT NULL REFERENCES sellers(id) ON DELETE CASCADE,
  document_type VARCHAR(50) NOT NULL,        -- 'CNIC','PASSPORT','BUSINESS_LICENSE'...
  document_url  TEXT NOT NULL,               -- pointer to encrypted object storage, not raw PII in DB
  status        verification_status NOT NULL DEFAULT 'PENDING',
  reviewed_by   UUID REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at   TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_seller_verifications_seller ON seller_verifications(seller_id);

-- ---------------------------------------------------------------------
CREATE TABLE dealers (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id   UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  legal_name      VARCHAR(200) NOT NULL,
  registration_number VARCHAR(100),
  verification_status verification_status NOT NULL DEFAULT 'UNVERIFIED',
  rating_avg      NUMERIC(3,2) NOT NULL DEFAULT 0,
  rating_count    INT NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_dealers_verification ON dealers(verification_status);
CREATE TRIGGER trg_dealers_updated_at BEFORE UPDATE ON dealers
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE dealer_profiles (
  dealer_id     UUID PRIMARY KEY REFERENCES dealers(id) ON DELETE CASCADE,
  display_name  VARCHAR(150) NOT NULL,
  logo_url      TEXT,
  description   TEXT,
  website_url   TEXT,
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE dealer_employees (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dealer_id   UUID NOT NULL REFERENCES dealers(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role        dealer_employee_role NOT NULL DEFAULT 'SALES_AGENT',
  is_active   BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (dealer_id, user_id)
);
CREATE INDEX idx_dealer_employees_user ON dealer_employees(user_id);

CREATE TABLE dealer_locations (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dealer_id   UUID NOT NULL REFERENCES dealers(id) ON DELETE CASCADE,
  location_id BIGINT NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  is_primary  BOOLEAN NOT NULL DEFAULT false,
  phone       VARCHAR(20),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_dealer_locations_dealer ON dealer_locations(dealer_id);
-- only one primary branch per dealer
CREATE UNIQUE INDEX uq_dealer_primary_location ON dealer_locations(dealer_id) WHERE is_primary;

CREATE TABLE dealer_hours (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dealer_location_id UUID NOT NULL REFERENCES dealer_locations(id) ON DELETE CASCADE,
  day_of_week SMALLINT NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),  -- 0=Sunday
  open_time   TIME,
  close_time  TIME,
  is_closed   BOOLEAN NOT NULL DEFAULT false,
  UNIQUE (dealer_location_id, day_of_week)
);

CREATE TABLE dealer_documents (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dealer_id   UUID NOT NULL REFERENCES dealers(id) ON DELETE CASCADE,
  document_type VARCHAR(50) NOT NULL,
  document_url  TEXT NOT NULL,
  status        verification_status NOT NULL DEFAULT 'PENDING',
  uploaded_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_dealer_documents_dealer ON dealer_documents(dealer_id);
