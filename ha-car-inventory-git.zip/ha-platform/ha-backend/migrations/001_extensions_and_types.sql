-- =====================================================================
-- H.A CAR INVENTORY — Migration 001
-- Extensions, ENUM types, shared helper functions
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";      -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "citext";        -- case-insensitive emails
CREATE EXTENSION IF NOT EXISTS "pg_trgm";       -- fuzzy / partial text search
CREATE EXTENSION IF NOT EXISTS "btree_gist";    -- exclusion constraints (appointments)
CREATE EXTENSION IF NOT EXISTS "unaccent";      -- accent-insensitive search

-- ---------------------------------------------------------------------
-- Generic trigger: auto-maintain updated_at on every UPDATE
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- ENUM types
-- ---------------------------------------------------------------------
CREATE TYPE user_status AS ENUM ('ACTIVE','SUSPENDED','BANNED','DEACTIVATED','PENDING_VERIFICATION');
CREATE TYPE account_type AS ENUM ('BUYER','SELLER','DEALER','ADMIN','SUPPORT');

CREATE TYPE vehicle_status AS ENUM (
  'DRAFT','PENDING_REVIEW','ACTIVE','RESERVED','SOLD','ARCHIVED','REJECTED'
);
CREATE TYPE verification_status AS ENUM ('UNVERIFIED','PENDING','VERIFIED','REJECTED');
CREATE TYPE mileage_unit AS ENUM ('KM','MI');
CREATE TYPE currency_code AS ENUM ('USD','EUR','GBP','PKR','AED','SAR','CAD','AUD');

CREATE TYPE listing_condition AS ENUM ('NEW','USED','CERTIFIED_PRE_OWNED','SALVAGE');
CREATE TYPE media_type AS ENUM ('EXTERIOR','INTERIOR','ENGINE','DAMAGE','DOCUMENT','OTHER');

CREATE TYPE seller_type AS ENUM ('PRIVATE','DEALER');
CREATE TYPE dealer_employee_role AS ENUM ('OWNER','MANAGER','SALES_AGENT','SUPPORT');

CREATE TYPE inquiry_status AS ENUM ('OPEN','IN_PROGRESS','CLOSED','SPAM');
CREATE TYPE lead_status AS ENUM ('NEW','CONTACTED','QUALIFIED','WON','LOST');
CREATE TYPE appointment_status AS ENUM ('REQUESTED','CONFIRMED','COMPLETED','CANCELLED','NO_SHOW');

CREATE TYPE review_status AS ENUM ('PENDING','PUBLISHED','HIDDEN','REMOVED');

CREATE TYPE payment_status AS ENUM ('PENDING','SUCCEEDED','FAILED','REFUNDED','PARTIALLY_REFUNDED','CANCELLED');
CREATE TYPE subscription_status AS ENUM ('TRIALING','ACTIVE','PAST_DUE','CANCELLED','EXPIRED');
CREATE TYPE invoice_status AS ENUM ('DRAFT','OPEN','PAID','VOID','UNCOLLECTIBLE');

CREATE TYPE notification_channel AS ENUM ('IN_APP','EMAIL','SMS','PUSH');
CREATE TYPE moderation_action_type AS ENUM ('APPROVE','REJECT','HIDE','WARN','SUSPEND','BAN','DELETE');

-- Money is NEVER stored as floating point.
-- Convention: store the smallest currency unit (integer, e.g. cents / fils)
-- in a BIGINT column, paired with a currency_code column.
