-- =====================================================================
-- Migration 009 — AI, Content, Analytics, Admin
-- =====================================================================

-- ------------------------------- AI -------------------------------------
-- Privacy note: store only what's needed to power/debug the feature.
-- No raw payment data, no password data, ever, in these tables.
CREATE TABLE ai_conversations (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,   -- nullable: anonymous AI chat
  context     VARCHAR(50) NOT NULL DEFAULT 'GENERAL',         -- 'VEHICLE_QA','SEARCH_ASSIST','SUPPORT'
  vehicle_id  UUID REFERENCES vehicles(id) ON DELETE SET NULL,
  started_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  ended_at    TIMESTAMPTZ
);
CREATE INDEX idx_ai_conversations_user ON ai_conversations(user_id);

CREATE TABLE ai_messages (
  id              BIGSERIAL PRIMARY KEY,
  ai_conversation_id UUID NOT NULL REFERENCES ai_conversations(id) ON DELETE CASCADE,
  role            VARCHAR(20) NOT NULL,        -- 'user','assistant','tool'
  content         TEXT NOT NULL,
  token_count     INT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_ai_messages_conversation ON ai_messages(ai_conversation_id, created_at);

CREATE TABLE ai_searches (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  query_text  TEXT NOT NULL,
  parsed_filters JSONB,               -- structured output extracted by the AI from natural language
  result_count INT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_ai_searches_user ON ai_searches(user_id);

CREATE TABLE ai_recommendations (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  vehicle_id  UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  score       NUMERIC(5,4),
  reason      VARCHAR(255),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, vehicle_id)
);
CREATE INDEX idx_ai_recommendations_user ON ai_recommendations(user_id, score DESC);

-- Cost tracking for AI API usage. API keys/secrets are NEVER stored here
-- or anywhere in the DB — they live in a secrets manager (see docs).
CREATE TABLE ai_usage (
  id            BIGSERIAL PRIMARY KEY,
  user_id       UUID REFERENCES users(id) ON DELETE SET NULL,
  feature       VARCHAR(50) NOT NULL,        -- 'ai_search','ai_chat','description_generation'
  model         VARCHAR(50) NOT NULL,
  input_tokens  INT NOT NULL DEFAULT 0,
  output_tokens INT NOT NULL DEFAULT 0,
  cost_micros   BIGINT NOT NULL DEFAULT 0,   -- cost in millionths of a USD (integer, not float)
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_ai_usage_created ON ai_usage(created_at);
CREATE INDEX idx_ai_usage_feature ON ai_usage(feature, created_at);

-- ----------------------------- CONTENT / CMS -----------------------------
CREATE TABLE blog_categories (
  id     SERIAL PRIMARY KEY,
  name   VARCHAR(100) NOT NULL UNIQUE,
  slug   VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE blog_posts (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  category_id   INT REFERENCES blog_categories(id) ON DELETE SET NULL,
  title         VARCHAR(255) NOT NULL,
  slug          VARCHAR(255) NOT NULL UNIQUE,
  excerpt       TEXT,
  body          TEXT NOT NULL,
  cover_image_url TEXT,
  is_published  BOOLEAN NOT NULL DEFAULT false,
  published_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_blog_posts_published ON blog_posts(published_at DESC) WHERE is_published;
CREATE TRIGGER trg_blog_posts_updated_at BEFORE UPDATE ON blog_posts
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE blog_tags (
  id    SERIAL PRIMARY KEY,
  name  VARCHAR(50) NOT NULL UNIQUE,
  slug  VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE blog_post_tags (
  blog_post_id UUID NOT NULL REFERENCES blog_posts(id) ON DELETE CASCADE,
  blog_tag_id  INT NOT NULL REFERENCES blog_tags(id) ON DELETE CASCADE,
  PRIMARY KEY (blog_post_id, blog_tag_id)
);

CREATE TABLE pages (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug        VARCHAR(150) NOT NULL UNIQUE,   -- 'about-us','terms-of-service'
  title       VARCHAR(255) NOT NULL,
  body        TEXT NOT NULL,
  is_published BOOLEAN NOT NULL DEFAULT true,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE faqs (
  id          SERIAL PRIMARY KEY,
  category    VARCHAR(100),
  question    TEXT NOT NULL,
  answer      TEXT NOT NULL,
  sort_order  SMALLINT NOT NULL DEFAULT 0,
  is_published BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE seo_metadata (
  id            BIGSERIAL PRIMARY KEY,
  entity_type   VARCHAR(50) NOT NULL,   -- 'vehicle','blog_post','page'
  entity_id     UUID NOT NULL,
  meta_title    VARCHAR(255),
  meta_description VARCHAR(500),
  canonical_url TEXT,
  UNIQUE (entity_type, entity_id)
);

CREATE TABLE redirects (
  id          SERIAL PRIMARY KEY,
  from_path   VARCHAR(500) NOT NULL UNIQUE,
  to_path     VARCHAR(500) NOT NULL,
  status_code SMALLINT NOT NULL DEFAULT 301,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------ ANALYTICS --------------------------------
-- Generic append-only event stream. High volume -> candidate for monthly
-- partitioning (see docs/performance.md) once traffic justifies it.
CREATE TABLE analytics_events (
  id          BIGSERIAL PRIMARY KEY,
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  session_id  UUID,
  event_name  VARCHAR(100) NOT NULL,      -- 'page_view','listing_click','search_submitted'
  properties  JSONB,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_analytics_events_name_time ON analytics_events(event_name, occurred_at DESC);
CREATE INDEX idx_analytics_events_user ON analytics_events(user_id);
CREATE INDEX idx_analytics_events_properties ON analytics_events USING GIN (properties);

-- Daily rollups (populated by a scheduled job) keep dashboards fast
-- without scanning analytics_events / vehicle_views directly.
CREATE TABLE vehicle_analytics (
  vehicle_id  UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  date        DATE NOT NULL,
  views       INT NOT NULL DEFAULT 0,
  favorites   INT NOT NULL DEFAULT 0,
  inquiries   INT NOT NULL DEFAULT 0,
  PRIMARY KEY (vehicle_id, date)
);

CREATE TABLE search_analytics (
  id          BIGSERIAL PRIMARY KEY,
  query_text  TEXT,
  filters     JSONB,
  result_count INT,
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_search_analytics_created ON search_analytics(created_at);

CREATE TABLE seller_analytics (
  seller_id   UUID NOT NULL REFERENCES sellers(id) ON DELETE CASCADE,
  date        DATE NOT NULL,
  listings_active INT NOT NULL DEFAULT 0,
  views_total INT NOT NULL DEFAULT 0,
  leads_total INT NOT NULL DEFAULT 0,
  PRIMARY KEY (seller_id, date)
);

CREATE TABLE dealer_analytics (
  dealer_id   UUID NOT NULL REFERENCES dealers(id) ON DELETE CASCADE,
  date        DATE NOT NULL,
  listings_active INT NOT NULL DEFAULT 0,
  views_total INT NOT NULL DEFAULT 0,
  leads_total INT NOT NULL DEFAULT 0,
  vehicles_sold INT NOT NULL DEFAULT 0,
  PRIMARY KEY (dealer_id, date)
);

-- -------------------------------- ADMIN -----------------------------------
CREATE TABLE admin_actions (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id    UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  action      VARCHAR(100) NOT NULL,       -- 'USER_SUSPENDED','LISTING_APPROVED'...
  target_type VARCHAR(50) NOT NULL,
  target_id   UUID,
  notes       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_admin_actions_admin ON admin_actions(admin_id);
CREATE INDEX idx_admin_actions_target ON admin_actions(target_type, target_id);

-- Immutable, append-only audit trail for sensitive actions across the system.
CREATE TABLE audit_logs (
  id          BIGSERIAL PRIMARY KEY,
  actor_id    UUID REFERENCES users(id) ON DELETE SET NULL,
  action      VARCHAR(100) NOT NULL,
  entity_type VARCHAR(50) NOT NULL,
  entity_id   TEXT,
  before_state JSONB,
  after_state  JSONB,
  ip_address  INET,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_actor ON audit_logs(actor_id);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at);

CREATE TABLE reports (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reported_by UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_type VARCHAR(50) NOT NULL,        -- 'vehicle','user','review','message'
  target_id   UUID NOT NULL,
  reason      VARCHAR(100) NOT NULL,
  details     TEXT,
  status      VARCHAR(30) NOT NULL DEFAULT 'OPEN',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_reports_target ON reports(target_type, target_id);
CREATE INDEX idx_reports_status ON reports(status);

CREATE TABLE moderation_actions (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id   UUID REFERENCES reports(id) ON DELETE SET NULL,
  moderator_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action      moderation_action_type NOT NULL,
  target_type VARCHAR(50) NOT NULL,
  target_id   UUID NOT NULL,
  notes       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_moderation_actions_target ON moderation_actions(target_type, target_id);

CREATE TABLE system_settings (
  key         VARCHAR(100) PRIMARY KEY,
  value       JSONB NOT NULL,
  description TEXT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE feature_flags (
  key         VARCHAR(100) PRIMARY KEY,
  is_enabled  BOOLEAN NOT NULL DEFAULT false,
  rollout_percentage SMALLINT NOT NULL DEFAULT 0 CHECK (rollout_percentage BETWEEN 0 AND 100),
  description TEXT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
