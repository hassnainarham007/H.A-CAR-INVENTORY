-- =====================================================================
-- Seed Data — H.A Car Inventory
-- Safe to run once against a fresh dev/test database.
-- =====================================================================

-- ---- Lookup tables ----
INSERT INTO body_types (name) VALUES
  ('Sedan'),('SUV'),('Coupe'),('Hatchback'),('Pickup Truck'),
  ('Convertible'),('Van'),('Wagon'),('Sports Car');

INSERT INTO fuel_types (name) VALUES
  ('Petrol'),('Diesel'),('Electric'),('Hybrid'),('Plug-in Hybrid'),('CNG');

INSERT INTO transmissions (name) VALUES
  ('Automatic'),('Manual'),('CVT'),('DCT'),('Semi-Automatic');

INSERT INTO drive_types (name) VALUES ('FWD'),('RWD'),('AWD'),('4WD');

INSERT INTO conditions (name) VALUES ('New'),('Used'),('Certified Pre-Owned'),('Salvage');

INSERT INTO colors (name, hex_code) VALUES
  ('White','#FFFFFF'),('Black','#000000'),('Silver','#C0C0C0'),
  ('Red','#FF0000'),('Blue','#0047AB'),('Grey','#808080');

-- ---- Countries / States / Cities (minimal set) ----
INSERT INTO countries (name, iso2, iso3, dial_code, default_currency) VALUES
  ('Pakistan','PK','PAK','+92','PKR'),
  ('United States','US','USA','+1','USD'),
  ('United Arab Emirates','AE','ARE','+971','AED'),
  ('United Kingdom','GB','GBR','+44','GBP');

INSERT INTO states_regions (country_id, name, code)
  SELECT id, 'Punjab', 'PB' FROM countries WHERE iso2 = 'PK'
  UNION ALL
  SELECT id, 'California', 'CA' FROM countries WHERE iso2 = 'US'
  UNION ALL
  SELECT id, 'Dubai', 'DU' FROM countries WHERE iso2 = 'AE';

INSERT INTO cities (state_id, name, latitude, longitude)
  SELECT id, 'Phalia', 32.4408, 73.5764 FROM states_regions WHERE name = 'Punjab'
  UNION ALL
  SELECT id, 'Lahore', 31.5497, 74.3436 FROM states_regions WHERE name = 'Punjab'
  UNION ALL
  SELECT id, 'Los Angeles', 34.0522, -118.2437 FROM states_regions WHERE name = 'California'
  UNION ALL
  SELECT id, 'Dubai', 25.2048, 55.2708 FROM states_regions WHERE name = 'Dubai';

INSERT INTO locations (city_id, address_line, postal_code, latitude, longitude)
  SELECT id, 'Main Bazaar Road', '50040', latitude, longitude FROM cities WHERE name = 'Phalia';

-- ---- Vehicle makes ----
INSERT INTO vehicle_makes (name, slug, country_of_origin) VALUES
  ('Toyota','toyota','Japan'),('BMW','bmw','Germany'),('Mercedes-Benz','mercedes-benz','Germany'),
  ('Audi','audi','Germany'),('Porsche','porsche','Germany'),('Tesla','tesla','USA'),
  ('Ford','ford','USA'),('Honda','honda','Japan'),('Lexus','lexus','Japan'),
  ('Nissan','nissan','Japan'),('Hyundai','hyundai','South Korea'),('Kia','kia','South Korea'),
  ('Land Rover','land-rover','United Kingdom'),('Chevrolet','chevrolet','USA'),
  ('Volkswagen','volkswagen','Germany'),('Volvo','volvo','Sweden'),
  ('Ferrari','ferrari','Italy'),('Lamborghini','lamborghini','Italy'),('McLaren','mclaren','United Kingdom');

-- ---- Models (subset, illustrative) ----
INSERT INTO vehicle_models (make_id, name, slug)
  SELECT id, 'Corolla', 'corolla' FROM vehicle_makes WHERE slug = 'toyota'
  UNION ALL SELECT id, 'Land Cruiser', 'land-cruiser' FROM vehicle_makes WHERE slug = 'toyota'
  UNION ALL SELECT id, '3 Series', '3-series' FROM vehicle_makes WHERE slug = 'bmw'
  UNION ALL SELECT id, 'X5', 'x5' FROM vehicle_makes WHERE slug = 'bmw'
  UNION ALL SELECT id, 'C-Class', 'c-class' FROM vehicle_makes WHERE slug = 'mercedes-benz'
  UNION ALL SELECT id, 'Model 3', 'model-3' FROM vehicle_makes WHERE slug = 'tesla'
  UNION ALL SELECT id, 'Model Y', 'model-y' FROM vehicle_makes WHERE slug = 'tesla'
  UNION ALL SELECT id, 'F-150', 'f-150' FROM vehicle_makes WHERE slug = 'ford'
  UNION ALL SELECT id, 'Civic', 'civic' FROM vehicle_makes WHERE slug = 'honda'
  UNION ALL SELECT id, '911', '911' FROM vehicle_makes WHERE slug = 'porsche';

-- ---- Features catalog ----
INSERT INTO features (name, category) VALUES
  ('Sunroof','Comfort'),('Leather Seats','Comfort'),('Navigation System','Technology'),
  ('Backup Camera','Safety'),('Adaptive Cruise Control','Safety'),('Heated Seats','Comfort'),
  ('Apple CarPlay','Technology'),('Android Auto','Technology'),('Blind Spot Monitor','Safety');

-- ---- A demo seller (owner account) ----
INSERT INTO users (id, email, password_hash, status, account_type, email_verified_at)
VALUES (
  gen_random_uuid(), 'hassnainarham007@gmail.com',
  '$2b$12$replace_with_real_bcrypt_hash______________',   -- NEVER a real password here
  'ACTIVE', 'DEALER', now()
);

INSERT INTO user_profiles (user_id, first_name, last_name, display_name, country_id, city_id)
SELECT u.id, 'Hassnain', 'Arham', 'H.A Car Inventory',
       (SELECT id FROM countries WHERE iso2 = 'PK'),
       (SELECT id FROM cities WHERE name = 'Phalia')
FROM users u WHERE u.email = 'hassnainarham007@gmail.com';

INSERT INTO dealers (id, owner_user_id, legal_name, verification_status)
SELECT gen_random_uuid(), u.id, 'H.A Car Inventory', 'VERIFIED'
FROM users u WHERE u.email = 'hassnainarham007@gmail.com';

INSERT INTO dealer_profiles (dealer_id, display_name, description)
SELECT id, 'H.A Car Inventory', 'Global automotive marketplace based in Phalia, Punjab, Pakistan.'
FROM dealers WHERE legal_name = 'H.A Car Inventory';

INSERT INTO dealer_locations (dealer_id, location_id, is_primary, phone)
SELECT d.id, l.id, true, '+923000000000'
FROM dealers d, locations l
WHERE d.legal_name = 'H.A Car Inventory'
LIMIT 1;

-- ---- Sample vehicles across categories ----
INSERT INTO vehicles (
  dealer_id, make_id, model_id, year, price_amount, price_currency,
  mileage, mileage_unit, condition_id, body_type_id, fuel_type_id,
  transmission_id, drive_type_id, description, search_text,
  location_id, status, verification_status, published_at
)
SELECT
  d.id,
  m.id, mo.id, 2023, 4500000000, 'PKR',   -- 45,000,000 PKR stored in minor units (paisa)
  12000, 'KM',
  (SELECT id FROM conditions WHERE name = 'Used'),
  (SELECT id FROM body_types WHERE name = 'SUV'),
  (SELECT id FROM fuel_types WHERE name = 'Petrol'),
  (SELECT id FROM transmissions WHERE name = 'Automatic'),
  (SELECT id FROM drive_types WHERE name = 'AWD'),
  'Well-maintained Land Cruiser, single owner, full service history.',
  'Toyota Land Cruiser 2023 SUV Automatic AWD',
  l.id, 'ACTIVE', 'VERIFIED', now()
FROM dealers d
JOIN vehicle_makes m ON m.slug = 'toyota'
JOIN vehicle_models mo ON mo.slug = 'land-cruiser' AND mo.make_id = m.id
JOIN locations l ON true
WHERE d.legal_name = 'H.A Car Inventory'
LIMIT 1;

INSERT INTO vehicles (
  dealer_id, make_id, model_id, year, price_amount, price_currency,
  mileage, mileage_unit, condition_id, body_type_id, fuel_type_id,
  transmission_id, drive_type_id, description, search_text,
  location_id, status, verification_status, published_at
)
SELECT
  d.id, m.id, mo.id, 2024, 4400000, 'USD',   -- 44,000.00 USD in cents
  8000, 'MI',
  (SELECT id FROM conditions WHERE name = 'Used'),
  (SELECT id FROM body_types WHERE name = 'Sedan'),
  (SELECT id FROM fuel_types WHERE name = 'Electric'),
  (SELECT id FROM transmissions WHERE name = 'Automatic'),
  (SELECT id FROM drive_types WHERE name = 'RWD'),
  'Tesla Model 3, Autopilot included, low mileage, excellent condition.',
  'Tesla Model 3 2024 Sedan Electric Automatic',
  l.id, 'ACTIVE', 'VERIFIED', now()
FROM dealers d
JOIN vehicle_makes m ON m.slug = 'tesla'
JOIN vehicle_models mo ON mo.slug = 'model-3' AND mo.make_id = m.id
JOIN locations l ON true
WHERE d.legal_name = 'H.A Car Inventory'
LIMIT 1;

-- ---- Application roles (used by the backend's RBAC guard) ----
INSERT INTO roles (name, description, is_system) VALUES
  ('CUSTOMER', 'Buyer browsing and inquiring about vehicles', true),
  ('SELLER', 'Private individual selling their own vehicle(s)', true),
  ('DEALER', 'Dealership owner/account holder', true),
  ('DEALER_EMPLOYEE', 'Staff member acting on behalf of a dealer', true),
  ('ADMIN', 'Platform administrator', true),
  ('SUPER_ADMIN', 'Platform administrator with full system access', true)
ON CONFLICT (name) DO NOTHING;
