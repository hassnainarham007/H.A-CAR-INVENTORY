-- =====================================================================
-- Migration 002 — Users, Authentication, RBAC
-- =====================================================================

-- ---------------------------------------------------------------------
CREATE TABLE users (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email            CITEXT NOT NULL UNIQUE,
  phone            VARCHAR(20) UNIQUE,
  password_hash    TEXT NOT NULL,              -- bcrypt/argon2 hash ONLY, never plaintext
  status           user_status NOT NULL DEFAULT 'PENDING_VERIFICATION',
  account_type     account_type NOT NULL DEFAULT 'BUYER',
  email_verified_at TIMESTAMPTZ,
  phone_verified_at TIMESTAMPTZ,
  mfa_enabled      BOOLEAN NOT NULL DEFAULT false,
  mfa_secret_encrypted TEXT,                   -- encrypted at rest (app-layer), never plaintext
  last_login_at    TIMESTAMPTZ,
  last_login_ip    INET,
  failed_login_attempts SMALLINT NOT NULL DEFAULT 0,
  locked_until     TIMESTAMPTZ,
  deleted_at       TIMESTAMPTZ,                 -- soft delete
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_users_status ON users(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_account_type ON users(account_type) WHERE deleted_at IS NULL;
CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------
CREATE TABLE user_profiles (
  user_id          UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  first_name       VARCHAR(100),
  last_name        VARCHAR(100),
  display_name     VARCHAR(150),
  avatar_url       TEXT,
  bio              TEXT,
  date_of_birth    DATE,
  preferred_language VARCHAR(10) DEFAULT 'en',
  preferred_currency currency_code DEFAULT 'USD',
  country_id       INT,                         -- FK added after countries table exists (004)
  city_id          INT,
  timezone         VARCHAR(50) DEFAULT 'UTC',
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER trg_user_profiles_updated_at BEFORE UPDATE ON user_profiles
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------
-- RBAC: roles / permissions / user_roles
-- ---------------------------------------------------------------------
CREATE TABLE roles (
  id          SMALLSERIAL PRIMARY KEY,
  name        VARCHAR(50) NOT NULL UNIQUE,       -- e.g. 'admin', 'seller', 'dealer_manager'
  description TEXT,
  is_system   BOOLEAN NOT NULL DEFAULT false
);

CREATE TABLE permissions (
  id          SMALLSERIAL PRIMARY KEY,
  code        VARCHAR(100) NOT NULL UNIQUE,      -- e.g. 'vehicle.publish'
  description TEXT
);

CREATE TABLE role_permissions (
  role_id       SMALLINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id SMALLINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE user_roles (
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id     SMALLINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  granted_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  granted_by  UUID REFERENCES users(id) ON DELETE SET NULL,
  PRIMARY KEY (user_id, role_id)
);

-- ---------------------------------------------------------------------
-- Sessions / tokens — store only hashes of tokens, never raw secrets
-- ---------------------------------------------------------------------
CREATE TABLE sessions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_token_hash TEXT NOT NULL UNIQUE,
  ip_address      INET,
  user_agent      TEXT,
  expires_at      TIMESTAMPTZ NOT NULL,
  revoked_at      TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sessions_user ON sessions(user_id) WHERE revoked_at IS NULL;
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

CREATE TABLE refresh_tokens (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_id      UUID REFERENCES sessions(id) ON DELETE CASCADE,
  token_hash      TEXT NOT NULL UNIQUE,
  expires_at      TIMESTAMPTZ NOT NULL,
  revoked_at      TIMESTAMPTZ,
  replaced_by     UUID REFERENCES refresh_tokens(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id) WHERE revoked_at IS NULL;

CREATE TABLE email_verifications (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,
  expires_at  TIMESTAMPTZ NOT NULL,
  verified_at TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE password_resets (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,
  expires_at  TIMESTAMPTZ NOT NULL,
  used_at     TIMESTAMPTZ,
  ip_address  INET,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_password_resets_user ON password_resets(user_id) WHERE used_at IS NULL;
