-- =====================================================================
-- Migration 010 — Align `account_type` enum with the backend's RBAC roles
-- (CUSTOMER, SELLER, DEALER, DEALER_EMPLOYEE, ADMIN, SUPER_ADMIN)
-- Run this once, after 001-009 and before the backend connects.
-- =====================================================================

ALTER TYPE account_type RENAME VALUE 'BUYER' TO 'CUSTOMER';
ALTER TYPE account_type ADD VALUE IF NOT EXISTS 'DEALER_EMPLOYEE';
ALTER TYPE account_type ADD VALUE IF NOT EXISTS 'SUPER_ADMIN';
-- 'SUPPORT' is left in place for backward compatibility with any existing
-- rows; the application layer treats it as equivalent to 'ADMIN' with
-- reduced permissions rather than removing it (Postgres cannot drop a
-- single enum value without recreating the type).
