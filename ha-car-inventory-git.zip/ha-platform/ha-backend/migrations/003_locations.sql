-- =====================================================================
-- Migration 003 — Global Location Architecture
-- =====================================================================

CREATE TABLE countries (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(100) NOT NULL UNIQUE,
  iso2        CHAR(2) NOT NULL UNIQUE,
  iso3        CHAR(3) NOT NULL UNIQUE,
  dial_code   VARCHAR(10),
  default_currency currency_code,
  is_active   BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE states_regions (
  id          SERIAL PRIMARY KEY,
  country_id  INT NOT NULL REFERENCES countries(id) ON DELETE RESTRICT,
  name        VARCHAR(150) NOT NULL,
  code        VARCHAR(10),
  UNIQUE (country_id, name)
);
CREATE INDEX idx_states_country ON states_regions(country_id);

CREATE TABLE cities (
  id          SERIAL PRIMARY KEY,
  state_id    INT NOT NULL REFERENCES states_regions(id) ON DELETE RESTRICT,
  name        VARCHAR(150) NOT NULL,
  latitude    NUMERIC(9,6),
  longitude   NUMERIC(9,6),
  UNIQUE (state_id, name)
);
CREATE INDEX idx_cities_state ON cities(state_id);
CREATE INDEX idx_cities_latlng ON cities(latitude, longitude);

-- A reusable "location" for a listing, dealer branch, or user address:
-- lets us geo-query without duplicating city/state text everywhere.
CREATE TABLE locations (
  id           BIGSERIAL PRIMARY KEY,
  city_id      INT NOT NULL REFERENCES cities(id) ON DELETE RESTRICT,
  address_line VARCHAR(255),
  postal_code  VARCHAR(20),
  latitude     NUMERIC(9,6),
  longitude    NUMERIC(9,6),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_locations_city ON locations(city_id);
CREATE INDEX idx_locations_latlng ON locations(latitude, longitude);

-- Now that countries/cities exist, wire up user_profiles FKs.
ALTER TABLE user_profiles
  ADD CONSTRAINT fk_user_profiles_country FOREIGN KEY (country_id) REFERENCES countries(id) ON DELETE SET NULL,
  ADD CONSTRAINT fk_user_profiles_city    FOREIGN KEY (city_id)    REFERENCES cities(id)    ON DELETE SET NULL;
