-- =====================================================================
-- Migration 004 — Vehicle Taxonomy (lookup / reference tables)
-- Small, mostly-static tables -> normalized instead of free-text columns
-- so search/filtering stays index-friendly and typo-free.
-- =====================================================================

CREATE TABLE vehicle_makes (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(80) NOT NULL UNIQUE,
  slug        VARCHAR(80) NOT NULL UNIQUE,
  logo_url    TEXT,
  country_of_origin VARCHAR(80),
  is_active   BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE vehicle_models (
  id          SERIAL PRIMARY KEY,
  make_id     INT NOT NULL REFERENCES vehicle_makes(id) ON DELETE RESTRICT,
  name        VARCHAR(100) NOT NULL,
  slug        VARCHAR(100) NOT NULL,
  is_active   BOOLEAN NOT NULL DEFAULT true,
  UNIQUE (make_id, name),
  UNIQUE (make_id, slug)
);
CREATE INDEX idx_vehicle_models_make ON vehicle_models(make_id);

CREATE TABLE vehicle_trims (
  id          SERIAL PRIMARY KEY,
  model_id    INT NOT NULL REFERENCES vehicle_models(id) ON DELETE RESTRICT,
  name        VARCHAR(100) NOT NULL,
  UNIQUE (model_id, name)
);
CREATE INDEX idx_vehicle_trims_model ON vehicle_trims(model_id);

CREATE TABLE body_types (
  id    SERIAL PRIMARY KEY,
  name  VARCHAR(50) NOT NULL UNIQUE     -- Sedan, SUV, Coupe, Hatchback, Pickup Truck, Van, Convertible...
);

CREATE TABLE fuel_types (
  id    SERIAL PRIMARY KEY,
  name  VARCHAR(50) NOT NULL UNIQUE     -- Petrol, Diesel, Electric, Hybrid, Plug-in Hybrid, CNG, LPG
);

CREATE TABLE transmissions (
  id    SERIAL PRIMARY KEY,
  name  VARCHAR(50) NOT NULL UNIQUE     -- Automatic, Manual, CVT, DCT, Semi-Automatic
);

CREATE TABLE drive_types (
  id    SERIAL PRIMARY KEY,
  name  VARCHAR(20) NOT NULL UNIQUE     -- FWD, RWD, AWD, 4WD
);

CREATE TABLE conditions (
  id    SERIAL PRIMARY KEY,
  name  VARCHAR(30) NOT NULL UNIQUE     -- New, Used, Certified Pre-Owned, Salvage
);

CREATE TABLE colors (
  id       SERIAL PRIMARY KEY,
  name     VARCHAR(40) NOT NULL UNIQUE,
  hex_code CHAR(7)
);
