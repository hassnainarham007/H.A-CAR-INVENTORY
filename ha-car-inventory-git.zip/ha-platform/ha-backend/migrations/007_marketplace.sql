-- =====================================================================
-- Migration 007 — Marketplace Interactions
-- =====================================================================

CREATE TABLE favorites (
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  vehicle_id  UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, vehicle_id)
);
CREATE INDEX idx_favorites_vehicle ON favorites(vehicle_id);

CREATE TABLE saved_searches (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name        VARCHAR(150),
  filters     JSONB NOT NULL,             -- {"make_id":5,"price_max":30000,...}
  notify_on_match BOOLEAN NOT NULL DEFAULT false,
  last_run_at TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_saved_searches_user ON saved_searches(user_id);
CREATE INDEX idx_saved_searches_filters ON saved_searches USING GIN (filters);

-- High-volume, append-only: partition-friendly by month if traffic grows.
CREATE TABLE vehicle_views (
  id          BIGSERIAL PRIMARY KEY,
  vehicle_id  UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,   -- nullable: anonymous views
  session_id  UUID,
  ip_address  INET,
  referrer    TEXT,
  viewed_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_vehicle_views_vehicle_time ON vehicle_views(vehicle_id, viewed_at DESC);
CREATE INDEX idx_vehicle_views_user ON vehicle_views(user_id) WHERE user_id IS NOT NULL;

CREATE TABLE vehicle_comparisons (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
  vehicle_ids UUID[] NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_vehicle_comparisons_user ON vehicle_comparisons(user_id);

CREATE TABLE inquiries (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id  UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  buyer_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message     TEXT NOT NULL,
  status      inquiry_status NOT NULL DEFAULT 'OPEN',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_inquiries_vehicle ON inquiries(vehicle_id);
CREATE INDEX idx_inquiries_buyer ON inquiries(buyer_id);
CREATE TRIGGER trg_inquiries_updated_at BEFORE UPDATE ON inquiries
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- CRM-style leads for sellers/dealers, distinct from raw inquiries
CREATE TABLE leads (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id    UUID REFERENCES vehicles(id) ON DELETE SET NULL,
  seller_id     UUID REFERENCES sellers(id) ON DELETE CASCADE,
  dealer_id     UUID REFERENCES dealers(id) ON DELETE CASCADE,
  buyer_id      UUID REFERENCES users(id) ON DELETE SET NULL,
  source        VARCHAR(50),               -- 'INQUIRY','PHONE','WALK_IN','AI_CHAT'
  status        lead_status NOT NULL DEFAULT 'NEW',
  estimated_value_amount BIGINT,
  estimated_value_currency currency_code,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_lead_owner CHECK (seller_id IS NOT NULL OR dealer_id IS NOT NULL)
);
CREATE INDEX idx_leads_seller ON leads(seller_id);
CREATE INDEX idx_leads_dealer ON leads(dealer_id);
CREATE INDEX idx_leads_status ON leads(status);
CREATE TRIGGER trg_leads_updated_at BEFORE UPDATE ON leads
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE appointments (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id    UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  buyer_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  location_id   BIGINT REFERENCES locations(id) ON DELETE SET NULL,
  scheduled_at  TIMESTAMPTZ NOT NULL,
  status        appointment_status NOT NULL DEFAULT 'REQUESTED',
  notes         TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_appointments_vehicle_time ON appointments(vehicle_id, scheduled_at);
CREATE INDEX idx_appointments_buyer ON appointments(buyer_id);

CREATE TABLE test_drives (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id UUID NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
  license_verified BOOLEAN NOT NULL DEFAULT false,
  waiver_signed_at TIMESTAMPTZ,
  feedback      TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE conversations (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id    UUID REFERENCES vehicles(id) ON DELETE SET NULL,
  buyer_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  seller_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  last_message_at TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (vehicle_id, buyer_id, seller_user_id)
);
CREATE INDEX idx_conversations_buyer ON conversations(buyer_id, last_message_at DESC);
CREATE INDEX idx_conversations_seller ON conversations(seller_user_id, last_message_at DESC);

CREATE TABLE messages (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body            TEXT NOT NULL,
  read_at         TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_messages_conversation ON messages(conversation_id, created_at);

CREATE TABLE notifications (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel     notification_channel NOT NULL DEFAULT 'IN_APP',
  type        VARCHAR(50) NOT NULL,        -- 'NEW_MESSAGE','PRICE_DROP','INQUIRY_RECEIVED'...
  payload     JSONB,
  read_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_user_unread ON notifications(user_id, created_at DESC) WHERE read_at IS NULL;
