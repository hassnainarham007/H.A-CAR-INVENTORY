import { Global, Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

export const REDIS_CLIENT = 'REDIS_CLIENT';

// `ioredis` and `bullmq` were listed as dependencies and Redis was running
// in docker-compose, but nothing in the app ever connected to it — dead
// infrastructure found during the CTO audit. This module makes it real:
// a single shared client, injected wherever caching or queues need it.
@Global()
@Module({
  imports: [ConfigModule],
  providers: [
    {
      provide: REDIS_CLIENT,
      inject: [ConfigService],
      useFactory: (config: ConfigService) => new Redis(config.get<string>('redis.url')!, { lazyConnect: false }),
    },
  ],
  exports: [REDIS_CLIENT],
})
export class RedisModule {}
