import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import configuration from './config/configuration';
import { validateEnv } from './config/env.validation';
import { DatabaseModule } from './database/database.module';
import { RedisModule } from './redis/redis.module';
import { HealthModule } from './modules/health/health.module';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { VehiclesModule } from './modules/vehicles/vehicles.module';
import { FavoritesModule } from './modules/favorites/favorites.module';
import { SellersModule } from './modules/sellers/sellers.module';
import { DealersModule } from './modules/dealers/dealers.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, load: [configuration], validate: validateEnv }),
    ThrottlerModule.forRoot([{ ttl: 60_000, limit: 100 }]), // global default; overridden per-route where needed
    DatabaseModule,
    RedisModule,
    HealthModule,
    AuthModule,
    UsersModule,
    VehiclesModule,
    FavoritesModule,
    SellersModule,
    DealersModule,
    // Additional modules (sellers, dealers, search, messaging, payments,
    // AI, admin, ...) follow the exact same pattern as VehiclesModule —
    // see docs/BACKEND_README.md "Module map & how to add the rest".
  ],
  providers: [{ provide: APP_GUARD, useClass: ThrottlerGuard }],
})
export class AppModule {}
