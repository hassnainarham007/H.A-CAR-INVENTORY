import { Injectable } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { EMAIL_QUEUE } from './email.module';

export interface SendEmailJob {
  to: string;
  template: 'email-verification' | 'password-reset' | 'welcome';
  data: Record<string, string>;
}

@Injectable()
export class EmailQueueService {
  constructor(@InjectQueue(EMAIL_QUEUE) private readonly queue: Queue<SendEmailJob>) {}

  // AuthService.register previously had a bare comment — "TODO: enqueue an
  // email-verification job" — with no queue behind it at all. This makes
  // that real: registration now actually enqueues a job, backed by the
  // Redis-backed BullMQ queue that was a dead dependency before this audit.
  async enqueueSend(job: SendEmailJob): Promise<void> {
    await this.queue.add('send', job, {
      attempts: 3,
      backoff: { type: 'exponential', delay: 5000 },
      removeOnComplete: true,
      removeOnFail: 100, // keep last 100 failures for debugging, don't grow unbounded
    });
  }
}
