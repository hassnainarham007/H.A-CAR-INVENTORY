import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import type { Job } from 'bullmq';
import { EMAIL_QUEUE } from './email.module';
import type { SendEmailJob } from './email-queue.service';

// No real SMTP/email-provider credentials exist in this environment (no
// SMTP_* values were ever set to anything but placeholders in .env.example),
// so per the audit brief's own instruction — "mock services only where an
// external production credential is necessarily unavailable" — this logs
// what WOULD be sent instead of pretending to deliver mail. The queue,
// retry, and backoff behavior around it is real; only the final SMTP call
// is a stand-in. Swap the body of `process()` for a real provider call
// (nodemailer/SES/Postmark/etc.) once SMTP_* credentials are configured.
@Processor(EMAIL_QUEUE)
export class EmailProcessor extends WorkerHost {
  private readonly logger = new Logger('EmailProcessor');

  async process(job: Job<SendEmailJob>): Promise<void> {
    const { to, template, data } = job.data;
    this.logger.log(`[MOCK EMAIL — no SMTP credentials configured] Would send "${template}" to ${to}: ${JSON.stringify(data)}`);
  }
}
