import { SetMetadata } from '@nestjs/common';

export type AppRole = 'CUSTOMER' | 'SELLER' | 'DEALER' | 'DEALER_EMPLOYEE' | 'ADMIN' | 'SUPER_ADMIN';

export const ROLES_KEY = 'roles';
export const Roles = (...roles: AppRole[]) => SetMetadata(ROLES_KEY, roles);
