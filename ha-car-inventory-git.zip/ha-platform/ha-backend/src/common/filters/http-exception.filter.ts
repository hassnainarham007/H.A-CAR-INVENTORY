import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Request, Response } from 'express';

@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger('ExceptionFilter');

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    const isHttp = exception instanceof HttpException;
    const status = isHttp ? exception.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR;
    const body = isHttp ? exception.getResponse() : null;

    const code = isHttp ? exception.constructor.name ?? 'HTTP_ERROR' : 'INTERNAL_ERROR';
    const message =
      isHttp && typeof body === 'object' && body && 'message' in (body as any)
        ? (body as any).message
        : isHttp
          ? exception.message
          : 'An unexpected error occurred';
    const details = isHttp && typeof body === 'object' ? (body as any).details ?? undefined : undefined;

    if (!isHttp) {
      this.logger.error(
        `Unhandled exception on ${request.method} ${request.url}`,
        exception instanceof Error ? exception.stack : String(exception),
      );
    }

    response.status(status).json({
      success: false,
      error: { code, message, details },
    });
  }
}
