import { Test } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { ConflictException } from '@nestjs/common';
import { SellersService } from './sellers.service';
import { Seller } from '../../database/entities/seller.entity';
import { User } from '../../database/entities/user.entity';
import { AuthService } from '../auth/auth.service';

// In-memory fake repository, same pattern as auth.service.spec.ts.
function fakeRepo<T extends { id?: string }>(seed: any[] = []) {
  const rows: any[] = [...seed];
  return {
    findOne: jest.fn(async ({ where }: any) => rows.find((r) => Object.entries(where).every(([k, v]) => r[k] === v)) ?? null),
    findOneOrFail: jest.fn(async ({ where }: any) => {
      const row = rows.find((r) => Object.entries(where).every(([k, v]) => r[k] === v));
      if (!row) throw new Error('not found');
      return row;
    }),
    create: jest.fn((data: any) => ({ ...data })),
    save: jest.fn(async (data: any) => {
      const withId = { id: data.id ?? `id-${rows.length + 1}`, ...data };
      rows.push(withId);
      return withId;
    }),
    update: jest.fn(async (idOrWhere: any, patch: any) => {
      const id = typeof idOrWhere === 'string' ? idOrWhere : undefined;
      rows.forEach((r) => {
        if (id ? r.id === id : Object.entries(idOrWhere).every(([k, v]) => r[k] === v)) Object.assign(r, patch);
      });
    }),
    _rows: rows,
  };
}

describe('SellersService', () => {
  let service: SellersService;
  let usersRepo: ReturnType<typeof fakeRepo>;
  let sellersRepo: ReturnType<typeof fakeRepo>;

  beforeEach(async () => {
    usersRepo = fakeRepo([{ id: 'user-1', email: 'a@test.com', accountType: 'CUSTOMER' }]);
    sellersRepo = fakeRepo([]);

    const module = await Test.createTestingModule({
      providers: [
        SellersService,
        { provide: getRepositoryToken(Seller), useValue: sellersRepo },
        { provide: getRepositoryToken(User), useValue: usersRepo },
        { provide: AuthService, useValue: { reissueTokensForUserId: jest.fn().mockResolvedValue({ accessToken: 'new.jwt', refreshToken: 'refresh123', expiresIn: '15m' }) } },
      ],
    }).compile();

    service = module.get(SellersService);
  });

  // This is the exact bug found in the CTO audit: a fresh CUSTOMER account
  // had no way to ever pass VehiclesController's @Roles('SELLER', ...)
  // guard, because nothing ever changed accountType away from 'CUSTOMER'.
  it('upgrades a CUSTOMER to SELLER and creates a seller record', async () => {
    const result = await service.becomeSeller('user-1');
    expect(result.seller.userId).toBe('user-1');
    const user = usersRepo._rows.find((u: any) => u.id === 'user-1');
    expect(user.accountType).toBe('SELLER');
  });

  it('reissues tokens so the new role is reflected in the JWT immediately', async () => {
    const result = await service.becomeSeller('user-1');
    expect(result.tokens.accessToken).toBe('new.jwt');
  });

  it('does not downgrade an existing DEALER by routing them through becomeSeller', async () => {
    usersRepo._rows.push({ id: 'user-2', email: 'dealer@test.com', accountType: 'DEALER' });
    await service.becomeSeller('user-2');
    const user = usersRepo._rows.find((u: any) => u.id === 'user-2');
    expect(user.accountType).toBe('DEALER'); // unchanged
  });

  it('rejects becoming a seller twice', async () => {
    await service.becomeSeller('user-1');
    await expect(service.becomeSeller('user-1')).rejects.toThrow(ConflictException);
  });
});
