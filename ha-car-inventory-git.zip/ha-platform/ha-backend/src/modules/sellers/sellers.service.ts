import { ConflictException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Seller } from '../../database/entities/seller.entity';
import { User } from '../../database/entities/user.entity';
import { AuthService, TokenPair } from '../auth/auth.service';

@Injectable()
export class SellersService {
  constructor(
    @InjectRepository(Seller) private readonly sellers: Repository<Seller>,
    @InjectRepository(User) private readonly users: Repository<User>,
    private readonly authService: AuthService,
  ) {}

  // The ONLY path in the whole system from CUSTOMER -> being able to list a
  // vehicle. Without this, VehiclesController.create's @Roles('SELLER', ...)
  // guard rejects every user forever, since AuthService.register hardcodes
  // accountType: 'CUSTOMER' and nothing else ever changes it. This was a
  // showstopper bug — the entire "sell your car" flow was unreachable.
  async becomeSeller(userId: string): Promise<{ seller: Seller; tokens: TokenPair }> {
    const existing = await this.sellers.findOne({ where: { userId } });
    if (existing) {
      throw new ConflictException('You already have a seller account.');
    }

    const seller = await this.sellers.save(this.sellers.create({ userId, sellerType: 'PRIVATE' }));

    // Only upgrade accountType if the user is a plain CUSTOMER — never
    // downgrade an existing DEALER/ADMIN/etc by routing them through here.
    const user = await this.users.findOneOrFail({ where: { id: userId } });
    if (user.accountType === 'CUSTOMER') {
      await this.users.update(userId, { accountType: 'SELLER' });
    }

    // Reissue tokens so the JWT's accountType claim reflects the new role
    // immediately — otherwise the user would be stuck with a stale
    // 'CUSTOMER' token (up to 15 min, per JWT_ACCESS_EXPIRES_IN) and the
    // RolesGuard on POST /vehicles would keep rejecting them right after
    // "successfully" becoming a seller.
    const tokens = await this.authService.reissueTokensForUserId(userId);
    return { seller, tokens };
  }
}
