import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VehiclesService } from './vehicles.service';
import { VehiclesController } from './vehicles.controller';
import { Vehicle } from '../../database/entities/vehicle.entity';
import { Seller } from '../../database/entities/seller.entity';
import { Dealer } from '../../database/entities/dealer.entity';
import { VehicleMake, VehicleModel } from '../../database/entities/taxonomy.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Vehicle, Seller, Dealer, VehicleMake, VehicleModel])],
  providers: [VehiclesService],
  controllers: [VehiclesController],
  exports: [VehiclesService],
})
export class VehiclesModule {}
