import { IsBoolean, IsIn, IsInt, IsNumberString, IsOptional, IsString, Max, Min, MaxLength } from 'class-validator';

const CURRENCIES = ['USD', 'EUR', 'GBP', 'PKR', 'AED', 'SAR', 'CAD', 'AUD'];

export class CreateVehicleDto {
  // Ownership is derived server-side from the authenticated seller/dealer —
  // NEVER trust a sellerId/dealerId in the request body (see VehiclesService).

  @IsInt() makeId: number;
  @IsInt() modelId: number;
  @IsInt() @Min(1900) @Max(2100) year: number;

  // Sent/stored as an integer string in minor units (e.g. cents) — never a float.
  @IsNumberString() priceAmount: string;
  @IsIn(CURRENCIES) priceCurrency: string;

  @IsOptional() @IsBoolean() isNegotiable?: boolean;
  @IsOptional() @IsInt() @Min(0) mileage?: number;
  @IsOptional() @IsIn(['KM', 'MI']) mileageUnit?: string;

  @IsInt() conditionId: number;
  @IsInt() bodyTypeId: number;
  @IsInt() fuelTypeId: number;
  @IsInt() transmissionId: number;
  @IsOptional() @IsInt() driveTypeId?: number;

  @IsOptional() @IsString() @MaxLength(5000) description?: string;
  // locations.id is a BIGSERIAL, not a UUID — @IsUUID() here would
  // reject every valid location ID. IsNumberString matches the actual PK type.
  @IsOptional() @IsNumberString() locationId?: string;
}
