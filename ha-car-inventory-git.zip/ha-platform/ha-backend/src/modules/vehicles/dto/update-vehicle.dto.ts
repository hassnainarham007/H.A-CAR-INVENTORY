import { PartialType } from '@nestjs/swagger';
import { CreateVehicleDto } from './create-vehicle.dto';

// PATCH semantics: every field optional, ownership/status still can't be
// set directly by the client (status changes go through publish/archive).
export class UpdateVehicleDto extends PartialType(CreateVehicleDto) {}
