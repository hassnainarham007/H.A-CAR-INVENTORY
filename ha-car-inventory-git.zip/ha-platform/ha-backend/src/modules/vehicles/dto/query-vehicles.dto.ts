import { Type } from 'class-transformer';
import { IsIn, IsInt, IsNumberString, IsOptional, IsString, IsUUID, Max, Min } from 'class-validator';
import { PaginationQueryDto } from '../../../common/dto/pagination.dto';

export class QueryVehiclesDto extends PaginationQueryDto {
  @IsOptional() @IsString() q?: string;              // full-text keyword search

  @IsOptional() @Type(() => Number) @IsInt() makeId?: number;
  @IsOptional() @Type(() => Number) @IsInt() modelId?: number;
  @IsOptional() @Type(() => Number) @IsInt() bodyTypeId?: number;
  @IsOptional() @Type(() => Number) @IsInt() fuelTypeId?: number;
  @IsOptional() @Type(() => Number) @IsInt() transmissionId?: number;
  @IsOptional() @Type(() => Number) @IsInt() driveTypeId?: number;
  @IsOptional() @Type(() => Number) @IsInt() conditionId?: number;

  @IsOptional() @Type(() => Number) @IsInt() @Min(1900) yearMin?: number;
  @IsOptional() @Type(() => Number) @IsInt() @Max(2100) yearMax?: number;

  @IsOptional() @Type(() => Number) @IsInt() @Min(0) priceMin?: number;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) priceMax?: number;

  @IsOptional() @Type(() => Number) @IsInt() @Min(0) mileageMax?: number;

  @IsOptional() @IsNumberString() locationId?: string; // locations.id is BIGSERIAL, not UUID
  @IsOptional() @IsUUID() sellerId?: string;
  @IsOptional() @IsUUID() dealerId?: string;

  @IsOptional() @IsIn(['VERIFIED', 'UNVERIFIED', 'PENDING', 'REJECTED'])
  verificationStatus?: string;

  @IsOptional() @IsIn(['price', 'year', 'mileage', 'createdAt', 'publishedAt'])
  sortBy?: string = 'publishedAt';
}
