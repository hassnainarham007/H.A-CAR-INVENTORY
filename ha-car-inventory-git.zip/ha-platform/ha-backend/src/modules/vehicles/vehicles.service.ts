import { ForbiddenException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import type { Redis } from 'ioredis';
import { REDIS_CLIENT } from '../../redis/redis.module';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { Vehicle } from '../../database/entities/vehicle.entity';
import { Seller } from '../../database/entities/seller.entity';
import { Dealer } from '../../database/entities/dealer.entity';
import { VehicleMake, VehicleModel } from '../../database/entities/taxonomy.entity';
import { CreateVehicleDto } from './dto/create-vehicle.dto';
import { UpdateVehicleDto } from './dto/update-vehicle.dto';
import { QueryVehiclesDto } from './dto/query-vehicles.dto';
import { buildPaginationMeta } from '../../common/dto/pagination.dto';
import { AuthenticatedUser } from '../auth/strategies/jwt.strategy';

@Injectable()
export class VehiclesService {
  constructor(
    @InjectRepository(Vehicle) private readonly vehicles: Repository<Vehicle>,
    @InjectRepository(Seller) private readonly sellers: Repository<Seller>,
    @InjectRepository(Dealer) private readonly dealers: Repository<Dealer>,
    @InjectRepository(VehicleMake) private readonly makes: Repository<VehicleMake>,
    @InjectRepository(VehicleModel) private readonly models: Repository<VehicleModel>,
    @Inject(REDIS_CLIENT) private readonly redis: Redis,
  ) {}

  async create(actor: AuthenticatedUser, dto: CreateVehicleDto) {
    // Ownership is resolved from the authenticated user's own seller/dealer
    // record — never from client-supplied IDs. A DEALER_EMPLOYEE creates on
    // behalf of their dealer (see note below); a plain CUSTOMER cannot list.
    const seller = await this.sellers.findOne({ where: { userId: actor.id } });
    const dealer = await this.dealers.findOne({ where: { ownerUserId: actor.id } });

    if (!seller && !dealer) {
      throw new ForbiddenException(
        'Only registered sellers or dealers can create listings. Register as a seller first.',
      );
    }

    // Build real search text from the actual make/model names so the
    // search_vector trigger (migration 006) has something to index — this
    // was previously hardcoded to an empty string, silently breaking
    // full-text search for every newly created listing.
    const [make, model] = await Promise.all([
      this.makes.findOneOrFail({ where: { id: dto.makeId } }),
      this.models.findOneOrFail({ where: { id: dto.modelId } }),
    ]);
    const searchText = `${dto.year} ${make.name} ${model.name}`.trim();

    const vehicle = this.vehicles.create({
      ...dto,
      sellerId: seller?.id ?? null,
      dealerId: dealer?.id ?? null,
      status: 'DRAFT',
      verificationStatus: 'UNVERIFIED',
      searchText,
    } as Partial<Vehicle>);

    const saved = await this.vehicles.save(vehicle);
    // Reload with relations so the response actually matches the Vehicle
    // API contract (make/model/images/... as objects, not bare IDs) —
    // `save()` alone only returns what was assigned, not hydrated relations.
    // Uses loadWithRelations (not findOne) so creating a listing doesn't
    // count as a view of it.
    return this.loadWithRelations(saved.id);
  }

  async findAll(query: QueryVehiclesDto) {
    // Cache identical searches for 30s. This is the single highest-traffic
    // query on the whole platform (public browse/search) — a 30s cache
    // absorbs repeated identical requests (pagination re-fetches, multiple
    // users browsing the same default view) without ever serving stale
    // data for longer than a user would notice. Redis was provisioned but
    // completely unused before this audit.
    const cacheKey = `vehicles:search:${JSON.stringify(query)}`;
    const cached = await this.redis.get(cacheKey).catch(() => null);
    if (cached) return JSON.parse(cached);

    // Must load every relation VehicleCard.tsx actually reads (condition,
    // transmission, fuelType) — this endpoint previously only loaded
    // make/model/images, which means the /cars browse page (the single
    // highest-traffic page in the whole app) would throw "Cannot read
    // properties of undefined (reading 'name')" the instant it rendered a
    // single result. Found during audit by cross-checking this query
    // against every field the card component reads, not assumed fixed
    // just because the response envelope looked right.
    const qb = this.vehicles
      .createQueryBuilder('vehicle')
      .leftJoinAndSelect('vehicle.make', 'make')
      .leftJoinAndSelect('vehicle.model', 'model')
      .leftJoinAndSelect('vehicle.images', 'images')
      .leftJoinAndSelect('vehicle.condition', 'condition')
      .leftJoinAndSelect('vehicle.bodyType', 'bodyType')
      .leftJoinAndSelect('vehicle.fuelType', 'fuelType')
      .leftJoinAndSelect('vehicle.transmission', 'transmission')
      .leftJoinAndSelect('vehicle.driveType', 'driveType')
      .where('vehicle.deletedAt IS NULL');

    this.applyFilters(qb, query);

    const sortColumn = { price: 'vehicle.priceAmount', year: 'vehicle.year', mileage: 'vehicle.mileage', createdAt: 'vehicle.createdAt', publishedAt: 'vehicle.publishedAt' }[query.sortBy ?? 'publishedAt'];
    qb.orderBy(sortColumn, query.order.toUpperCase() as 'ASC' | 'DESC');

    const page = query.page ?? 1;
    const limit = query.limit ?? 20;
    qb.skip((page - 1) * limit).take(limit);

    const [items, totalItems] = await qb.getManyAndCount();
    const result = { data: items, meta: buildPaginationMeta(page, limit, totalItems) };

    this.redis.set(cacheKey, JSON.stringify(result), 'EX', 30).catch(() => {});
    return result;
  }

  async findOne(id: string) {
    const vehicle = await this.loadWithRelations(id);

    // Fire-and-forget view counter (matches the schema's `view_count` cache
    // column). Deliberately not awaited — a view increment should never
    // slow down or fail the page load. Atomic `.increment()` avoids the
    // lost-update race a read-modify-write would have under concurrent hits.
    // Only the PUBLIC lookup (a real page view) increments — create()/
    // update() reload the same way internally and must NOT count as a view.
    this.vehicles.increment({ id }, 'viewCount', 1).catch(() => {});

    return vehicle;
  }

  private async loadWithRelations(id: string): Promise<Vehicle> {
    const vehicle = await this.vehicles.findOne({
      where: { id },
      relations: ['make', 'model', 'images', 'condition', 'bodyType', 'fuelType', 'transmission', 'driveType'],
    });
    if (!vehicle || vehicle.deletedAt) throw new NotFoundException('Vehicle not found.');
    return vehicle;
  }

  // Powers the seller/dealer dashboard's "your inventory" view — unlike
  // findAll(), this deliberately returns every status (DRAFT, PENDING_REVIEW,
  // ACTIVE, ARCHIVED, ...) for the caller's own listings. Before this
  // existed, findAll()'s hardcoded `status = 'ACTIVE'` filter meant a
  // seller's own draft listings were invisible even to themselves.
  async findMine(actor: AuthenticatedUser) {
    const seller = await this.sellers.findOne({ where: { userId: actor.id } });
    const dealer = await this.dealers.findOne({ where: { ownerUserId: actor.id } });

    if (!seller && !dealer) return { data: [], meta: buildPaginationMeta(1, 20, 0) };

    // Same relation-completeness fix as findAll() above — the seller
    // dashboard renders these through the same VehicleCard component.
    const qb = this.vehicles
      .createQueryBuilder('vehicle')
      .leftJoinAndSelect('vehicle.make', 'make')
      .leftJoinAndSelect('vehicle.model', 'model')
      .leftJoinAndSelect('vehicle.images', 'images')
      .leftJoinAndSelect('vehicle.condition', 'condition')
      .leftJoinAndSelect('vehicle.bodyType', 'bodyType')
      .leftJoinAndSelect('vehicle.fuelType', 'fuelType')
      .leftJoinAndSelect('vehicle.transmission', 'transmission')
      .leftJoinAndSelect('vehicle.driveType', 'driveType')
      .where('vehicle.deletedAt IS NULL')
      .andWhere(seller ? 'vehicle.sellerId = :sellerId' : 'vehicle.dealerId = :dealerId', {
        sellerId: seller?.id,
        dealerId: dealer?.id,
      })
      .orderBy('vehicle.updatedAt', 'DESC');

    const items = await qb.getMany();
    return { data: items, meta: buildPaginationMeta(1, items.length || 1, items.length) };
  }

  async findSimilar(id: string, limit = 6) {
    const vehicle = await this.findOne(id);
    // Same relation-completeness class of bug as findAll/findMine — this
    // had NO relations loaded at all, so the "Similar Vehicles" section
    // shown on every single vehicle detail page would have crashed on
    // `vehicle.make.name` before a user ever saw a result.
    return this.vehicles
      .find({
        where: { makeId: vehicle.makeId, modelId: vehicle.modelId, status: 'ACTIVE' },
        relations: ['make', 'model', 'images', 'condition', 'bodyType', 'fuelType', 'transmission', 'driveType'],
        take: limit + 1, // +1 in case the source vehicle itself matches, filtered below
      })
      .then((rows) => rows.filter((v) => v.id !== id).slice(0, limit));
  }

  async update(actor: AuthenticatedUser, id: string, dto: UpdateVehicleDto) {
    const vehicle = await this.assertOwnership(actor, id);
    Object.assign(vehicle, dto);
    const saved = await this.vehicles.save(vehicle);
    return this.loadWithRelations(saved.id); // same relation-hydration reasoning as create(); not a view
  }

  async remove(actor: AuthenticatedUser, id: string) {
    const vehicle = await this.assertOwnership(actor, id);
    vehicle.deletedAt = new Date();
    await this.vehicles.save(vehicle);
    return { deleted: true };
  }

  async publish(actor: AuthenticatedUser, id: string) {
    const vehicle = await this.assertOwnership(actor, id);
    // Business rule: a listing must pass moderation before going live.
    // Direct DRAFT -> ACTIVE is allowed here for MVP simplicity; swap the
    // target status to 'PENDING_REVIEW' once admin moderation queue ships.
    vehicle.status = 'ACTIVE';
    vehicle.publishedAt = new Date();
    return this.vehicles.save(vehicle);
  }

  async archive(actor: AuthenticatedUser, id: string) {
    const vehicle = await this.assertOwnership(actor, id);
    vehicle.status = 'ARCHIVED';
    return this.vehicles.save(vehicle);
  }

  // ---- internal helpers ----

  private applyFilters(qb: SelectQueryBuilder<Vehicle>, query: QueryVehiclesDto) {
    if (query.q) {
      // Uses the search_vector GIN index from migration 006 (websearch_to_tsquery
      // handles natural phrasing like `"land cruiser" -diesel` correctly).
      qb.andWhere('vehicle.search_vector @@ websearch_to_tsquery(:q)', { q: query.q });
    }
    if (query.makeId) qb.andWhere('vehicle.makeId = :makeId', { makeId: query.makeId });
    if (query.modelId) qb.andWhere('vehicle.modelId = :modelId', { modelId: query.modelId });
    if (query.bodyTypeId) qb.andWhere('vehicle.bodyTypeId = :bodyTypeId', { bodyTypeId: query.bodyTypeId });
    if (query.fuelTypeId) qb.andWhere('vehicle.fuelTypeId = :fuelTypeId', { fuelTypeId: query.fuelTypeId });
    if (query.transmissionId) qb.andWhere('vehicle.transmissionId = :transmissionId', { transmissionId: query.transmissionId });
    if (query.driveTypeId) qb.andWhere('vehicle.driveTypeId = :driveTypeId', { driveTypeId: query.driveTypeId });
    if (query.conditionId) qb.andWhere('vehicle.conditionId = :conditionId', { conditionId: query.conditionId });
    if (query.yearMin) qb.andWhere('vehicle.year >= :yearMin', { yearMin: query.yearMin });
    if (query.yearMax) qb.andWhere('vehicle.year <= :yearMax', { yearMax: query.yearMax });
    if (query.priceMin) qb.andWhere('vehicle.priceAmount >= :priceMin', { priceMin: query.priceMin });
    if (query.priceMax) qb.andWhere('vehicle.priceAmount <= :priceMax', { priceMax: query.priceMax });
    if (query.mileageMax) qb.andWhere('vehicle.mileage <= :mileageMax', { mileageMax: query.mileageMax });
    if (query.locationId) qb.andWhere('vehicle.locationId = :locationId', { locationId: query.locationId });
    if (query.sellerId) qb.andWhere('vehicle.sellerId = :sellerId', { sellerId: query.sellerId });
    if (query.dealerId) qb.andWhere('vehicle.dealerId = :dealerId', { dealerId: query.dealerId });
    if (query.verificationStatus) qb.andWhere('vehicle.verificationStatus = :vs', { vs: query.verificationStatus });

    // Public listing browse only ever shows ACTIVE vehicles by default —
    // callers with an owner/admin context should pass an explicit status
    // filter in a future iteration; kept simple and safe here.
    qb.andWhere('vehicle.status = :status', { status: 'ACTIVE' });
  }

  private async assertOwnership(actor: AuthenticatedUser, vehicleId: string): Promise<Vehicle> {
    const vehicle = await this.vehicles.findOne({ where: { id: vehicleId } });
    if (!vehicle || vehicle.deletedAt) throw new NotFoundException('Vehicle not found.');

    if (actor.accountType === 'ADMIN' || actor.accountType === 'SUPER_ADMIN') return vehicle;

    const seller = await this.sellers.findOne({ where: { userId: actor.id } });
    const dealer = await this.dealers.findOne({ where: { ownerUserId: actor.id } });

    const isOwner =
      (vehicle.sellerId && seller && vehicle.sellerId === seller.id) ||
      (vehicle.dealerId && dealer && vehicle.dealerId === dealer.id);

    if (!isOwner) {
      throw new ForbiddenException('You do not have permission to modify this listing.');
    }
    return vehicle;
  }
}
