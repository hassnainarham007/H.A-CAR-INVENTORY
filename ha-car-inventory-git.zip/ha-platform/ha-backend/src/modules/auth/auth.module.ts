import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { JwtStrategy } from './strategies/jwt.strategy';
import { User } from '../../database/entities/user.entity';
import { UserProfile } from '../../database/entities/user-profile.entity';
import { RefreshToken } from '../../database/entities/refresh-token.entity';
import { EmailModule } from '../../queues/email/email.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([User, UserProfile, RefreshToken]),
    PassportModule,
    JwtModule.register({}), // secrets are supplied per-call in AuthService, not globally
    EmailModule,
  ],
  providers: [AuthService, JwtStrategy],
  controllers: [AuthController],
  exports: [AuthService],
})
export class AuthModule {}
