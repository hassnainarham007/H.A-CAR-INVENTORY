import { ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import { User } from '../../database/entities/user.entity';
import { UserProfile } from '../../database/entities/user-profile.entity';
import { RefreshToken } from '../../database/entities/refresh-token.entity';
import { EmailQueueService } from '../../queues/email/email-queue.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';

const BCRYPT_ROUNDS = 12;
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  expiresIn: string;
}

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User) private readonly users: Repository<User>,
    @InjectRepository(UserProfile) private readonly profiles: Repository<UserProfile>,
    @InjectRepository(RefreshToken) private readonly refreshTokens: Repository<RefreshToken>,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly emailQueue: EmailQueueService,
  ) {}

  async register(dto: RegisterDto): Promise<{ user: Partial<User> }> {
    const existing = await this.users.findOne({ where: { email: dto.email } });
    if (existing) {
      // Deliberately generic message — don't confirm/deny account
      // existence in a way that helps account enumeration attacks.
      throw new ConflictException('Unable to register with the provided details.');
    }

    const passwordHash = await bcrypt.hash(dto.password, BCRYPT_ROUNDS);
    const user = await this.users.save(
      this.users.create({ email: dto.email, passwordHash, status: 'PENDING_VERIFICATION', accountType: 'CUSTOMER' }),
    );
    await this.profiles.save(
      this.profiles.create({ userId: user.id, firstName: dto.firstName, lastName: dto.lastName }),
    );

    // Enqueues onto the Redis-backed BullMQ queue (src/queues/email) rather
    // than sending synchronously — registration shouldn't block on, or fail
    // because of, an email provider being slow or down.
    await this.emailQueue
      .enqueueSend({ to: user.email, template: 'email-verification', data: { userId: user.id } })
      .catch(() => {}); // never let a queue hiccup fail registration itself

    return { user: this.toSafeUser(user) };
  }

  async login(dto: LoginDto): Promise<{ user: Partial<User>; tokens: TokenPair }> {
    const user = await this.users.findOne({ where: { email: dto.email } });

    // Constant-shape response whether the email exists or not, to resist
    // enumeration — we still do a bcrypt.compare against a dummy hash so
    // response timing doesn't leak existence either.
    const passwordHash = user?.passwordHash ?? '$2b$12$invalidsaltinvalidsaltinvalidsaltinvalidsaltinvalidsal';
    const passwordMatches = await bcrypt.compare(dto.password, passwordHash);

    if (!user || !passwordMatches) {
      if (user) await this.registerFailedAttempt(user);
      throw new UnauthorizedException('Invalid email or password.');
    }

    if (user.lockedUntil && user.lockedUntil > new Date()) {
      throw new UnauthorizedException('Account temporarily locked due to repeated failed login attempts.');
    }
    if (user.status === 'SUSPENDED' || user.status === 'BANNED' || user.status === 'DEACTIVATED') {
      throw new UnauthorizedException('This account cannot sign in.');
    }

    if (user.failedLoginAttempts > 0) {
      await this.users.update(user.id, { failedLoginAttempts: 0, lockedUntil: null });
    }

    const tokens = await this.issueTokenPair(user);
    return { user: this.toSafeUser(user), tokens };
  }

  async refresh(rawRefreshToken: string): Promise<TokenPair> {
    const tokenHash = this.hashToken(rawRefreshToken);
    const stored = await this.refreshTokens.findOne({ where: { tokenHash }, relations: ['user'] });

    if (!stored || stored.revokedAt || stored.expiresAt < new Date()) {
      throw new UnauthorizedException('Invalid or expired refresh token.');
    }

    // Rotation: the old token is revoked the instant it's used. If a
    // revoked token is ever presented again, that's a strong signal of
    // token theft — a production system should alert/force-logout here.
    await this.refreshTokens.update(stored.id, { revokedAt: new Date() });

    const user = await this.users.findOneOrFail({ where: { id: stored.userId } });
    return this.issueTokenPair(user);
  }

  async logout(userId: string, rawRefreshToken: string): Promise<void> {
    const tokenHash = this.hashToken(rawRefreshToken);
    await this.refreshTokens.update({ userId, tokenHash }, { revokedAt: new Date() });
  }

  // ---- internal helpers ----

  // Public wrapper around token issuance for other modules that legitimately
  // change what's in the JWT payload (e.g. SellersService promoting a
  // CUSTOMER to SELLER) — the access token embeds accountType, so a role
  // change must reissue tokens or the old role sticks around for up to
  // JWT_ACCESS_EXPIRES_IN even after the DB row is updated.
  async reissueTokensForUserId(userId: string): Promise<TokenPair> {
    const user = await this.users.findOneOrFail({ where: { id: userId } });
    return this.issueTokenPair(user);
  }

  private async issueTokenPair(user: User): Promise<TokenPair> {
    const payload = { sub: user.id, email: user.email, accountType: user.accountType };
    const accessExpiresIn = this.config.get<string>('jwt.accessExpiresIn');
    const accessToken = await this.jwt.signAsync(payload, {
      secret: this.config.get<string>('jwt.accessSecret'),
      expiresIn: accessExpiresIn,
    });

    const rawRefreshToken = crypto.randomBytes(48).toString('hex');
    const refreshExpiresIn = this.config.get<string>('jwt.refreshExpiresIn')!;
    await this.refreshTokens.save(
      this.refreshTokens.create({
        userId: user.id,
        tokenHash: this.hashToken(rawRefreshToken),
        expiresAt: this.parseExpiryToDate(refreshExpiresIn),
      }),
    );

    return { accessToken, refreshToken: rawRefreshToken, expiresIn: accessExpiresIn! };
  }

  private async registerFailedAttempt(user: User): Promise<void> {
    const attempts = user.failedLoginAttempts + 1;
    const lockedUntil =
      attempts >= MAX_FAILED_ATTEMPTS ? new Date(Date.now() + LOCKOUT_MINUTES * 60_000) : user.lockedUntil;
    await this.users.update(user.id, { failedLoginAttempts: attempts, lockedUntil });
  }

  private hashToken(raw: string): string {
    return crypto.createHash('sha256').update(raw).digest('hex');
  }

  private parseExpiryToDate(expr: string): Date {
    const match = /^(\d+)([smhd])$/.exec(expr);
    if (!match) return new Date(Date.now() + 30 * 24 * 60 * 60_000); // default 30d
    const value = parseInt(match[1], 10);
    const unitMs = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 }[match[2]]!;
    return new Date(Date.now() + value * unitMs);
  }

  private toSafeUser(user: User): Partial<User> {
    // Never return passwordHash to the client, ever.
    const { passwordHash: _omit, ...safe } = user;
    return safe;
  }
}
