import { Test } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { ConflictException, UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { AuthService } from './auth.service';
import { User } from '../../database/entities/user.entity';
import { UserProfile } from '../../database/entities/user-profile.entity';
import { RefreshToken } from '../../database/entities/refresh-token.entity';

// A minimal in-memory fake instead of a full mocking library — enough to
// exercise the real branching logic in AuthService without a live DB.
function fakeRepo<T extends { id?: string }>(seed: Partial<T>[] = []) {
  const rows: any[] = [...seed];
  return {
    findOne: jest.fn(async ({ where }: any) => rows.find((r) => Object.entries(where).every(([k, v]) => r[k] === v)) ?? null),
    create: jest.fn((data: any) => ({ ...data })),
    save: jest.fn(async (data: any) => {
      const withId = { id: data.id ?? `id-${rows.length + 1}`, ...data };
      rows.push(withId);
      return withId;
    }),
    update: jest.fn(async (idOrWhere: any, patch: any) => {
      const id = typeof idOrWhere === 'string' ? idOrWhere : undefined;
      rows.forEach((r) => {
        if (id ? r.id === id : Object.entries(idOrWhere).every(([k, v]) => r[k] === v)) Object.assign(r, patch);
      });
    }),
    findOneOrFail: jest.fn(async ({ where }: any) => rows.find((r) => Object.entries(where).every(([k, v]) => r[k] === v))),
    _rows: rows,
  };
}

describe('AuthService', () => {
  let service: AuthService;
  let usersRepo: ReturnType<typeof fakeRepo<User>>;

  beforeEach(async () => {
    usersRepo = fakeRepo<User>([]);
    const profilesRepo = fakeRepo<UserProfile>([]);
    const refreshRepo = fakeRepo<RefreshToken>([]);

    const module = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: getRepositoryToken(User), useValue: usersRepo },
        { provide: getRepositoryToken(UserProfile), useValue: profilesRepo },
        { provide: getRepositoryToken(RefreshToken), useValue: refreshRepo },
        { provide: JwtService, useValue: { signAsync: jest.fn().mockResolvedValue('signed.jwt.token') } },
        {
          provide: ConfigService,
          useValue: {
            get: (key: string) =>
              ({
                'jwt.accessSecret': 'test-secret',
                'jwt.accessExpiresIn': '15m',
                'jwt.refreshSecret': 'test-refresh-secret',
                'jwt.refreshExpiresIn': '30d',
              })[key],
          },
        },
      ],
    }).compile();

    service = module.get(AuthService);
  });

  it('registers a new user with a hashed password (never plaintext)', async () => {
    const result = await service.register({ email: 'buyer@example.com', password: 'Passw0rd!' } as any);
    expect(result.user).not.toHaveProperty('passwordHash');
    const stored = usersRepo._rows.find((r) => r.email === 'buyer@example.com');
    expect(stored.passwordHash).not.toEqual('Passw0rd!');
    expect(await bcrypt.compare('Passw0rd!', stored.passwordHash)).toBe(true);
  });

  it('rejects registering the same email twice', async () => {
    await service.register({ email: 'dup@example.com', password: 'Passw0rd!' } as any);
    await expect(service.register({ email: 'dup@example.com', password: 'Passw0rd!' } as any)).rejects.toThrow(
      ConflictException,
    );
  });

  it('rejects login with a wrong password without revealing which field was wrong', async () => {
    await service.register({ email: 'user@example.com', password: 'Passw0rd!' } as any);
    await expect(service.login({ email: 'user@example.com', password: 'WrongPass1' } as any)).rejects.toThrow(
      UnauthorizedException,
    );
  });

  it('logs in successfully and issues an access + refresh token pair', async () => {
    await service.register({ email: 'ok@example.com', password: 'Passw0rd!' } as any);
    const result = await service.login({ email: 'ok@example.com', password: 'Passw0rd!' } as any);
    expect(result.tokens.accessToken).toEqual('signed.jwt.token');
    expect(typeof result.tokens.refreshToken).toBe('string');
    expect(result.tokens.refreshToken.length).toBeGreaterThan(20);
  });

  it('locks the account after 5 failed attempts', async () => {
    await service.register({ email: 'lockout@example.com', password: 'Passw0rd!' } as any);
    for (let i = 0; i < 5; i++) {
      await expect(service.login({ email: 'lockout@example.com', password: 'wrong' } as any)).rejects.toThrow();
    }
    const stored = usersRepo._rows.find((r) => r.email === 'lockout@example.com');
    expect(stored.lockedUntil).toBeInstanceOf(Date);
  });
});
