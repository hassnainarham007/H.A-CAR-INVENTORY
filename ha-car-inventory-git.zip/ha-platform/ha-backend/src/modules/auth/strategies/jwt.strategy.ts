import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
import { ExtractJwt, Strategy } from 'passport-jwt';

export interface JwtPayload {
  sub: string;        // user id
  email: string;
  accountType: string;
}

export interface AuthenticatedUser {
  id: string;
  email: string;
  accountType: string;
}

// Validates the ACCESS token only. Refresh tokens are never accepted here —
// they're verified separately in AuthService against their own secret and
// their hash in the `refresh_tokens` table, so a leaked access token can
// never be replayed as a refresh token.
@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
  constructor(config: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: config.get<string>('jwt.accessSecret')!,
    });
  }

  async validate(payload: JwtPayload): Promise<AuthenticatedUser> {
    // Kept intentionally minimal (no DB hit) so every authenticated request
    // doesn't pay a round trip. If you need "is this user still active/
    // banned right now" enforcement, add a short-TTL Redis cache check here.
    return { id: payload.sub, email: payload.email, accountType: payload.accountType };
  }
}
