import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Favorite } from '../../database/entities/favorite.entity';

@Injectable()
export class FavoritesService {
  constructor(@InjectRepository(Favorite) private readonly favorites: Repository<Favorite>) {}

  async add(userId: string, vehicleId: string) {
    await this.favorites.upsert({ userId, vehicleId }, ['userId', 'vehicleId']);
    return { favorited: true };
  }

  async remove(userId: string, vehicleId: string) {
    await this.favorites.delete({ userId, vehicleId });
    return { favorited: false };
  }

  async listForUser(userId: string) {
    return this.favorites.find({ where: { userId }, relations: ['vehicle'] });
  }
}
