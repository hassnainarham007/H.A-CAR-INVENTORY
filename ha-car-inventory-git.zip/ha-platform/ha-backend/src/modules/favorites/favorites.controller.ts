import { Controller, Delete, Get, Param, ParseUUIDPipe, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { FavoritesService } from './favorites.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AuthenticatedUser } from '../auth/strategies/jwt.strategy';

@ApiTags('favorites')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('favorites')
export class FavoritesController {
  constructor(private readonly favorites: FavoritesService) {}

  @Get()
  list(@CurrentUser() user: AuthenticatedUser) {
    return this.favorites.listForUser(user.id);
  }

  @Post(':vehicleId')
  add(@CurrentUser() user: AuthenticatedUser, @Param('vehicleId', ParseUUIDPipe) vehicleId: string) {
    return this.favorites.add(user.id, vehicleId);
  }

  @Delete(':vehicleId')
  remove(@CurrentUser() user: AuthenticatedUser, @Param('vehicleId', ParseUUIDPipe) vehicleId: string) {
    return this.favorites.remove(user.id, vehicleId);
  }
}
