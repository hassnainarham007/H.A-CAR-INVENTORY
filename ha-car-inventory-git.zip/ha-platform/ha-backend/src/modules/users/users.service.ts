import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../../database/entities/user.entity';
import { UserProfile } from '../../database/entities/user-profile.entity';
import { UpdateProfileDto } from './dto/update-profile.dto';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User) private readonly users: Repository<User>,
    @InjectRepository(UserProfile) private readonly profiles: Repository<UserProfile>,
  ) {}

  async findMe(userId: string) {
    const user = await this.users.findOne({ where: { id: userId }, relations: ['profile'] });
    if (!user) throw new NotFoundException('User not found.');
    const { passwordHash: _omit, ...safe } = user;
    return safe;
  }

  async updateProfile(userId: string, dto: UpdateProfileDto) {
    await this.profiles.update({ userId }, dto);
    return this.findMe(userId);
  }

  // Soft delete only — preserves referential integrity for historical
  // listings/reviews/messages, per the schema's `deleted_at` design.
  async deactivate(userId: string) {
    await this.users.update(userId, { status: 'DEACTIVATED', deletedAt: new Date() });
    return { deactivated: true };
  }
}
