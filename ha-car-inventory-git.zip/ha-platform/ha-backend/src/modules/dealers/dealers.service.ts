import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Dealer } from '../../database/entities/dealer.entity';
import { Vehicle } from '../../database/entities/vehicle.entity';

@Injectable()
export class DealersService {
  constructor(
    @InjectRepository(Dealer) private readonly dealers: Repository<Dealer>,
    @InjectRepository(Vehicle) private readonly vehicles: Repository<Vehicle>,
  ) {}

  // Public directory — only ever surfaces VERIFIED dealers. An unverified
  // dealer record existing in the DB (mid-onboarding, rejected, etc.)
  // should never appear on a public marketplace page.
  async findAll() {
    const dealers = await this.dealers.find({ where: { verificationStatus: 'VERIFIED' }, order: { ratingAvg: 'DESC' } });
    return Promise.all(dealers.map((d) => this.withActiveListingCount(d)));
  }

  async findOne(id: string) {
    const dealer = await this.dealers.findOne({ where: { id, verificationStatus: 'VERIFIED' } });
    if (!dealer) throw new NotFoundException('Dealer not found.');

    const vehicles = await this.vehicles.find({
      where: { dealerId: id, status: 'ACTIVE' },
      // Must match every relation VehicleCard actually reads (condition,
      // transmission, fuelType, plus make/model/images) — loading a subset
      // would render fine until a component accessed the missing relation
      // and threw "Cannot read properties of undefined" at runtime. Caught
      // during audit, before it shipped, by cross-checking VehicleCard.tsx
      // against this exact query.
      relations: ['make', 'model', 'images', 'condition', 'bodyType', 'fuelType', 'transmission', 'driveType'],
      order: { publishedAt: 'DESC' },
    });

    return { ...(await this.withActiveListingCount(dealer)), vehicles };
  }

  private async withActiveListingCount(dealer: Dealer) {
    const activeListingCount = await this.vehicles.count({ where: { dealerId: dealer.id, status: 'ACTIVE' } });
    return { ...dealer, activeListingCount };
  }
}
