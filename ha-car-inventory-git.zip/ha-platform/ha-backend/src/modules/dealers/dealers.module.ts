import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DealersService } from './dealers.service';
import { DealersController } from './dealers.controller';
import { Dealer } from '../../database/entities/dealer.entity';
import { Vehicle } from '../../database/entities/vehicle.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Dealer, Vehicle])],
  providers: [DealersService],
  controllers: [DealersController],
})
export class DealersModule {}
