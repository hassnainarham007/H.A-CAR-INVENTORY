import { Controller, Get, Param, ParseUUIDPipe } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { DealersService } from './dealers.service';

@ApiTags('dealers')
@Controller('dealers')
export class DealersController {
  constructor(private readonly dealers: DealersService) {}

  @Get()
  findAll() {
    return this.dealers.findAll();
  }

  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.dealers.findOne(id);
  }
}
