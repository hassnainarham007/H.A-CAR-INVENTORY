import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './entities/user.entity';
import { UserProfile } from './entities/user-profile.entity';
import { RefreshToken } from './entities/refresh-token.entity';
import { Seller } from './entities/seller.entity';
import { Dealer } from './entities/dealer.entity';
import { Vehicle } from './entities/vehicle.entity';
import { VehicleImage } from './entities/vehicle-image.entity';
import { Favorite } from './entities/favorite.entity';
import { VehicleMake, VehicleModel, BodyType, FuelType, Transmission, DriveType, VehicleCondition } from './entities/taxonomy.entity';

const entities = [
  User,
  UserProfile,
  RefreshToken,
  Seller,
  Dealer,
  Vehicle,
  VehicleImage,
  Favorite,
  VehicleMake,
  VehicleModel,
  BodyType,
  FuelType,
  Transmission,
  DriveType,
  VehicleCondition,
];

@Module({
  imports: [
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres',
        url: config.get<string>('database.url'),
        ssl: config.get<boolean>('database.ssl') ? { rejectUnauthorized: false } : false,
        entities,
        // synchronize is ALWAYS false: the schema is owned by the SQL
        // migration files (001-010), never by TypeORM auto-sync. Auto-sync
        // in production is how you silently drop columns.
        synchronize: false,
        logging: config.get('env') === 'development' ? ['error', 'warn'] : ['error'],
      }),
    }),
    TypeOrmModule.forFeature(entities),
  ],
  exports: [TypeOrmModule],
})
export class DatabaseModule {}
