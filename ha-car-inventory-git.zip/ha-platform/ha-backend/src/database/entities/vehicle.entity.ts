import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Seller } from './seller.entity';
import { Dealer } from './dealer.entity';
import { VehicleMake, VehicleModel, BodyType, FuelType, Transmission, DriveType, VehicleCondition } from './taxonomy.entity';
import { VehicleImage } from './vehicle-image.entity';

export type VehicleStatus = 'DRAFT' | 'PENDING_REVIEW' | 'ACTIVE' | 'RESERVED' | 'SOLD' | 'ARCHIVED' | 'REJECTED';
export type VerificationStatus = 'UNVERIFIED' | 'PENDING' | 'VERIFIED' | 'REJECTED';
export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'PKR' | 'AED' | 'SAR' | 'CAD' | 'AUD';

// Maps onto `vehicles` (migration 006). Money stays BIGINT minor-units in
// the DB and as a string/number here — the app layer must never do
// floating-point arithmetic on price_amount (see schema docs).
@Entity('vehicles')
export class Vehicle {
  @PrimaryGeneratedColumn('uuid') id: string;

  @ManyToOne(() => Seller, { nullable: true })
  @JoinColumn({ name: 'seller_id' })
  seller: Seller | null;

  @Column({ name: 'seller_id', type: 'uuid', nullable: true })
  sellerId: string | null;

  @ManyToOne(() => Dealer, { nullable: true })
  @JoinColumn({ name: 'dealer_id' })
  dealer: Dealer | null;

  @Column({ name: 'dealer_id', type: 'uuid', nullable: true })
  dealerId: string | null;

  @Column({ type: 'varchar', length: 17, nullable: true }) vin: string | null;
  @Column({ name: 'stock_number', nullable: true }) stockNumber: string | null;

  @ManyToOne(() => VehicleMake) @JoinColumn({ name: 'make_id' }) make: VehicleMake;
  @Column({ name: 'make_id' }) makeId: number;

  @ManyToOne(() => VehicleModel) @JoinColumn({ name: 'model_id' }) model: VehicleModel;
  @Column({ name: 'model_id' }) modelId: number;

  @Column() year: number;

  @Index()
  @Column({ name: 'price_amount', type: 'bigint' })
  priceAmount: string;

  @Column({ name: 'price_currency', type: 'enum', enum: ['USD', 'EUR', 'GBP', 'PKR', 'AED', 'SAR', 'CAD', 'AUD'], enumName: 'currency_code', default: 'USD' })
  priceCurrency: CurrencyCode;

  @Column({ name: 'is_negotiable', default: false })
  isNegotiable: boolean;

  @Index()
  @Column({ type: 'int', nullable: true })
  mileage: number | null;

  @Column({ name: 'mileage_unit', type: 'enum', enum: ['KM', 'MI'], enumName: 'mileage_unit', default: 'KM' })
  mileageUnit: 'KM' | 'MI';

  @ManyToOne(() => VehicleCondition) @JoinColumn({ name: 'condition_id' }) condition: VehicleCondition;
  @Column({ name: 'condition_id' }) conditionId: number;

  @ManyToOne(() => BodyType) @JoinColumn({ name: 'body_type_id' }) bodyType: BodyType;
  @Column({ name: 'body_type_id' }) bodyTypeId: number;

  @ManyToOne(() => FuelType) @JoinColumn({ name: 'fuel_type_id' }) fuelType: FuelType;
  @Column({ name: 'fuel_type_id' }) fuelTypeId: number;

  @ManyToOne(() => Transmission) @JoinColumn({ name: 'transmission_id' }) transmission: Transmission;
  @Column({ name: 'transmission_id' }) transmissionId: number;

  @ManyToOne(() => DriveType, { nullable: true }) @JoinColumn({ name: 'drive_type_id' }) driveType: DriveType | null;
  @Column({ name: 'drive_type_id', nullable: true }) driveTypeId: number | null;

  @Column({ type: 'text', nullable: true }) description: string | null;
  @Column({ name: 'search_text', type: 'text', nullable: true }) searchText: string | null;

  @Column({ name: 'location_id', type: 'bigint', nullable: true })
  locationId: string | null;

  // 'enum' + enumName is required for every column backed by a real
  // Postgres ENUM type (see migration 001) — a bare 'varchar' column type
  // causes TypeORM to send these as untyped text params, which Postgres
  // rejects against an enum column. This was broken for every enum
  // column on Vehicle/User/Seller/Dealer/VehicleImage before this fix.
  @Index()
  @Column({ type: 'enum', enum: ['DRAFT', 'PENDING_REVIEW', 'ACTIVE', 'RESERVED', 'SOLD', 'ARCHIVED', 'REJECTED'], enumName: 'vehicle_status', default: 'DRAFT' })
  status: VehicleStatus;

  @Column({ name: 'verification_status', type: 'enum', enum: ['UNVERIFIED', 'PENDING', 'VERIFIED', 'REJECTED'], enumName: 'verification_status', default: 'UNVERIFIED' })
  verificationStatus: VerificationStatus;

  @Column({ name: 'view_count', type: 'bigint', default: 0 })
  viewCount: string;

  @Column({ name: 'published_at', type: 'timestamptz', nullable: true })
  publishedAt: Date | null;

  @Column({ name: 'sold_at', type: 'timestamptz', nullable: true })
  soldAt: Date | null;

  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;

  @Column({ name: 'deleted_at', type: 'timestamptz', nullable: true })
  deletedAt: Date | null;

  @OneToMany(() => VehicleImage, (image) => image.vehicle)
  images: VehicleImage[];
}
