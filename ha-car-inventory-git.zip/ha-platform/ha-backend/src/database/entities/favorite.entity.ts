import { CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { User } from './user.entity';
import { Vehicle } from './vehicle.entity';

@Entity('favorites')
export class Favorite {
  @PrimaryColumn({ name: 'user_id', type: 'uuid' }) userId: string;
  @PrimaryColumn({ name: 'vehicle_id', type: 'uuid' }) vehicleId: string;

  @ManyToOne(() => User, { onDelete: 'CASCADE' }) @JoinColumn({ name: 'user_id' }) user: User;
  @ManyToOne(() => Vehicle, { onDelete: 'CASCADE' }) @JoinColumn({ name: 'vehicle_id' }) vehicle: Vehicle;

  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
}
