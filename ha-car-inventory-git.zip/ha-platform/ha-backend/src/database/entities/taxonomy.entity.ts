import { Column, Entity, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';

// Small, mostly-static lookup tables (migration 004). Grouped in one file
// since they're simple and change together rarely — split out if any of
// them grows real business logic.
@Entity('vehicle_makes')
export class VehicleMake {
  @PrimaryGeneratedColumn() id: number;
  @Column() name: string;
  @Column() slug: string;
}

@Entity('vehicle_models')
export class VehicleModel {
  @PrimaryGeneratedColumn() id: number;

  @ManyToOne(() => VehicleMake)
  @JoinColumn({ name: 'make_id' })
  make: VehicleMake;

  @Column({ name: 'make_id' }) makeId: number;
  @Column() name: string;
  @Column() slug: string;
}

@Entity('body_types')
export class BodyType {
  @PrimaryGeneratedColumn() id: number;
  @Column() name: string;
}

@Entity('fuel_types')
export class FuelType {
  @PrimaryGeneratedColumn() id: number;
  @Column() name: string;
}

@Entity('transmissions')
export class Transmission {
  @PrimaryGeneratedColumn() id: number;
  @Column() name: string;
}

@Entity('drive_types')
export class DriveType {
  @PrimaryGeneratedColumn() id: number;
  @Column() name: string;
}

@Entity('conditions')
export class VehicleCondition {
  @PrimaryGeneratedColumn() id: number;
  @Column() name: string;
}
