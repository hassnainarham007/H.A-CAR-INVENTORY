import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { User } from './user.entity';

@Entity('dealers')
export class Dealer {
  @PrimaryGeneratedColumn('uuid') id: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'owner_user_id' })
  owner: User;

  @Column({ name: 'owner_user_id', type: 'uuid' })
  ownerUserId: string;

  @Column({ name: 'legal_name' })
  legalName: string;

  @Column({ name: 'verification_status', type: 'enum', enum: ['UNVERIFIED', 'PENDING', 'VERIFIED', 'REJECTED'], enumName: 'verification_status', default: 'UNVERIFIED' })
  verificationStatus: 'UNVERIFIED' | 'PENDING' | 'VERIFIED' | 'REJECTED';

  @Column({ name: 'rating_avg', type: 'numeric', default: 0 })
  ratingAvg: string;

  @Column({ name: 'rating_count', default: 0 })
  ratingCount: number;

  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}
