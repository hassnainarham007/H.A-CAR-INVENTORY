import { Column, CreateDateColumn, Entity, Index, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { UserProfile } from './user-profile.entity';

export type UserStatus = 'ACTIVE' | 'SUSPENDED' | 'BANNED' | 'DEACTIVATED' | 'PENDING_VERIFICATION';
export type AccountType = 'CUSTOMER' | 'SELLER' | 'DEALER' | 'DEALER_EMPLOYEE' | 'ADMIN' | 'SUPER_ADMIN' | 'SUPPORT';

// Maps onto the `users` table (migration 002), after migration 010 aligns
// the account_type enum with this backend's role model.
@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Index({ unique: true })
  @Column({ type: 'citext' })
  email: string;

  @Column({ type: 'varchar', length: 20, nullable: true, unique: true })
  phone: string | null;

  @Column({ name: 'password_hash', type: 'text' })
  passwordHash: string;

  @Column({ type: 'enum', enum: ['ACTIVE', 'SUSPENDED', 'BANNED', 'DEACTIVATED', 'PENDING_VERIFICATION'], enumName: 'user_status', default: 'PENDING_VERIFICATION' })
  status: UserStatus;

  // enumName MUST match the Postgres type name from migration 001 exactly.
  // Without an explicit 'enum' column type + enumName, TypeORM sends this
  // parameter as plain text and Postgres rejects it with "column is of
  // type account_type but expression is of type character varying" on
  // every single INSERT/UPDATE — this was broken against the real schema.
  @Column({ name: 'account_type', type: 'enum', enum: ['CUSTOMER', 'SELLER', 'DEALER', 'DEALER_EMPLOYEE', 'ADMIN', 'SUPER_ADMIN', 'SUPPORT'], enumName: 'account_type', default: 'CUSTOMER' })
  accountType: AccountType;

  @Column({ name: 'email_verified_at', type: 'timestamptz', nullable: true })
  emailVerifiedAt: Date | null;

  @Column({ name: 'failed_login_attempts', type: 'smallint', default: 0 })
  failedLoginAttempts: number;

  @Column({ name: 'locked_until', type: 'timestamptz', nullable: true })
  lockedUntil: Date | null;

  @Column({ name: 'deleted_at', type: 'timestamptz', nullable: true })
  deletedAt: Date | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  @OneToOne(() => UserProfile, (profile) => profile.user)
  profile?: UserProfile;
}
