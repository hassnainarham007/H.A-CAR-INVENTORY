import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Vehicle } from './vehicle.entity';

@Entity('vehicle_images')
export class VehicleImage {
  @PrimaryGeneratedColumn('uuid') id: string;

  @ManyToOne(() => Vehicle, (vehicle) => vehicle.images, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'vehicle_id' })
  vehicle: Vehicle;

  @Column({ name: 'vehicle_id', type: 'uuid' }) vehicleId: string;

  @Column({ type: 'text' }) url: string;
  @Column({ name: 'media_type', type: 'enum', enum: ['EXTERIOR', 'INTERIOR', 'ENGINE', 'DAMAGE', 'DOCUMENT', 'OTHER'], enumName: 'media_type', default: 'EXTERIOR' }) mediaType: string;
  @Column({ name: 'sort_order', default: 0 }) sortOrder: number;
  @Column({ name: 'is_primary', default: false }) isPrimary: boolean;

  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
}
