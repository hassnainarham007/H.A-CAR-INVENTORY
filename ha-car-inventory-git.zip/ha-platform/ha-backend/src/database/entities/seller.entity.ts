import { Column, CreateDateColumn, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { User } from './user.entity';

@Entity('sellers')
export class Seller {
  @PrimaryGeneratedColumn('uuid') id: string;

  @OneToOne(() => User)
  @JoinColumn({ name: 'user_id' })
  user: User;

  @Column({ name: 'user_id', type: 'uuid' })
  userId: string;

  @Column({ name: 'seller_type', type: 'enum', enum: ['PRIVATE', 'DEALER'], enumName: 'seller_type', default: 'PRIVATE' })
  sellerType: 'PRIVATE' | 'DEALER';

  @Column({ name: 'verification_status', type: 'enum', enum: ['UNVERIFIED', 'PENDING', 'VERIFIED', 'REJECTED'], enumName: 'verification_status', default: 'UNVERIFIED' })
  verificationStatus: 'UNVERIFIED' | 'PENDING' | 'VERIFIED' | 'REJECTED';

  @Column({ name: 'rating_avg', type: 'numeric', default: 0 })
  ratingAvg: string;

  @Column({ name: 'rating_count', default: 0 })
  ratingCount: number;

  @CreateDateColumn({ name: 'created_at' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' }) updatedAt: Date;
}
