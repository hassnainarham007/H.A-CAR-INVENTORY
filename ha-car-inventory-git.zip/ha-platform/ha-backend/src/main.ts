import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import helmet from 'helmet';
import { AppModule } from './app.module';
import { HttpExceptionFilter } from './common/filters/http-exception.filter';
import { ResponseInterceptor } from './common/interceptors/response.interceptor';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.use(helmet());
  const configuredOrigins = (process.env.CORS_ORIGINS ?? '').split(',').filter(Boolean);
  const isDev = (process.env.NODE_ENV ?? 'development') !== 'production';
  // An unset CORS_ORIGINS previously resolved to an empty array, which
  // blocks ALL cross-origin requests — including the frontend's own dev
  // server on a different port. That's a safe failure mode in production
  // (deny by default) but a broken one in development, where nobody sets
  // this env var before their first `docker compose up`. Default to the
  // frontend's known dev origin only when NODE_ENV isn't production.
  const corsOrigins = configuredOrigins.length > 0 ? configuredOrigins : isDev ? ['http://localhost:3000'] : [];
  app.enableCors({
    origin: corsOrigins,
    credentials: true,
  });

  const apiPrefix = process.env.API_PREFIX ?? 'api/v1';
  app.setGlobalPrefix(apiPrefix, { exclude: ['health'] });

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );
  app.useGlobalFilters(new HttpExceptionFilter());
  app.useGlobalInterceptors(new ResponseInterceptor());

  const swaggerConfig = new DocumentBuilder()
    .setTitle('H.A Car Inventory API')
    .setDescription('Backend API for the H.A Car Inventory global automotive marketplace')
    .setVersion('1.0')
    .addBearerAuth()
    .build();
  const document = SwaggerModule.createDocument(app, swaggerConfig);
  SwaggerModule.setup(`${apiPrefix}/docs`, app, document);

  const port = process.env.PORT ?? 3000;
  await app.listen(port);
  // eslint-disable-next-line no-console
  console.log(`H.A Car Inventory API running on :${port}/${apiPrefix} — docs at /${apiPrefix}/docs`);
}
bootstrap();
