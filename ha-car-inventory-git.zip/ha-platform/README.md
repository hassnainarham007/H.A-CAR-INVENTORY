# H.A Car Inventory

A global automotive marketplace — PostgreSQL schema, NestJS backend, Next.js frontend, all wired together in this one repository.

**Founder:** Hassnain Arham · Phalia, Punjab, Pakistan · hassnainarham007@gmail.com

---

## Two ways to run this

### Option A — Just look at the site (fastest, no database needed)

The frontend has a built-in fallback: if it can't reach the backend, it
shows realistic sample inventory instead of an error. So you can preview
the entire UI — homepage, browsing, filters, vehicle pages, compare,
favorites, financing calculator — with nothing but Node.js installed:

```bash
cd ha-frontend
npm install
npm run dev
```

Open **http://localhost:3000**. Accounts, real listings, and persistence
won't work yet (there's no database) — everything else will.

### Option B — The full stack (real accounts, real data, real API)

This needs PostgreSQL and Redis running. The single easiest way to get
both without installing anything locally is Docker:

```bash
# from this folder (the repo root)
cp ha-backend/.env.example ha-backend/.env      # then edit the JWT secrets — see below
cp ha-frontend/.env.example ha-frontend/.env.local
docker compose up --build
```

- Frontend: **http://localhost:3001**
- Backend API: **http://localhost:3000/api/v1**
- API docs (Swagger): **http://localhost:3000/api/v1/docs**
- Health check: **http://localhost:3000/health**

Postgres and Redis start automatically as part of `docker compose up` —
the database schema (all 10 migration files) runs itself on first boot.

**Don't have Docker?** Run `npm install` then `npm run dev` from this repo
root instead — it starts both apps together via npm workspaces — but you
still need a real Postgres + Redis reachable at the `DATABASE_URL` /
`REDIS_URL` in `ha-backend/.env` first. The fastest way to get those
without installing Postgres yourself is a free hosted database — see
"Deploying" below.

```bash
npm install
npm run dev
```

---

## Required environment variables

Copy the `.env.example` in **each** app folder — don't skip this, the
backend refuses to start without real secrets (it validates env vars at
boot and fails fast rather than starting insecurely):

**`ha-backend/.env`** (copy from `ha-backend/.env.example`):
- `DATABASE_URL` — your Postgres connection string
- `REDIS_URL` — your Redis connection string
- `JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET` — any long random strings (e.g. `openssl rand -hex 32`), must be different from each other
- `CORS_ORIGINS` — set to `http://localhost:3001` for local dev

**`ha-frontend/.env.local`** (copy from `ha-frontend/.env.example`):
- `NEXT_PUBLIC_API_BASE_URL` — where the backend is running, e.g. `http://localhost:3000/api/v1`

Everything else in both `.env.example` files (AI provider key, Stripe keys,
SMTP credentials) is **optional** — those features are already coded to
degrade honestly (AI assistant says "not connected yet", email sends are
logged instead of delivered) rather than break when the credential is
missing. Fill them in when you have real ones.

---

## What's actually working vs. what's a documented next step

This is a large project built in stages. Full, honest scope breakdowns —
including a CTO-style audit of bugs found and fixed — live in:

- `ha-backend/docs/BACKEND_README.md`
- `ha-frontend/docs/FRONTEND_README.md`
- `ha-backend/migrations/` + inline SQL comments for the database design

Short version: authentication, vehicle CRUD, search/filters/sort/pagination,
seller onboarding, favorites, compare, financing calculator, SEO
(sitemap/structured data), and the AI assistant UI (honestly not yet
connected to a real model) all work end-to-end against the real database.
Messaging, payments, admin dashboard, and dealer profile pages are
scaffolded with a documented pattern for building them, not faked.

---

## Production build (no Docker)

```bash
npm run build     # builds both apps
npm run start     # runs both in production mode (needs .env files set as above)
```

---

## Deploying

This project isn't deployed anywhere by me — there's no live URL. Here's
the realistic path, roughly in order of effort:

1. **Database + Redis (5 min):** create a free Postgres on
   [Neon](https://neon.tech) or [Supabase](https://supabase.com), and a free
   Redis on [Upstash](https://upstash.com). Run the SQL files in
   `ha-backend/migrations/` against it, in order (001 through 010, then
   `seed.sql` if you want sample data). Copy the connection strings into
   `DATABASE_URL` / `REDIS_URL`.
2. **Backend:** deploy `ha-backend/` to [Railway](https://railway.app) or
   [Render](https://render.com) — both build directly from the included
   `Dockerfile` with zero config changes. Set the environment variables
   from `ha-backend/.env.example` in their dashboard.
3. **Frontend:** deploy `ha-frontend/` to [Vercel](https://vercel.com) —
   it's a standard Next.js app, so this is close to zero-config. Set
   `NEXT_PUBLIC_API_BASE_URL` to your deployed backend's URL from step 2.
4. **Point CORS at your real frontend URL:** update `CORS_ORIGINS` in the
   backend's environment to your Vercel URL once you have it, or every
   request from the deployed frontend will be blocked.

Alternative: a single VPS (DigitalOcean/Hetzner/etc.) running
`docker compose up --build` from this repo root deploys everything —
frontend, backend, Postgres, and Redis — in one shot, using the
`docker-compose.yml` already in this folder.
