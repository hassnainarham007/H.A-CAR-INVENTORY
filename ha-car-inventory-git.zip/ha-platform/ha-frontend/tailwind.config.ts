import type { Config } from 'tailwindcss';

// Original palette: deep "motor oil" charcoal + a warm brass/amber accent —
// avoids the generic blue-SaaS look while staying premium/automotive.
// Both a dark (default, showroom-at-night) and light theme are supported
// via the `dark` class strategy so the whole design system works both ways.
const config: Config = {
  darkMode: 'class',
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        charcoal: {
          950: '#0a0b0d',
          900: '#111317',
          800: '#1a1d22',
          700: '#262a31',
          600: '#383d46',
          500: '#565d69',
        },
        brass: {
          50: '#fdf8ee',
          100: '#f9ecd0',
          300: '#eec97e',
          400: '#e3ac4c',
          500: '#c9902f', // primary brand accent
          600: '#a67323',
          700: '#7c561b',
        },
        verified: {
          500: '#2f9e6e', // trust/verification green, used sparingly
        },
      },
      fontFamily: {
        display: ['var(--font-display)', 'ui-sans-serif', 'system-ui'],
        sans: ['var(--font-sans)', 'ui-sans-serif', 'system-ui'],
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      boxShadow: {
        card: '0 1px 2px rgba(0,0,0,0.06), 0 8px 24px -8px rgba(0,0,0,0.25)',
      },
      keyframes: {
        'fade-in': { from: { opacity: '0', transform: 'translateY(4px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        shimmer: { from: { backgroundPosition: '-200% 0' }, to: { backgroundPosition: '200% 0' } },
      },
      animation: {
        'fade-in': 'fade-in 0.25s ease-out',
        shimmer: 'shimmer 1.6s linear infinite',
      },
    },
  },
  plugins: [],
};

export default config;
