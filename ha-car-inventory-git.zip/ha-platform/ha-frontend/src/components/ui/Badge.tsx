import { HTMLAttributes } from 'react';
import { cn } from '@/lib/utils/cn';

type Tone = 'neutral' | 'verified' | 'warning' | 'danger' | 'brand';

const toneClasses: Record<Tone, string> = {
  neutral: 'bg-charcoal-800 text-charcoal-100 ring-charcoal-600',
  verified: 'bg-verified-500/15 text-verified-500 ring-verified-500/30',
  warning: 'bg-amber-500/15 text-amber-400 ring-amber-500/30',
  danger: 'bg-red-500/15 text-red-400 ring-red-500/30',
  brand: 'bg-brass-500/15 text-brass-400 ring-brass-500/30',
};

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  tone?: Tone;
}

export function Badge({ tone = 'neutral', className, children, ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset',
        toneClasses[tone],
        className,
      )}
      {...props}
    >
      {children}
    </span>
  );
}
