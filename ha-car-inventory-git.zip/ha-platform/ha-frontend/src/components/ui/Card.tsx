import { HTMLAttributes } from 'react';
import { cn } from '@/lib/utils/cn';

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        'rounded-xl2 border border-charcoal-800 bg-charcoal-900 shadow-card',
        className,
      )}
      {...props}
    />
  );
}
