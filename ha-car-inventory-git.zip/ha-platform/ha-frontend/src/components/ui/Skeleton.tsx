import { HTMLAttributes } from 'react';
import { cn } from '@/lib/utils/cn';

// Loading placeholder used everywhere a card/list is fetched. Uses a CSS
// gradient shimmer (see tailwind.config animation.shimmer) instead of a
// spinner, which reads as faster and preserves layout (no CLS on load).
export function Skeleton({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        'animate-shimmer rounded-lg bg-[linear-gradient(110deg,theme(colors.charcoal.800)8%,theme(colors.charcoal.700)18%,theme(colors.charcoal.800)33%)] bg-[length:200%_100%]',
        className,
      )}
      {...props}
    />
  );
}
