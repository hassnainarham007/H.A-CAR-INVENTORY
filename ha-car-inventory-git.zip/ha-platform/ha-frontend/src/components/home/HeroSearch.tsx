'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Search } from 'lucide-react';
import { Select } from '@/components/ui/Select';
import { sampleMakes, sampleBodyTypes } from '@/data/sample-vehicles';

export function HeroSearch() {
  const router = useRouter();
  const [make, setMake] = useState('');
  const [bodyType, setBodyType] = useState('');
  const [priceMax, setPriceMax] = useState('');
  const [location, setLocation] = useState('');

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (make) params.set('make', make);
    if (bodyType) params.set('bodyType', bodyType);
    if (priceMax) params.set('priceMax', priceMax);
    if (location) params.set('location', location);
    router.push(`/cars?${params.toString()}`);
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="w-full max-w-4xl rounded-xl2 border border-charcoal-700 bg-charcoal-900/90 p-4 shadow-2xl backdrop-blur sm:p-6"
    >
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Select aria-label="Make" value={make} onChange={(e) => setMake(e.target.value)}>
          <option value="">Any Make</option>
          {sampleMakes.map((m) => (
            <option key={m.id} value={m.slug}>{m.name}</option>
          ))}
        </Select>
        <Select aria-label="Body type" value={bodyType} onChange={(e) => setBodyType(e.target.value)}>
          <option value="">Any Body Type</option>
          {sampleBodyTypes.map((b) => (
            <option key={b} value={b}>{b}</option>
          ))}
        </Select>
        <Select aria-label="Max price" value={priceMax} onChange={(e) => setPriceMax(e.target.value)}>
          <option value="">Any Price</option>
          <option value="10000">Under $10,000</option>
          <option value="30000">Under $30,000</option>
          <option value="60000">Under $60,000</option>
          <option value="100000">Under $100,000</option>
        </Select>
        <input
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          placeholder="City or country"
          aria-label="Location"
          className="h-11 rounded-lg border border-charcoal-700 bg-charcoal-800 px-3.5 text-sm text-white placeholder:text-charcoal-500 focus:outline-none focus:ring-2 focus:ring-brass-500"
        />
      </div>

      <div className="mt-4 flex flex-col gap-3 sm:flex-row">
        <button
          type="submit"
          className="flex h-12 flex-1 items-center justify-center gap-2 rounded-lg bg-brass-500 text-sm font-semibold text-charcoal-950 transition-colors hover:bg-brass-400"
        >
          <Search className="h-4 w-4" /> Search Cars
        </button>
        <a
          href="/cars"
          className="flex h-12 flex-1 items-center justify-center rounded-lg border border-charcoal-600 text-sm font-semibold text-white transition-colors hover:bg-charcoal-800 sm:flex-none sm:px-6"
        >
          Browse Inventory
        </a>
        <a
          href="/sell"
          className="flex h-12 flex-1 items-center justify-center rounded-lg border border-charcoal-600 text-sm font-semibold text-white transition-colors hover:bg-charcoal-800 sm:flex-none sm:px-6"
        >
          Sell Your Car
        </a>
      </div>
    </form>
  );
}
