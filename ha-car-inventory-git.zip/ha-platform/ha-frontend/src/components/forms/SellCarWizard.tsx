'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { vehiclesApi } from '@/lib/api/vehicles';
import { sellersApi } from '@/lib/api/sellers';
import { ApiClientError } from '@/lib/api/client';
import { toMinorUnits } from '@/lib/utils/money';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { sampleMakes, sampleBodyTypes, sampleFuelTypes, sampleTransmissions } from '@/data/sample-vehicles';

// Implements steps 1-3, 6, 9-10 of the brief's 10-step flow with REAL
// submission logic against POST /vehicles (already built, tested backend
// endpoint). Steps 4 (Photos), 5 (Documents), 8 (Verification) are shown as
// disabled placeholders rather than faked — they need the backend's S3
// upload module and seller_verifications workflow, neither of which exist
// yet (flagged in docs/BACKEND_README.md). Building a fake drag-and-drop
// that doesn't actually upload anywhere would be worse than being honest
// about what's not wired up.
const STEPS = [
  'Vehicle Info',
  'Specifications',
  'Condition',
  'Photos',
  'Documents',
  'Pricing',
  'Seller Info',
  'Verification',
  'Preview',
  'Publish',
] as const;

interface FormState {
  makeId: number;
  modelId: number;
  year: number;
  bodyTypeId: number;
  fuelTypeId: number;
  transmissionId: number;
  mileage: number;
  conditionId: number;
  description: string;
  priceAmount: number;
  priceCurrency: string;
  isNegotiable: boolean;
}

const INITIAL_STATE: FormState = {
  makeId: 1,
  modelId: 1,
  year: new Date().getFullYear(),
  bodyTypeId: 1,
  fuelTypeId: 1,
  transmissionId: 1,
  mileage: 0,
  conditionId: 2,
  description: '',
  priceAmount: 0,
  priceCurrency: 'USD',
  isNegotiable: true,
};

export function SellCarWizard() {
  const { accessToken, user, applyTokens } = useAuth();
  const router = useRouter();
  const [stepIndex, setStepIndex] = useState(0);
  const [form, setForm] = useState<FormState>(INITIAL_STATE);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const step = STEPS[stepIndex];
  const canGoBack = stepIndex > 0;
  const isPhotoOrDocOrVerifyStep = step === 'Photos' || step === 'Documents' || step === 'Verification';

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handlePublish() {
    if (!accessToken) {
      router.push('/login');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      let token = accessToken;
      try {
        await createAndPublish(token);
      } catch (err) {
        // A plain CUSTOMER has no seller/dealer record yet — the backend
        // rejects with 403. Previously there was NO path forward from here
        // at all (no seller-registration endpoint existed); now there is,
        // so transparently register the user as a seller and retry ONCE
        // rather than making them hunt for a separate "become a seller" flow.
        if (err instanceof ApiClientError && err.status === 403) {
          const { tokens } = await sellersApi.registerAsSeller(token);
          await applyTokens(tokens);
          token = tokens.accessToken;
          await createAndPublish(token);
        } else {
          throw err;
        }
      }
      router.push('/seller/dashboard');
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Could not publish this listing. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  async function createAndPublish(token: string) {
    const created = await vehiclesApi.create(token, {
      makeId: form.makeId,
      modelId: form.modelId,
      year: form.year,
      priceAmount: toMinorUnits(form.priceAmount),
      priceCurrency: form.priceCurrency,
      isNegotiable: form.isNegotiable,
      mileage: form.mileage,
      mileageUnit: 'KM',
      conditionId: form.conditionId,
      bodyTypeId: form.bodyTypeId,
      fuelTypeId: form.fuelTypeId,
      transmissionId: form.transmissionId,
      description: form.description,
    });
    await vehiclesApi.publish(token, created.id);
  }

  if (!user) {
    return (
      <Card className="p-8 text-center">
        <p className="mb-4 text-sm text-charcoal-300">You need an account to list a vehicle.</p>
        <Button onClick={() => router.push('/login')}>Log in to continue</Button>
      </Card>
    );
  }

  return (
    <div>
      {/* Step indicator */}
      <ol className="mb-8 flex flex-wrap gap-2 text-xs">
        {STEPS.map((s, i) => (
          <li
            key={s}
            className={`rounded-full px-3 py-1 ${i === stepIndex ? 'bg-brass-500 text-charcoal-950' : i < stepIndex ? 'bg-verified-500/20 text-verified-500' : 'bg-charcoal-800 text-charcoal-500'}`}
          >
            {i + 1}. {s}
          </li>
        ))}
      </ol>

      <Card className="p-6">
        {step === 'Vehicle Info' && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Select label="Make" value={form.makeId} onChange={(e) => update('makeId', Number(e.target.value))}>
              {sampleMakes.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
            </Select>
            <Input label="Model" placeholder="e.g. Corolla" onChange={() => update('modelId', 1)} />
            {/* NOTE: modelId is hardcoded to 1 here — sample-vehicles.ts only
                seeds a couple of make→model pairs for demo purposes. Wire this
                to GET /vehicle-models?makeId=... once that endpoint exists. */}
            <Input label="Year" type="number" value={form.year} onChange={(e) => update('year', Number(e.target.value))} />
            <Select label="Body Type" value={form.bodyTypeId} onChange={(e) => update('bodyTypeId', Number(e.target.value))}>
              {sampleBodyTypes.map((b, i) => <option key={b} value={i + 1}>{b}</option>)}
            </Select>
          </div>
        )}

        {step === 'Specifications' && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Select label="Fuel Type" value={form.fuelTypeId} onChange={(e) => update('fuelTypeId', Number(e.target.value))}>
              {sampleFuelTypes.map((f, i) => <option key={f} value={i + 1}>{f}</option>)}
            </Select>
            <Select label="Transmission" value={form.transmissionId} onChange={(e) => update('transmissionId', Number(e.target.value))}>
              {sampleTransmissions.map((t, i) => <option key={t} value={i + 1}>{t}</option>)}
            </Select>
            <Input label="Mileage (KM)" type="number" value={form.mileage} onChange={(e) => update('mileage', Number(e.target.value))} />
          </div>
        )}

        {step === 'Condition' && (
          <div className="flex flex-col gap-4">
            <Select label="Condition" value={form.conditionId} onChange={(e) => update('conditionId', Number(e.target.value))}>
              <option value={1}>New</option>
              <option value={2}>Used</option>
              <option value={3}>Certified Pre-Owned</option>
              <option value={4}>Salvage</option>
            </Select>
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium text-charcoal-100">Description &amp; Seller Notes</label>
              <textarea
                value={form.description}
                onChange={(e) => update('description', e.target.value)}
                rows={5}
                placeholder="Describe the vehicle's condition, history, and anything a buyer should know..."
                className="rounded-lg border border-charcoal-700 bg-charcoal-800 p-3 text-sm text-white placeholder:text-charcoal-500 focus:outline-none focus:ring-2 focus:ring-brass-500"
              />
            </div>
          </div>
        )}

        {isPhotoOrDocOrVerifyStep && (
          <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-charcoal-700 py-14 text-center">
            <p className="text-sm font-medium text-charcoal-300">
              {step} isn&apos;t connected to the backend yet.
            </p>
            <p className="max-w-sm text-xs text-charcoal-500">
              {step === 'Photos' && 'Needs the S3-compatible upload module (see backend README).'}
              {step === 'Documents' && 'Needs the same upload module plus vehicle_documents endpoints.'}
              {step === 'Verification' && 'Needs the seller_verifications review workflow.'}
              {' '}You can skip ahead — this listing will publish without it for now.
            </p>
          </div>
        )}

        {step === 'Pricing' && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input label="Price" type="number" value={form.priceAmount} onChange={(e) => update('priceAmount', Number(e.target.value))} />
            <Select label="Currency" value={form.priceCurrency} onChange={(e) => update('priceCurrency', e.target.value)}>
              {['USD', 'EUR', 'GBP', 'PKR', 'AED', 'SAR', 'CAD', 'AUD'].map((c) => <option key={c} value={c}>{c}</option>)}
            </Select>
            <label className="col-span-2 flex items-center gap-2 text-sm text-charcoal-300">
              <input type="checkbox" checked={form.isNegotiable} onChange={(e) => update('isNegotiable', e.target.checked)} className="h-4 w-4 rounded border-charcoal-600 bg-charcoal-800 text-brass-500" />
              Price is negotiable
            </label>
          </div>
        )}

        {step === 'Seller Info' && (
          <div className="text-sm text-charcoal-300">
            <p>Listing as <span className="font-medium text-white">{user.profile?.displayName || user.email}</span> ({user.accountType}).</p>
            <p className="mt-2 text-xs text-charcoal-500">Update your business details in your seller profile before publishing.</p>
          </div>
        )}

        {step === 'Preview' && (
          <div className="text-sm text-charcoal-300">
            <h3 className="mb-2 text-lg font-semibold text-white">
              {form.year} {sampleMakes.find((m) => m.id === form.makeId)?.name}
            </h3>
            <p className="text-brass-400">{form.priceAmount ? `${form.priceCurrency} ${form.priceAmount.toLocaleString()}` : 'No price set'}</p>
            <p className="mt-2 text-charcoal-400">{form.description || 'No description yet.'}</p>
          </div>
        )}

        {step === 'Publish' && (
          <div className="text-center">
            <p className="mb-4 text-sm text-charcoal-300">Ready to publish? Your listing will go live immediately.</p>
            {error && <p className="mb-4 text-sm text-red-400">{error}</p>}
            <Button onClick={handlePublish} isLoading={submitting}>Publish Listing</Button>
          </div>
        )}
      </Card>

      <div className="mt-6 flex justify-between">
        <Button variant="outline" disabled={!canGoBack} onClick={() => setStepIndex((i) => i - 1)}>Back</Button>
        {step !== 'Publish' && (
          <Button onClick={() => setStepIndex((i) => Math.min(i + 1, STEPS.length - 1))}>Next</Button>
        )}
      </div>
    </div>
  );
}
