import Link from 'next/link';

const COLUMNS: { title: string; links: { href: string; label: string }[] }[] = [
  {
    title: 'Explore',
    links: [
      { href: '/cars', label: 'Browse Cars' },
      { href: '/dealers', label: 'Dealers' },
      { href: '/sell', label: 'Sell Your Car' },
      { href: '/financing', label: 'Financing' },
      { href: '/guides', label: 'Guides' },
    ],
  },
  {
    title: 'Company',
    links: [
      { href: '/about', label: 'About' },
      { href: '/contact', label: 'Contact' },
      { href: '/privacy', label: 'Privacy Policy' },
      { href: '/terms', label: 'Terms of Service' },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-charcoal-800 bg-charcoal-950">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <span className="font-display text-lg font-bold text-white">
              H.A <span className="text-brass-400">Car Inventory</span>
            </span>
            <p className="mt-3 max-w-xs text-sm text-charcoal-400">
              A global automotive marketplace connecting buyers with verified sellers and dealerships worldwide.
            </p>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h4 className="text-sm font-semibold text-white">{col.title}</h4>
              <ul className="mt-3 flex flex-col gap-2">
                {col.links.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href} className="text-sm text-charcoal-400 hover:text-white">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div>
            <h4 className="text-sm font-semibold text-white">Contact</h4>
            <address className="mt-3 flex flex-col gap-1.5 text-sm not-italic text-charcoal-400">
              <span>Hassnain Arham</span>
              <span>Phalia, Punjab, Pakistan</span>
              <a href="mailto:hassnainarham007@gmail.com" className="hover:text-white">
                hassnainarham007@gmail.com
              </a>
            </address>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-charcoal-800 pt-6 text-xs text-charcoal-500 md:flex-row">
          <p>© {new Date().getFullYear()} H.A Car Inventory. All rights reserved.</p>
          <p>Prices shown may vary by currency and region.</p>
        </div>
      </div>
    </footer>
  );
}
