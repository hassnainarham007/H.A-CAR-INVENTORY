'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Menu, X, Heart, User } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

const NAV_LINKS = [
  { href: '/cars', label: 'Buy' },
  { href: '/sell', label: 'Sell Your Car' },
  { href: '/dealers', label: 'Dealers' },
  { href: '/financing', label: 'Financing' },
  { href: '/compare', label: 'Compare' },
  { href: '/guides', label: 'Guides' },
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user } = useAuth();
  const accountHref = user ? '/account' : '/login';

  return (
    <header className="sticky top-0 z-40 border-b border-charcoal-800 bg-charcoal-950/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2">
          <span className="font-display text-xl font-bold tracking-tight text-white">
            H.A <span className="text-brass-400">Car Inventory</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-7 lg:flex">
          {NAV_LINKS.map((link) => (
            <Link key={link.href} href={link.href} className="text-sm font-medium text-charcoal-300 transition-colors hover:text-white">
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <Link href="/favorites" aria-label="Saved vehicles" className="rounded-lg p-2 text-charcoal-300 hover:bg-charcoal-800 hover:text-white">
            <Heart className="h-5 w-5" />
          </Link>
          <Link href={accountHref} className="rounded-lg p-2 text-charcoal-300 hover:bg-charcoal-800 hover:text-white" aria-label="Account">
            <User className="h-5 w-5" />
            {user && <span className="sr-only">{user.profile?.displayName ?? user.email}</span>}
          </Link>
          <Link
            href="/sell"
            className="inline-flex h-9 items-center justify-center rounded-lg bg-brass-500 px-4 text-sm font-medium text-charcoal-950 transition-colors hover:bg-brass-400"
          >
            Sell Your Car
          </Link>
        </div>

        <button
          type="button"
          className="p-2 text-white lg:hidden"
          onClick={() => setMobileOpen((v) => !v)}
          aria-label="Toggle menu"
          aria-expanded={mobileOpen}
        >
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {mobileOpen && (
        <nav className="border-t border-charcoal-800 px-4 py-4 lg:hidden">
          <ul className="flex flex-col gap-3">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="block py-1 text-sm font-medium text-charcoal-200" onClick={() => setMobileOpen(false)}>
                  {link.label}
                </Link>
              </li>
            ))}
            <li className="flex gap-4 pt-2">
              <Link href={accountHref} className="text-sm font-medium text-charcoal-200">{user ? 'My Account' : 'Log in'}</Link>
              <Link href="/favorites" className="text-sm font-medium text-charcoal-200">Saved</Link>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
