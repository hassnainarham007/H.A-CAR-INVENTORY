'use client';

import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { cn } from '@/lib/utils/cn';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

const SUGGESTED_PROMPTS = [
  'Find me an SUV under $30,000',
  'Compare BMW 5 Series and Mercedes E-Class',
  'Which cars are good for families?',
  'Show me electric cars',
];

export function AiAssistantWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, open]);

  async function sendMessage(text: string) {
    if (!text.trim() || sending) return;
    setMessages((prev) => [...prev, { role: 'user', content: text }]);
    setInput('');
    setSending(true);
    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text }),
      });
      const data = await res.json();
      setMessages((prev) => [...prev, { role: 'assistant', content: data.reply ?? 'Something went wrong. Please try again.' }]);
    } catch {
      setMessages((prev) => [...prev, { role: 'assistant', content: "I couldn't reach the assistant service. Please try again shortly." }]);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="fixed bottom-5 right-5 z-50">
      {open && (
        <div className="mb-3 flex h-[28rem] w-80 flex-col overflow-hidden rounded-xl2 border border-charcoal-700 bg-charcoal-900 shadow-2xl animate-fade-in sm:w-96">
          <div className="flex items-center justify-between border-b border-charcoal-800 bg-charcoal-950 px-4 py-3">
            <div>
              <p className="text-sm font-semibold text-white">H.A Auto Assistant</p>
              <p className="text-xs text-charcoal-400">Ask about inventory, specs, or comparisons</p>
            </div>
            <button onClick={() => setOpen(false)} aria-label="Close assistant" className="text-charcoal-400 hover:text-white">
              <X className="h-5 w-5" />
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
            {messages.length === 0 && (
              <div className="space-y-3">
                <p className="text-sm text-charcoal-300">Hi, I&apos;m H.A Auto Assistant. What kind of car are you looking for?</p>
                <div className="flex flex-wrap gap-2">
                  {SUGGESTED_PROMPTS.map((prompt) => (
                    <button
                      key={prompt}
                      onClick={() => sendMessage(prompt)}
                      className="rounded-full border border-charcoal-700 px-3 py-1.5 text-xs text-charcoal-300 hover:border-brass-500 hover:text-brass-400"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {messages.map((msg, i) => (
              <div
                key={i}
                className={cn(
                  'max-w-[85%] rounded-lg px-3 py-2 text-sm',
                  msg.role === 'user' ? 'ml-auto bg-brass-500 text-charcoal-950' : 'bg-charcoal-800 text-charcoal-100',
                )}
              >
                {msg.content}
              </div>
            ))}
            {sending && <div className="w-fit rounded-lg bg-charcoal-800 px-3 py-2 text-sm text-charcoal-400">Thinking…</div>}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage(input);
            }}
            className="flex items-center gap-2 border-t border-charcoal-800 p-3"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about a car…"
              className="h-10 flex-1 rounded-lg border border-charcoal-700 bg-charcoal-800 px-3 text-sm text-white placeholder:text-charcoal-500 focus:outline-none focus:ring-2 focus:ring-brass-500"
            />
            <button
              type="submit"
              disabled={sending}
              aria-label="Send message"
              className="flex h-10 w-10 items-center justify-center rounded-lg bg-brass-500 text-charcoal-950 disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}

      <button
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? 'Close AI assistant' : 'Open AI assistant'}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-brass-500 text-charcoal-950 shadow-2xl transition-transform hover:scale-105"
      >
        {open ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </button>
    </div>
  );
}
