'use client';

import { useMemo, useState } from 'react';
import { Input } from '@/components/ui/Input';
import { Card } from '@/components/ui/Card';

interface CalculatorInputs {
  vehiclePrice: number;
  downPayment: number;
  tradeInValue: number;
  fees: number;
  loanTermMonths: number;
  annualInterestRatePct: number;
}

// Standard amortized-loan formula. Deliberately done in plain floating-point
// HERE ONLY because this is a client-side *estimate* the user sees before
// any transaction — the moment a real financing request is submitted, it
// must go through the backend's financing_calculations logic (integer
// basis-points interest rate, stored server-side), matching the schema's
// "never store money as a float" rule. This calculator never submits or
// persists anything — it's purely illustrative math.
function calculateMonthlyPayment({ vehiclePrice, downPayment, tradeInValue, fees, loanTermMonths, annualInterestRatePct }: CalculatorInputs) {
  const principal = Math.max(0, vehiclePrice - downPayment - tradeInValue + fees);
  const monthlyRate = annualInterestRatePct / 100 / 12;

  if (monthlyRate === 0) {
    const monthlyPayment = principal / loanTermMonths;
    return { monthlyPayment, totalInterest: 0, totalPayment: principal };
  }

  const monthlyPayment = (principal * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -loanTermMonths));
  const totalPayment = monthlyPayment * loanTermMonths;
  const totalInterest = totalPayment - principal;
  return { monthlyPayment, totalInterest, totalPayment };
}

export function FinancingCalculator({ initialPrice = 30000 }: { initialPrice?: number }) {
  const [vehiclePrice, setVehiclePrice] = useState(initialPrice);
  const [downPayment, setDownPayment] = useState(Math.round(initialPrice * 0.2));
  const [tradeInValue, setTradeInValue] = useState(0);
  const [fees, setFees] = useState(0);
  const [loanTermMonths, setLoanTermMonths] = useState(60);
  const [annualInterestRatePct, setAnnualInterestRatePct] = useState(7.5);

  const result = useMemo(
    () => calculateMonthlyPayment({ vehiclePrice, downPayment, tradeInValue, fees, loanTermMonths, annualInterestRatePct }),
    [vehiclePrice, downPayment, tradeInValue, fees, loanTermMonths, annualInterestRatePct],
  );

  const fmt = (n: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <Card className="p-6">
        <div className="grid grid-cols-2 gap-4">
          <Input label="Vehicle Price" type="number" value={vehiclePrice} onChange={(e) => setVehiclePrice(Number(e.target.value))} />
          <Input label="Down Payment" type="number" value={downPayment} onChange={(e) => setDownPayment(Number(e.target.value))} />
          <Input label="Trade-in Value" type="number" value={tradeInValue} onChange={(e) => setTradeInValue(Number(e.target.value))} />
          <Input label="Taxes & Fees" type="number" value={fees} onChange={(e) => setFees(Number(e.target.value))} />
          <Input label="Loan Term (months)" type="number" value={loanTermMonths} onChange={(e) => setLoanTermMonths(Number(e.target.value))} />
          <Input label="Interest Rate (APR %)" type="number" step="0.1" value={annualInterestRatePct} onChange={(e) => setAnnualInterestRatePct(Number(e.target.value))} />
        </div>
      </Card>

      <Card className="flex flex-col justify-center gap-4 p-6">
        <div>
          <p className="text-xs uppercase tracking-wide text-charcoal-400">Estimated Monthly Payment</p>
          <p className="text-4xl font-bold text-brass-400">{fmt(result.monthlyPayment)}</p>
        </div>
        <div className="grid grid-cols-2 gap-4 border-t border-charcoal-800 pt-4">
          <div>
            <p className="text-xs text-charcoal-400">Total Interest</p>
            <p className="text-lg font-semibold text-white">{fmt(result.totalInterest)}</p>
          </div>
          <div>
            <p className="text-xs text-charcoal-400">Total Cost</p>
            <p className="text-lg font-semibold text-white">{fmt(result.totalPayment)}</p>
          </div>
        </div>
        <p className="mt-2 text-xs text-charcoal-500">
          This is an estimate only, for illustration purposes. Actual rates, terms, and monthly payments depend on your
          credit profile, lender, and location, and are not guaranteed by H.A Car Inventory.
        </p>
      </Card>
    </div>
  );
}
