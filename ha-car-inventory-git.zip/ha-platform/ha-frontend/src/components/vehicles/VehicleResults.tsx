'use client';

import { useState } from 'react';
import type { Vehicle } from '@/lib/types/vehicle';
import { VehicleCard } from './VehicleCard';
import { VehicleListToolbar } from './VehicleListToolbar';
import { EmptyState } from '@/components/ui/EmptyState';
import { useFavorites } from '@/context/FavoritesContext';
import { useCompare } from '@/context/CompareContext';

export function VehicleResults({ vehicles, totalItems }: { vehicles: Vehicle[]; totalItems: number }) {
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const { isFavorited, toggleFavorite } = useFavorites();
  const { isComparing, toggleCompare, atLimit } = useCompare();

  if (vehicles.length === 0) {
    return (
      <EmptyState
        title="No vehicles match these filters"
        description="Try widening your price range or clearing a filter to see more results."
      />
    );
  }

  return (
    <div>
      <VehicleListToolbar totalItems={totalItems} view={view} onViewChange={setView} />
      <div className={view === 'grid' ? 'grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3' : 'flex flex-col gap-4'}>
        {vehicles.map((vehicle) => (
          <VehicleCard
            key={vehicle.id}
            vehicle={vehicle}
            view={view}
            isFavorited={isFavorited(vehicle.id)}
            onToggleFavorite={toggleFavorite}
            isComparing={isComparing(vehicle.id)}
            onToggleCompare={toggleCompare}
            compareDisabled={atLimit}
          />
        ))}
      </div>
    </div>
  );
}
