'use client';

import Image from 'next/image';
import { useState } from 'react';
import type { VehicleImage } from '@/lib/types/vehicle';
import { cn } from '@/lib/utils/cn';

export function VehicleGallery({ images, title }: { images: VehicleImage[]; title: string }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const active = images[activeIndex];

  return (
    <div>
      <div className="relative aspect-[16/10] w-full overflow-hidden rounded-xl2 bg-charcoal-800">
        {active ? (
          <Image src={active.url} alt={title} fill priority className="object-cover" sizes="(max-width: 1024px) 100vw, 66vw" />
        ) : (
          <div className="flex h-full items-center justify-center text-charcoal-500">No photos available</div>
        )}
        {/* Placeholder affordance for a future 360° viewer — wire a real
            360-image sequence or embed here once the backend supports it. */}
        {images.length > 0 && (
          <span className="absolute bottom-3 right-3 rounded-full bg-charcoal-950/70 px-3 py-1 text-xs text-white backdrop-blur">
            {activeIndex + 1} / {images.length} · 360° view coming soon
          </span>
        )}
      </div>

      {images.length > 1 && (
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {images.map((img, i) => (
            <button
              key={img.id}
              onClick={() => setActiveIndex(i)}
              className={cn(
                'relative h-16 w-24 flex-shrink-0 overflow-hidden rounded-lg border-2',
                i === activeIndex ? 'border-brass-500' : 'border-transparent',
              )}
            >
              <Image src={img.url} alt="" fill className="object-cover" sizes="96px" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
