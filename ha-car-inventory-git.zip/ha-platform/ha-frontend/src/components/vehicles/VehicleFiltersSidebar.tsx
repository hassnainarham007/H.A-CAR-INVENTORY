'use client';

import { useRouter, useSearchParams, usePathname } from 'next/navigation';
import { Select } from '@/components/ui/Select';
import { Input } from '@/components/ui/Input';
import { sampleMakes, sampleBodyTypes, sampleFuelTypes, sampleTransmissions } from '@/data/sample-vehicles';

// Filters are encoded directly in the URL (searchParams) rather than
// component state — makes the filtered view shareable/bookmarkable and
// lets the listing page fetch server-side with the exact same params.
export function VehicleFiltersSidebar() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  function setParam(key: string, value: string) {
    const params = new URLSearchParams(searchParams.toString());
    if (value) params.set(key, value);
    else params.delete(key);
    params.delete('page'); // any filter change resets pagination
    router.push(`${pathname}?${params.toString()}`);
  }

  return (
    <aside className="flex w-full flex-col gap-5 lg:w-64">
      <FilterGroup label="Make">
        <Select value={searchParams.get('make') ?? ''} onChange={(e) => setParam('make', e.target.value)}>
          <option value="">Any Make</option>
          {sampleMakes.map((m) => (
            <option key={m.id} value={m.slug}>{m.name}</option>
          ))}
        </Select>
      </FilterGroup>

      <FilterGroup label="Body Type">
        <Select value={searchParams.get('bodyType') ?? ''} onChange={(e) => setParam('bodyType', e.target.value)}>
          <option value="">Any</option>
          {sampleBodyTypes.map((b) => (
            <option key={b} value={b}>{b}</option>
          ))}
        </Select>
      </FilterGroup>

      <FilterGroup label="Fuel Type">
        <Select value={searchParams.get('fuel') ?? ''} onChange={(e) => setParam('fuel', e.target.value)}>
          <option value="">Any</option>
          {sampleFuelTypes.map((f) => (
            <option key={f} value={f}>{f}</option>
          ))}
        </Select>
      </FilterGroup>

      <FilterGroup label="Transmission">
        <Select value={searchParams.get('transmission') ?? ''} onChange={(e) => setParam('transmission', e.target.value)}>
          <option value="">Any</option>
          {sampleTransmissions.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </Select>
      </FilterGroup>

      <FilterGroup label="Price Range">
        <div className="flex gap-2">
          <Input type="number" placeholder="Min" defaultValue={searchParams.get('priceMin') ?? ''} onBlur={(e) => setParam('priceMin', e.target.value)} />
          <Input type="number" placeholder="Max" defaultValue={searchParams.get('priceMax') ?? ''} onBlur={(e) => setParam('priceMax', e.target.value)} />
        </div>
      </FilterGroup>

      <FilterGroup label="Year Range">
        <div className="flex gap-2">
          <Input type="number" placeholder="From" defaultValue={searchParams.get('yearMin') ?? ''} onBlur={(e) => setParam('yearMin', e.target.value)} />
          <Input type="number" placeholder="To" defaultValue={searchParams.get('yearMax') ?? ''} onBlur={(e) => setParam('yearMax', e.target.value)} />
        </div>
      </FilterGroup>

      <FilterGroup label="Max Mileage">
        <Input type="number" placeholder="e.g. 50000" defaultValue={searchParams.get('mileageMax') ?? ''} onBlur={(e) => setParam('mileageMax', e.target.value)} />
      </FilterGroup>

      <label className="flex items-center gap-2 text-sm text-charcoal-300">
        <input
          type="checkbox"
          checked={searchParams.get('verified') === 'true'}
          onChange={(e) => setParam('verified', e.target.checked ? 'true' : '')}
          className="h-4 w-4 rounded border-charcoal-600 bg-charcoal-800 text-brass-500 focus:ring-brass-500"
        />
        Verified vehicles only
      </label>

      <button
        onClick={() => router.push(pathname)}
        className="text-left text-xs font-medium text-charcoal-400 hover:text-white"
      >
        Clear all filters
      </button>
    </aside>
  );
}

function FilterGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-charcoal-400">{label}</p>
      {children}
    </div>
  );
}
