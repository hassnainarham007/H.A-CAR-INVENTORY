'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { X } from 'lucide-react';
import { useCompare } from '@/context/CompareContext';
import { getVehicleByIdSafe } from '@/lib/api/getVehiclesSafe';
import type { Vehicle } from '@/lib/types/vehicle';
import { formatMoney } from '@/lib/utils/money';
import { formatMileage } from '@/lib/utils/format';
import { vehicleUrl } from '@/lib/utils/format';
import { EmptyState } from '@/components/ui/EmptyState';

const ROWS: { label: string; render: (v: Vehicle) => string }[] = [
  { label: 'Price', render: (v) => formatMoney(v.priceAmount, v.priceCurrency) },
  { label: 'Year', render: (v) => String(v.year) },
  { label: 'Mileage', render: (v) => formatMileage(v.mileage, v.mileageUnit) },
  { label: 'Transmission', render: (v) => v.transmission.name },
  { label: 'Fuel Type', render: (v) => v.fuelType.name },
  { label: 'Drivetrain', render: (v) => v.driveType?.name ?? '—' },
  { label: 'Body Type', render: (v) => v.bodyType.name },
  { label: 'Condition', render: (v) => v.condition.name },
  { label: 'Seller', render: (v) => v.sellerName ?? '—' },
  { label: 'Location', render: (v) => v.locationLabel ?? '—' },
];

export function CompareTable() {
  const { compareIds, toggleCompare, clearCompare } = useCompare();
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);

  useEffect(() => {
    let cancelled = false;
    Promise.all(compareIds.map((id) => getVehicleByIdSafe(id))).then((results) => {
      if (!cancelled) setVehicles(results.filter((v): v is Vehicle => v !== null));
    });
    return () => {
      cancelled = true;
    };
  }, [compareIds]);

  if (compareIds.length === 0) {
    return (
      <EmptyState
        title="No vehicles selected yet"
        description="Browse listings and tap “Add to compare” on any vehicle card to start comparing."
        action={
          <Link href="/cars" className="text-sm font-medium text-brass-400 hover:text-brass-300">
            Browse Cars →
          </Link>
        }
      />
    );
  }

  return (
    <div className="overflow-x-auto">
      <div className="mb-3 flex justify-end">
        <button onClick={clearCompare} className="text-xs font-medium text-charcoal-400 hover:text-white">
          Clear all
        </button>
      </div>
      <table className="w-full min-w-[640px] border-collapse">
        <thead>
          <tr>
            <th className="w-32" />
            {vehicles.map((v) => (
              <th key={v.id} className="p-3 text-left align-top">
                <div className="relative mb-2 h-28 w-full overflow-hidden rounded-lg bg-charcoal-800">
                  {v.images[0] && <Image src={v.images[0].url} alt="" fill className="object-cover" sizes="200px" />}
                  <button
                    onClick={() => toggleCompare(v.id)}
                    aria-label="Remove from comparison"
                    className="absolute right-1 top-1 flex h-6 w-6 items-center justify-center rounded-full bg-charcoal-950/70 text-white"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
                <Link href={vehicleUrl(v.make.name, v.model.name, v.year, v.id)} className="text-sm font-semibold text-white hover:text-brass-400">
                  {v.year} {v.make.name} {v.model.name}
                </Link>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {ROWS.map((row) => (
            <tr key={row.label} className="border-t border-charcoal-800">
              <td className="p-3 text-xs font-semibold uppercase tracking-wide text-charcoal-400">{row.label}</td>
              {vehicles.map((v) => (
                <td key={v.id} className="p-3 text-sm text-white">{row.render(v)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
