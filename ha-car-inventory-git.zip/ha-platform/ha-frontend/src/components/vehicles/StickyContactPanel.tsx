'use client';

import { Phone, Mail, MessageCircle, CalendarClock, Heart, Share2, Flag } from 'lucide-react';
import type { Vehicle } from '@/lib/types/vehicle';
import { formatMoney } from '@/lib/utils/money';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { useFavorites } from '@/context/FavoritesContext';

export function StickyContactPanel({ vehicle }: { vehicle: Vehicle }) {
  const { isFavorited, toggleFavorite } = useFavorites();
  const favorited = isFavorited(vehicle.id);

  return (
    <Card className="sticky top-24 flex flex-col gap-4 p-5">
      <div>
        <p className="text-2xl font-bold text-brass-400">{formatMoney(vehicle.priceAmount, vehicle.priceCurrency)}</p>
        {vehicle.isNegotiable && <p className="text-xs text-charcoal-400">Price negotiable</p>}
      </div>

      <div className="flex items-center gap-2">
        {vehicle.verificationStatus === 'VERIFIED' && <Badge tone="verified">✓ Verified Vehicle</Badge>}
        <Badge tone="neutral">{vehicle.sellerType === 'DEALER' ? 'Dealer' : 'Private Seller'}</Badge>
      </div>

      <div className="border-t border-charcoal-800 pt-4">
        <p className="text-sm font-semibold text-white">{vehicle.sellerName}</p>
        <p className="text-xs text-charcoal-400">{vehicle.locationLabel}</p>
      </div>

      <div className="flex flex-col gap-2">
        <a
          href="tel:+923000000000"
          className="flex h-11 items-center justify-center gap-2 rounded-lg bg-brass-500 text-sm font-semibold text-charcoal-950 hover:bg-brass-400"
        >
          <Phone className="h-4 w-4" /> Call Seller
        </a>
        <a
          href={`mailto:hassnainarham007@gmail.com?subject=${encodeURIComponent(`Inquiry: ${vehicle.year} ${vehicle.make.name} ${vehicle.model.name}`)}`}
          className="flex h-11 items-center justify-center gap-2 rounded-lg border border-charcoal-600 text-sm font-semibold text-white hover:bg-charcoal-800"
        >
          <Mail className="h-4 w-4" /> Email Seller
        </a>
        <a
          href="https://wa.me/923000000000"
          target="_blank"
          rel="noopener noreferrer"
          className="flex h-11 items-center justify-center gap-2 rounded-lg border border-verified-500/40 text-sm font-semibold text-verified-500 hover:bg-verified-500/10"
        >
          <MessageCircle className="h-4 w-4" /> WhatsApp
        </a>
        <button className="flex h-11 items-center justify-center gap-2 rounded-lg border border-charcoal-600 text-sm font-semibold text-white hover:bg-charcoal-800">
          <CalendarClock className="h-4 w-4" /> Book Test Drive
        </button>
      </div>

      <div className="flex items-center justify-between border-t border-charcoal-800 pt-3 text-xs text-charcoal-400">
        <button onClick={() => toggleFavorite(vehicle.id)} className="flex items-center gap-1 hover:text-white">
          <Heart className={favorited ? 'h-4 w-4 fill-brass-500 text-brass-500' : 'h-4 w-4'} /> {favorited ? 'Saved' : 'Save'}
        </button>
        <button className="flex items-center gap-1 hover:text-white">
          <Share2 className="h-4 w-4" /> Share
        </button>
        <button className="flex items-center gap-1 hover:text-red-400">
          <Flag className="h-4 w-4" /> Report
        </button>
      </div>
    </Card>
  );
}
