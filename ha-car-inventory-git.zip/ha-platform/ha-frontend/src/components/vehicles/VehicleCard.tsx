import Image from 'next/image';
import Link from 'next/link';
import { Heart, GitCompareArrows } from 'lucide-react';
import type { Vehicle } from '@/lib/types/vehicle';
import { formatMoney } from '@/lib/utils/money';
import { formatMileage } from '@/lib/utils/format';
import { vehicleUrl } from '@/lib/utils/format';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';

interface VehicleCardProps {
  vehicle: Vehicle;
  view?: 'grid' | 'list';
  isFavorited?: boolean;
  onToggleFavorite?: (vehicleId: string) => void;
  isComparing?: boolean;
  onToggleCompare?: (vehicleId: string) => void;
  compareDisabled?: boolean;
}

export function VehicleCard({
  vehicle,
  view = 'grid',
  isFavorited,
  onToggleFavorite,
  isComparing,
  onToggleCompare,
  compareDisabled,
}: VehicleCardProps) {
  const primaryImage = vehicle.images.find((img) => img.isPrimary) ?? vehicle.images[0];
  const href = vehicleUrl(vehicle.make.name, vehicle.model.name, vehicle.year, vehicle.id);

  return (
    <Card
      className={
        view === 'grid'
          ? 'group overflow-hidden transition-transform hover:-translate-y-0.5 hover:shadow-lg'
          : 'group flex overflow-hidden transition-colors hover:border-charcoal-600'
      }
    >
      <Link href={href} className={view === 'grid' ? 'block' : 'flex w-full'}>
        <div className={view === 'grid' ? 'relative aspect-[4/3] w-full' : 'relative h-40 w-56 flex-shrink-0'}>
          {primaryImage ? (
            <Image
              src={primaryImage.url}
              alt={`${vehicle.year} ${vehicle.make.name} ${vehicle.model.name}`}
              fill
              sizes="(max-width: 768px) 100vw, 33vw"
              className="object-cover transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            <div className="flex h-full items-center justify-center bg-charcoal-800 text-charcoal-500 text-sm">
              No photo available
            </div>
          )}

          <div className="absolute left-3 top-3 flex gap-2">
            {vehicle.verificationStatus === 'VERIFIED' && <Badge tone="verified">✓ Verified</Badge>}
            {vehicle.condition.name === 'Certified Pre-Owned' && <Badge tone="brand">CPO</Badge>}
          </div>

          {onToggleFavorite && (
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                onToggleFavorite(vehicle.id);
              }}
              aria-label={isFavorited ? 'Remove from favorites' : 'Save to favorites'}
              className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-charcoal-950/70 backdrop-blur transition-colors hover:bg-charcoal-950"
            >
              <Heart className={isFavorited ? 'h-4 w-4 fill-brass-500 text-brass-500' : 'h-4 w-4 text-white'} />
            </button>
          )}
        </div>

        <div className="flex flex-1 flex-col gap-1.5 p-4">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-display text-base font-semibold text-white">
              {vehicle.year} {vehicle.make.name} {vehicle.model.name}
            </h3>
          </div>
          <p className="text-lg font-bold text-brass-400">{formatMoney(vehicle.priceAmount, vehicle.priceCurrency)}</p>

          <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-charcoal-400">
            <span>{formatMileage(vehicle.mileage, vehicle.mileageUnit)}</span>
            <span>·</span>
            <span>{vehicle.transmission.name}</span>
            <span>·</span>
            <span>{vehicle.fuelType.name}</span>
          </div>

          <div className="mt-1 flex items-center justify-between text-xs text-charcoal-500">
            <span>{vehicle.locationLabel}</span>
            <span>{vehicle.sellerType === 'DEALER' ? 'Dealer' : 'Private Seller'}</span>
          </div>

          {onToggleCompare && (
            <button
              type="button"
              disabled={!isComparing && compareDisabled}
              onClick={(e) => {
                e.preventDefault();
                onToggleCompare(vehicle.id);
              }}
              className="mt-2 flex items-center gap-1.5 self-start text-xs font-medium text-charcoal-400 hover:text-brass-400 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <GitCompareArrows className="h-3.5 w-3.5" />
              {isComparing ? 'Added to compare' : 'Add to compare'}
            </button>
          )}
        </div>
      </Link>
    </Card>
  );
}
