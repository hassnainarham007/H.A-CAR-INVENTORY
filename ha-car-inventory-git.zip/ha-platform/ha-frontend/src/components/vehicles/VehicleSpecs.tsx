import type { Vehicle } from '@/lib/types/vehicle';
import { formatMileage } from '@/lib/utils/format';

export function VehicleSpecs({ vehicle }: { vehicle: Vehicle }) {
  const rows: [string, string][] = [
    ['VIN', vehicle.vin ?? 'Not provided'],
    ['Stock #', vehicle.stockNumber ?? '—'],
    ['Body Type', vehicle.bodyType.name],
    ['Condition', vehicle.condition.name],
    ['Mileage', formatMileage(vehicle.mileage, vehicle.mileageUnit)],
    ['Fuel Type', vehicle.fuelType.name],
    ['Transmission', vehicle.transmission.name],
    ['Drivetrain', vehicle.driveType?.name ?? '—'],
    ['Year', String(vehicle.year)],
  ];

  return (
    <div className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
      {rows.map(([label, value]) => (
        <div key={label} className="flex justify-between border-b border-charcoal-800 py-2 text-sm">
          <span className="text-charcoal-400">{label}</span>
          <span className="font-medium text-white">{value}</span>
        </div>
      ))}
    </div>
  );
}
