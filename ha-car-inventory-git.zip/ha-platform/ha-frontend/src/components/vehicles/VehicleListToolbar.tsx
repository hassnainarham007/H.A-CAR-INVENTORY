'use client';

import { useRouter, useSearchParams, usePathname } from 'next/navigation';
import { LayoutGrid, List } from 'lucide-react';
import { cn } from '@/lib/utils/cn';

const SORT_OPTIONS = [
  { value: 'recommended', label: 'Recommended' },
  { value: 'newest', label: 'Newest' },
  { value: 'price-asc', label: 'Price: Low to High' },
  { value: 'price-desc', label: 'Price: High to Low' },
  { value: 'mileage', label: 'Mileage' },
  { value: 'year', label: 'Year' },
];

export function VehicleListToolbar({ totalItems, view, onViewChange }: { totalItems: number; view: 'grid' | 'list'; onViewChange: (v: 'grid' | 'list') => void }) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  function setSort(value: string) {
    const params = new URLSearchParams(searchParams.toString());
    params.set('sort', value);
    router.push(`${pathname}?${params.toString()}`);
  }

  return (
    <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <p className="text-sm text-charcoal-400">{totalItems.toLocaleString()} vehicles found</p>

      <div className="flex items-center gap-3">
        <select
          value={searchParams.get('sort') ?? 'recommended'}
          onChange={(e) => setSort(e.target.value)}
          className="h-10 rounded-lg border border-charcoal-700 bg-charcoal-800 px-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-brass-500"
        >
          {SORT_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>

        <div className="flex overflow-hidden rounded-lg border border-charcoal-700">
          <button
            aria-label="Grid view"
            onClick={() => onViewChange('grid')}
            className={cn('flex h-10 w-10 items-center justify-center', view === 'grid' ? 'bg-brass-500 text-charcoal-950' : 'bg-charcoal-800 text-charcoal-400')}
          >
            <LayoutGrid className="h-4 w-4" />
          </button>
          <button
            aria-label="List view"
            onClick={() => onViewChange('list')}
            className={cn('flex h-10 w-10 items-center justify-center', view === 'list' ? 'bg-brass-500 text-charcoal-950' : 'bg-charcoal-800 text-charcoal-400')}
          >
            <List className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
