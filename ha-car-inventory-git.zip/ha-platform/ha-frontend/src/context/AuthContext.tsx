'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { authApi } from '@/lib/api/auth';
import type { AuthUser, TokenPair } from '@/lib/types/user';

interface AuthContextValue {
  user: AuthUser | null;
  accessToken: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, firstName?: string, lastName?: string) => Promise<void>;
  logout: () => Promise<void>;
  /** For flows that mint a fresh token pair outside login (e.g. becoming a
   * seller changes the JWT's accountType claim) — stores the new tokens and
   * re-fetches the user so the UI reflects the change immediately. */
  applyTokens: (tokens: TokenPair) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

// Parses "15m" / "30d" / "3600s" into milliseconds. Matches the format
// AuthService.issueTokenPair returns as `expiresIn` (JWT_ACCESS_EXPIRES_IN).
function parseDurationToMs(expr: string): number {
  const match = /^(\d+)([smhd])$/.exec(expr);
  if (!match) return 15 * 60_000;
  const value = Number(match[1]);
  const unitMs: Record<string, number> = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 };
  return value * unitMs[match[2]];
}

// NOTE ON SECURITY TRADEOFF: tokens are kept in localStorage here for
// simplicity, matching how the backend issues them (bearer JWT). This is
// vulnerable to XSS token theft. The production-hardened version of this
// should move to httpOnly, Secure, SameSite=Strict cookies set by a
// Next.js Route Handler that proxies /auth/* — the backend's refresh-token
// ROTATION logic already built (AuthService) doesn't change either way,
// only where the token is stored on the client. Flagged here rather than
// silently shipped, since this is a real security decision worth your
// attention as you productionize this.
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const refreshTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Access tokens are short-lived (15m default) and NOTHING was previously
  // refreshing them proactively — every authenticated call would start
  // silently 401ing 15 minutes into a session with no way back short of a
  // manual re-login. This schedules a refresh shortly before expiry using
  // the real refresh-token-rotation endpoint the backend already has.
  const scheduleRefresh = useCallback((expiresIn: string) => {
    if (refreshTimer.current) clearTimeout(refreshTimer.current);
    const ms = parseDurationToMs(expiresIn);
    const fireIn = Math.max(ms - 60_000, 5_000); // refresh 1 min early, floor at 5s
    refreshTimer.current = setTimeout(async () => {
      const storedRefreshToken = localStorage.getItem('ha_refresh_token');
      if (!storedRefreshToken) return;
      try {
        const tokens = await authApi.refresh(storedRefreshToken);
        localStorage.setItem('ha_access_token', tokens.accessToken);
        localStorage.setItem('ha_refresh_token', tokens.refreshToken);
        setAccessToken(tokens.accessToken);
        scheduleRefresh(tokens.expiresIn);
      } catch {
        // Refresh token expired/revoked — force a clean logout rather than
        // leaving the UI in a half-authenticated state.
        localStorage.removeItem('ha_access_token');
        localStorage.removeItem('ha_refresh_token');
        setAccessToken(null);
        setUser(null);
      }
    }, fireIn);
  }, []);

  useEffect(() => {
    const token = localStorage.getItem('ha_access_token');
    if (!token) {
      setLoading(false);
      return;
    }
    setAccessToken(token);
    authApi
      .me(token)
      .then((fetchedUser) => {
        setUser(fetchedUser);
        scheduleRefresh('15m'); // conservative default; exact expiry isn't known on cold load
      })
      .catch(() => {
        localStorage.removeItem('ha_access_token');
        localStorage.removeItem('ha_refresh_token');
      })
      .finally(() => setLoading(false));

    return () => {
      if (refreshTimer.current) clearTimeout(refreshTimer.current);
    };
  }, [scheduleRefresh]);

  const applyTokens = useCallback(async (tokens: TokenPair) => {
    localStorage.setItem('ha_access_token', tokens.accessToken);
    localStorage.setItem('ha_refresh_token', tokens.refreshToken);
    setAccessToken(tokens.accessToken);
    scheduleRefresh(tokens.expiresIn);
    const refreshedUser = await authApi.me(tokens.accessToken);
    setUser(refreshedUser);
  }, [scheduleRefresh]);

  const login = useCallback(async (email: string, password: string) => {
    const { user: loggedInUser, tokens } = await authApi.login({ email, password });
    localStorage.setItem('ha_access_token', tokens.accessToken);
    localStorage.setItem('ha_refresh_token', tokens.refreshToken);
    setAccessToken(tokens.accessToken);
    setUser(loggedInUser);
    scheduleRefresh(tokens.expiresIn);
  }, [scheduleRefresh]);

  const register = useCallback(async (email: string, password: string, firstName?: string, lastName?: string) => {
    await authApi.register({ email, password, firstName, lastName });
    await login(email, password);
  }, [login]);

  const logout = useCallback(async () => {
    const refreshToken = localStorage.getItem('ha_refresh_token');
    if (accessToken && refreshToken) {
      await authApi.logout(accessToken, refreshToken).catch(() => {});
    }
    if (refreshTimer.current) clearTimeout(refreshTimer.current);
    localStorage.removeItem('ha_access_token');
    localStorage.removeItem('ha_refresh_token');
    setAccessToken(null);
    setUser(null);
  }, [accessToken]);

  const value = useMemo(
    () => ({ user, accessToken, loading, login, register, logout, applyTokens }),
    [user, accessToken, loading, login, register, logout, applyTokens],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
