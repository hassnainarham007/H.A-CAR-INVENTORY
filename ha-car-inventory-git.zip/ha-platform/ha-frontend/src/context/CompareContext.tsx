'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

const STORAGE_KEY = 'ha-car-inventory:compare';
const MAX_COMPARE = 4;

interface CompareContextValue {
  compareIds: string[];
  isComparing: (vehicleId: string) => boolean;
  toggleCompare: (vehicleId: string) => void;
  clearCompare: () => void;
  atLimit: boolean;
}

const CompareContext = createContext<CompareContextValue | null>(null);

export function CompareProvider({ children }: { children: ReactNode }) {
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setCompareIds(JSON.parse(raw));
    } catch {
      // ignore corrupted value
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem(STORAGE_KEY, JSON.stringify(compareIds));
  }, [compareIds, hydrated]);

  const toggleCompare = useCallback((vehicleId: string) => {
    setCompareIds((prev) => {
      if (prev.includes(vehicleId)) return prev.filter((id) => id !== vehicleId);
      if (prev.length >= MAX_COMPARE) return prev; // silently ignore past the limit; UI disables the control too
      return [...prev, vehicleId];
    });
  }, []);

  const clearCompare = useCallback(() => setCompareIds([]), []);
  const isComparing = useCallback((vehicleId: string) => compareIds.includes(vehicleId), [compareIds]);

  const value = useMemo(
    () => ({ compareIds, isComparing, toggleCompare, clearCompare, atLimit: compareIds.length >= MAX_COMPARE }),
    [compareIds, isComparing, toggleCompare, clearCompare],
  );

  return <CompareContext.Provider value={value}>{children}</CompareContext.Provider>;
}

export function useCompare() {
  const ctx = useContext(CompareContext);
  if (!ctx) throw new Error('useCompare must be used within CompareProvider');
  return ctx;
}
