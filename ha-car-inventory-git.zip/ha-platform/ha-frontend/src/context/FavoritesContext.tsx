'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { favoritesApi } from '@/lib/api/favorites';

interface FavoritesContextValue {
  favoriteIds: Set<string>;
  isFavorited: (vehicleId: string) => boolean;
  toggleFavorite: (vehicleId: string) => void;
}

const FavoritesContext = createContext<FavoritesContextValue | null>(null);
const STORAGE_KEY = 'ha-car-inventory:favorites';

// Guests: localStorage. Authenticated users: the real backend
// /favorites endpoints. On login, local favorites are merged into the
// account (best-effort) so a guest who favorited vehicles before signing
// up doesn't lose them. This used to be a documented-but-unwired gap —
// favoritesApi existed but nothing ever called it.
export function FavoritesProvider({ children }: { children: ReactNode }) {
  const { user, accessToken } = useAuth();
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [hydrated, setHydrated] = useState(false);
  const [mergedForUser, setMergedForUser] = useState<string | null>(null);

  // Guest hydration from localStorage (runs once on mount).
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setFavoriteIds(new Set(JSON.parse(raw)));
    } catch {
      // corrupted localStorage value — fail safe to an empty favorites set
    }
    setHydrated(true);
  }, []);

  // Guest persistence back to localStorage. Skipped once authenticated,
  // since the source of truth becomes the backend at that point.
  useEffect(() => {
    if (hydrated && !accessToken) localStorage.setItem(STORAGE_KEY, JSON.stringify([...favoriteIds]));
  }, [favoriteIds, hydrated, accessToken]);

  // On sign-in: push any locally-saved favorites to the account (merge,
  // not overwrite), then load the account's real favorites list.
  useEffect(() => {
    if (!user || !accessToken || mergedForUser === user.id) return;

    (async () => {
      try {
        const localIds = [...favoriteIds];
        await Promise.all(localIds.map((id) => favoritesApi.add(accessToken, id).catch(() => {})));
        const serverFavorites = await favoritesApi.list(accessToken);
        setFavoriteIds(new Set(serverFavorites.map((f) => f.vehicleId)));
        localStorage.removeItem(STORAGE_KEY);
      } catch {
        // Backend unreachable — keep whatever's in local state rather than
        // wiping the user's favorites on a network blip.
      } finally {
        setMergedForUser(user.id);
      }
    })();
    // favoriteIds intentionally omitted: this effect should run once per
    // sign-in (guarded by mergedForUser), not on every favorite toggle.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, accessToken, mergedForUser]);

  const toggleFavorite = useCallback(
    (vehicleId: string) => {
      const wasFavorited = favoriteIds.has(vehicleId);
      setFavoriteIds((prev) => {
        const next = new Set(prev);
        if (next.has(vehicleId)) next.delete(vehicleId);
        else next.add(vehicleId);
        return next;
      });

      if (accessToken) {
        const call = wasFavorited ? favoritesApi.remove(accessToken, vehicleId) : favoritesApi.add(accessToken, vehicleId);
        call.catch(() => {
          // Roll back optimistic update on failure so the UI doesn't lie
          // about what's actually saved server-side.
          setFavoriteIds((prev) => {
            const next = new Set(prev);
            if (wasFavorited) next.add(vehicleId);
            else next.delete(vehicleId);
            return next;
          });
        });
      }
    },
    [favoriteIds, accessToken],
  );

  const isFavorited = useCallback((vehicleId: string) => favoriteIds.has(vehicleId), [favoriteIds]);

  const value = useMemo(() => ({ favoriteIds, isFavorited, toggleFavorite }), [favoriteIds, isFavorited, toggleFavorite]);

  return <FavoritesContext.Provider value={value}>{children}</FavoritesContext.Provider>;
}

export function useFavorites() {
  const ctx = useContext(FavoritesContext);
  if (!ctx) throw new Error('useFavorites must be used within FavoritesProvider');
  return ctx;
}
