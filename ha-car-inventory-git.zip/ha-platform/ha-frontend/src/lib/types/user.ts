export type AccountType = 'CUSTOMER' | 'SELLER' | 'DEALER' | 'DEALER_EMPLOYEE' | 'ADMIN' | 'SUPER_ADMIN';

export interface AuthUser {
  id: string;
  email: string;
  accountType: AccountType;
  status: string;
  profile?: {
    firstName?: string | null;
    lastName?: string | null;
    displayName?: string | null;
    avatarUrl?: string | null;
  };
}

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  expiresIn: string;
}
