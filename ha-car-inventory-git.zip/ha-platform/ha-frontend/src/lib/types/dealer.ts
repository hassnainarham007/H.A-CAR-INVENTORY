export interface Dealer {
  id: string;
  legalName: string;
  verificationStatus: string;
  ratingAvg: string;
  ratingCount: number;
  activeListingCount: number;
  createdAt: string;
}
