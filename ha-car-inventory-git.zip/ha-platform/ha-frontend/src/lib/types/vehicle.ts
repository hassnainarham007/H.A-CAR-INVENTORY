// Mirrors the backend's Vehicle entity / DB schema exactly (migration 006 +
// modules/vehicles). Keep this in sync by hand for now; once the backend
// ships OpenAPI codegen, generate this file instead of hand-editing it.

export type VehicleStatus = 'DRAFT' | 'PENDING_REVIEW' | 'ACTIVE' | 'RESERVED' | 'SOLD' | 'ARCHIVED' | 'REJECTED';
export type VerificationStatus = 'UNVERIFIED' | 'PENDING' | 'VERIFIED' | 'REJECTED';
export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'PKR' | 'AED' | 'SAR' | 'CAD' | 'AUD';
export type ConditionName = 'New' | 'Used' | 'Certified Pre-Owned' | 'Salvage';

export interface Taxonomy {
  id: number;
  name: string;
}

export interface VehicleMake extends Taxonomy {
  slug: string;
}

export interface VehicleModelRef extends Taxonomy {
  slug: string;
  makeId: number;
}

export interface VehicleImage {
  id: string;
  url: string;
  mediaType: 'EXTERIOR' | 'INTERIOR' | 'ENGINE' | 'DAMAGE' | 'DOCUMENT' | 'OTHER';
  sortOrder: number;
  isPrimary: boolean;
}

export interface Vehicle {
  id: string;
  sellerId: string | null;
  dealerId: string | null;
  vin: string | null;
  stockNumber: string | null;

  make: VehicleMake;
  model: VehicleModelRef;
  year: number;

  // Minor units as a string (e.g. "4500000" = 45,000.00) — never treat as a
  // JS float. Use formatMoney() from lib/utils/money.ts for display.
  priceAmount: string;
  priceCurrency: CurrencyCode;
  isNegotiable: boolean;

  mileage: number | null;
  mileageUnit: 'KM' | 'MI';

  condition: Taxonomy;
  bodyType: Taxonomy;
  fuelType: Taxonomy;
  transmission: Taxonomy;
  driveType: Taxonomy | null;

  description: string | null;
  images: VehicleImage[];

  status: VehicleStatus;
  verificationStatus: VerificationStatus;
  viewCount: string;

  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;

  // UI-only convenience fields resolved by the API layer / sample data,
  // not stored as separate DB columns.
  sellerName?: string;
  sellerType?: 'PRIVATE' | 'DEALER';
  locationLabel?: string; // e.g. "Lahore, Punjab, Pakistan"
}

export interface VehicleFilters {
  q?: string;
  makeId?: number;
  modelId?: number;
  bodyTypeId?: number;
  fuelTypeId?: number;
  transmissionId?: number;
  driveTypeId?: number;
  conditionId?: number;
  yearMin?: number;
  yearMax?: number;
  priceMin?: number;
  priceMax?: number;
  mileageMax?: number;
  locationId?: string;
  sellerId?: string;
  dealerId?: string;
  verificationStatus?: VerificationStatus;
  sortBy?: 'price' | 'year' | 'mileage' | 'createdAt' | 'publishedAt';
  order?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export interface PaginationMeta {
  page: number;
  limit: number;
  totalItems: number;
  totalPages: number;
}
