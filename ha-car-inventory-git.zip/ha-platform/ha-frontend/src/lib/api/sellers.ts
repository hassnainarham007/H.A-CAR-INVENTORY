import { apiFetch } from './client';
import type { TokenPair } from '@/lib/types/user';

interface SellerRecord {
  id: string;
  userId: string;
  sellerType: 'PRIVATE' | 'DEALER';
  verificationStatus: string;
}

export const sellersApi = {
  registerAsSeller: (accessToken: string) =>
    apiFetch<{ seller: SellerRecord; tokens: TokenPair }>('/sellers/register', { method: 'POST', accessToken }),
};
