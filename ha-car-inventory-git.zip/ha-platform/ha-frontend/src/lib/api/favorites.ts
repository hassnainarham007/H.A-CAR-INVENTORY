import { apiFetch } from './client';

export const favoritesApi = {
  list: (accessToken: string) => apiFetch<{ vehicleId: string }[]>('/favorites', { accessToken }),
  add: (accessToken: string, vehicleId: string) =>
    apiFetch<{ favorited: true }>(`/favorites/${vehicleId}`, { method: 'POST', accessToken }),
  remove: (accessToken: string, vehicleId: string) =>
    apiFetch<{ favorited: false }>(`/favorites/${vehicleId}`, { method: 'DELETE', accessToken }),
};
