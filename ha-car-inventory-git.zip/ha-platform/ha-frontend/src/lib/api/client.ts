import type { ApiResponse } from '@/lib/types/api';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:3000/api/v1';

export class ApiClientError extends Error {
  constructor(
    message: string,
    public code: string,
    public status: number,
    public details?: Record<string, unknown>,
  ) {
    super(message);
    this.name = 'ApiClientError';
  }
}

interface RequestOptions extends Omit<RequestInit, 'body'> {
  body?: unknown;
  accessToken?: string;
  /** Next.js fetch cache/revalidate options — pass through for SSR/ISR pages. */
  next?: NextFetchRequestConfig;
}

// Single chokepoint for every backend call. Handles the {success,data,meta}
// envelope, attaches the bearer token when present, and turns backend
// errors into a typed exception instead of every call site parsing JSON by
// hand. Never put a raw API key or secret here — this file only ever
// forwards the user's own access token, which is safe to hold client-side.
export async function apiFetch<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { body, accessToken, headers, ...rest } = options;

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...rest,
    headers: {
      'Content-Type': 'application/json',
      ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      ...headers,
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  let json: ApiResponse<T>;
  try {
    json = await response.json();
  } catch {
    throw new ApiClientError('The server returned an unreadable response.', 'BAD_RESPONSE', response.status);
  }

  if (!response.ok || json.success === false) {
    const err = json.success === false ? json.error : { code: 'UNKNOWN_ERROR', message: 'Something went wrong.' };
    throw new ApiClientError(err.message, err.code, response.status, 'details' in err ? err.details : undefined);
  }

  return json.data;
}
