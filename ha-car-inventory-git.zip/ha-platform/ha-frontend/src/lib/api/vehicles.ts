import { apiFetch } from './client';
import type { Vehicle, VehicleFilters } from '@/lib/types/vehicle';
import type { Paginated } from '@/lib/types/api';

function toQueryString(filters: VehicleFilters): string {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') params.set(key, String(value));
  });
  const qs = params.toString();
  return qs ? `?${qs}` : '';
}

export const vehiclesApi = {
  list: (filters: VehicleFilters = {}) =>
    apiFetch<Paginated<Vehicle>>(`/vehicles${toQueryString(filters)}`, {
      next: { revalidate: 60 }, // 1-min ISR: listings are near-real-time but don't need to be on every request
    }),

  getById: (id: string) => apiFetch<Vehicle>(`/vehicles/${id}`, { next: { revalidate: 60 } }),

  similar: (id: string) => apiFetch<Vehicle[]>(`/vehicles/${id}/similar`, { next: { revalidate: 300 } }),

  // Returns ALL of the caller's own listings regardless of status (DRAFT,
  // PENDING_REVIEW, ACTIVE, ARCHIVED...) — list() above always filters to
  // ACTIVE only (that's correct for public search), so the seller dashboard
  // needs this separate endpoint rather than list({ sellerId }).
  mine: (accessToken: string) => apiFetch<Paginated<Vehicle>>('/vehicles/mine', { accessToken, cache: 'no-store' }),

  create: (accessToken: string, payload: Record<string, unknown>) =>
    apiFetch<Vehicle>('/vehicles', { method: 'POST', body: payload, accessToken }),

  update: (accessToken: string, id: string, payload: Record<string, unknown>) =>
    apiFetch<Vehicle>(`/vehicles/${id}`, { method: 'PATCH', body: payload, accessToken }),

  remove: (accessToken: string, id: string) =>
    apiFetch<{ deleted: true }>(`/vehicles/${id}`, { method: 'DELETE', accessToken }),

  publish: (accessToken: string, id: string) =>
    apiFetch<Vehicle>(`/vehicles/${id}/publish`, { method: 'POST', accessToken }),

  archive: (accessToken: string, id: string) =>
    apiFetch<Vehicle>(`/vehicles/${id}/archive`, { method: 'POST', accessToken }),
};
