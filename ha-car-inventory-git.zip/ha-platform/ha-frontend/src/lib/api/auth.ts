import { apiFetch } from './client';
import type { AuthUser, TokenPair } from '@/lib/types/user';

export const authApi = {
  register: (payload: { email: string; password: string; firstName?: string; lastName?: string }) =>
    apiFetch<{ user: AuthUser }>('/auth/register', { method: 'POST', body: payload }),

  login: (payload: { email: string; password: string }) =>
    apiFetch<{ user: AuthUser; tokens: TokenPair }>('/auth/login', { method: 'POST', body: payload }),

  refresh: (refreshToken: string) =>
    apiFetch<TokenPair>('/auth/refresh', { method: 'POST', body: { refreshToken } }),

  logout: (accessToken: string, refreshToken: string) =>
    apiFetch<{ loggedOut: true }>('/auth/logout', { method: 'POST', body: { refreshToken }, accessToken }),

  me: (accessToken: string) => apiFetch<AuthUser>('/users/me', { accessToken }),
};
