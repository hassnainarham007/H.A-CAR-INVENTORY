import { apiFetch } from './client';
import type { Dealer } from '@/lib/types/dealer';
import type { Vehicle } from '@/lib/types/vehicle';

export const dealersApi = {
  list: () => apiFetch<Dealer[]>('/dealers', { next: { revalidate: 300 } }),
  getById: (id: string) => apiFetch<Dealer & { vehicles: Vehicle[] }>(`/dealers/${id}`, { next: { revalidate: 120 } }),
};
