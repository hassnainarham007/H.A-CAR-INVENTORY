import { dealersApi } from './dealers';
import type { Dealer } from '@/lib/types/dealer';
import type { Vehicle } from '@/lib/types/vehicle';

// Same fallback boundary as getVehiclesSafe.ts — the dealers directory page
// was previously a dead 404 (empty folder, no backend module at all). Now
// that DealersModule is real, this still degrades to sample data if the
// backend isn't reachable, rather than crashing the page at build/request time.
const SAMPLE_DEALER: Dealer = {
  id: 'sample-dealer',
  legalName: 'H.A Car Inventory',
  verificationStatus: 'VERIFIED',
  ratingAvg: '4.80',
  ratingCount: 12,
  activeListingCount: 3,
  createdAt: new Date().toISOString(),
};

export async function getDealersSafe(): Promise<Dealer[]> {
  try {
    return await dealersApi.list();
  } catch {
    return [SAMPLE_DEALER];
  }
}

export async function getDealerByIdSafe(id: string): Promise<(Dealer & { vehicles: Vehicle[] }) | null> {
  try {
    return await dealersApi.getById(id);
  } catch {
    return { ...SAMPLE_DEALER, id, vehicles: [] };
  }
}
