import { vehiclesApi } from './vehicles';
import { sampleVehicles } from '@/data/sample-vehicles';
import type { Vehicle, VehicleFilters } from '@/lib/types/vehicle';
import type { Paginated } from '@/lib/types/api';

// Used ONLY by pages, never inside components, so the fallback boundary is
// explicit and easy to delete once the backend is deployed everywhere.
// Falls back to realistic sample data (src/data/sample-vehicles.ts) when the
// backend isn't reachable, so the frontend is fully explorable in isolation
// during development — this is a dev convenience, not a production feature.
export async function getVehiclesSafe(filters: VehicleFilters = {}): Promise<Paginated<Vehicle>> {
  try {
    return await vehiclesApi.list(filters);
  } catch {
    const page = filters.page ?? 1;
    const limit = filters.limit ?? 20;
    return {
      data: sampleVehicles,
      meta: { page, limit, totalItems: sampleVehicles.length, totalPages: 1 },
    };
  }
}

export async function getVehicleByIdSafe(id: string): Promise<Vehicle | null> {
  try {
    return await vehiclesApi.getById(id);
  } catch {
    return sampleVehicles.find((v) => v.id === id) ?? sampleVehicles[0] ?? null;
  }
}
