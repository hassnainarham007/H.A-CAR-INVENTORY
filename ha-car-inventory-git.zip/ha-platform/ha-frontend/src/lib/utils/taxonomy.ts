import { sampleMakes, sampleBodyTypes, sampleFuelTypes, sampleTransmissions } from '@/data/sample-vehicles';

// STOPGAP: the backend has no GET /taxonomy endpoint yet (flagged in
// BACKEND_README.md as a follow-up), so there's no way to resolve a
// human-readable filter ("SUV", "Electric") to the numeric ID the vehicles
// API actually filters on. These maps mirror the exact insertion order in
// migrations/seed.sql — body_types/fuel_types/transmissions are inserted in
// this literal order, and Postgres SERIAL assigns 1, 2, 3... accordingly.
// Before this file existed, VehicleFiltersSidebar/HeroSearch wrote a make/
// bodyType/fuel/transmission STRING into the URL that CarsPage never read
// at all — those filters were silently no-ops. This makes them work against
// the seeded dev data; swap for a real taxonomy endpoint once one exists.
export const MAKE_SLUG_TO_ID: Record<string, number> = Object.fromEntries(sampleMakes.map((m) => [m.slug, m.id]));
export const BODY_TYPE_TO_ID: Record<string, number> = Object.fromEntries(sampleBodyTypes.map((name, i) => [name, i + 1]));
export const FUEL_TYPE_TO_ID: Record<string, number> = Object.fromEntries(sampleFuelTypes.map((name, i) => [name, i + 1]));
export const TRANSMISSION_TO_ID: Record<string, number> = Object.fromEntries(sampleTransmissions.map((name, i) => [name, i + 1]));

// Money-unit boundary: every UI control that collects a price from a human
// works in whole currency units (dollars), but the backend/DB store price
// in MINOR units (cents) — see schema docs "never store money as a float".
// This is the ONE place that conversion happens for filter params, so it
// can't silently drift out of sync between HeroSearch, the filters sidebar,
// and the page that actually calls the API.
export function dollarsToMinorUnits(dollarString: string | undefined): number | undefined {
  if (!dollarString) return undefined;
  const n = Number(dollarString);
  return Number.isFinite(n) ? Math.round(n * 100) : undefined;
}
