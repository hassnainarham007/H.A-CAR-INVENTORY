export function formatMileage(mileage: number | null, unit: 'KM' | 'MI'): string {
  if (mileage === null) return 'Mileage not listed';
  return `${new Intl.NumberFormat('en-US').format(mileage)} ${unit}`;
}

export function formatRelativeDate(iso: string | null): string {
  if (!iso) return '';
  const diffMs = Date.now() - new Date(iso).getTime();
  const days = Math.floor(diffMs / 86_400_000);
  if (days <= 0) return 'Listed today';
  if (days === 1) return 'Listed yesterday';
  if (days < 30) return `Listed ${days} days ago`;
  const months = Math.floor(days / 30);
  return `Listed ${months} month${months > 1 ? 's' : ''} ago`;
}

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

export function vehicleUrl(make: string, model: string, year: number, id: string): string {
  // Human-readable + unique: /vehicle/toyota-corolla-2024-<id> — keeps the
  // canonical ID (needed for lookups) while giving Google real SEO text.
  return `/vehicle/${slugify(make)}-${slugify(model)}-${year}-${id}`;
}
