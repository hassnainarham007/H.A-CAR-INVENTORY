import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Standard Tailwind class-merging helper: lets components accept a
// `className` override without fighting specificity/duplicate-class bugs.
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
