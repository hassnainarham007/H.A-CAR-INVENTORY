import type { CurrencyCode } from '@/lib/types/vehicle';

// Every backend price is an integer string in MINOR units (see schema docs:
// money is never a float). USD/EUR/GBP/... use 2 minor-unit digits (cents);
// this covers every currency this platform currently supports.
const MINOR_UNIT_DIGITS = 2;

export function formatMoney(amountMinorUnits: string | number, currency: CurrencyCode, locale = 'en-US'): string {
  const amount = Number(amountMinorUnits) / 10 ** MINOR_UNIT_DIGITS;
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function toMinorUnits(displayAmount: number): string {
  return String(Math.round(displayAmount * 10 ** MINOR_UNIT_DIGITS));
}
