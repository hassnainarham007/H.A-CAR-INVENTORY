import type { Metadata } from 'next';

export const metadata: Metadata = { title: 'Terms of Service', robots: { index: true, follow: true } };

// TEMPLATE — placeholder legal text, not lawyer-reviewed. Same caveat as
// privacy/page.tsx: get real legal review before this governs real
// transactions between real buyers and sellers.
export default function TermsPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 text-sm leading-relaxed text-charcoal-300 sm:px-6">
      <h1 className="font-display mb-2 text-3xl font-bold text-white">Terms of Service</h1>
      <p className="mb-8 text-xs text-charcoal-500">
        Last updated: placeholder — this page is a template and has not been reviewed by a lawyer. Do not treat it as your real terms.
      </p>

      <h2 className="mt-8 mb-2 text-lg font-semibold text-white">The marketplace role</h2>
      <p>H.A Car Inventory connects buyers with independent sellers and dealers. We do not own, inspect, or guarantee any vehicle listed by a third party unless explicitly marked as our own inventory.</p>

      <h2 className="mt-8 mb-2 text-lg font-semibold text-white">Listings</h2>
      <p>Sellers are responsible for the accuracy of their listings, including price, condition, and vehicle history. Verified badges reflect our review process at the time of verification, not an ongoing guarantee.</p>

      <h2 className="mt-8 mb-2 text-lg font-semibold text-white">Prohibited conduct</h2>
      <p>Fraudulent listings, misrepresenting vehicle condition or ownership, and harassment of other users are grounds for account suspension.</p>

      <h2 className="mt-8 mb-2 text-lg font-semibold text-white">Contact</h2>
      <p>Questions about these terms: <a href="mailto:hassnainarham007@gmail.com" className="text-brass-400 hover:underline">hassnainarham007@gmail.com</a></p>
    </div>
  );
}
