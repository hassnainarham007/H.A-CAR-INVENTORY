import type { MetadataRoute } from 'next';

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://hacarinventory.com';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      { userAgent: '*', allow: '/', disallow: ['/account', '/seller', '/admin', '/api'] },
    ],
    sitemap: `${SITE_URL}/sitemap.xml`,
  };
}
