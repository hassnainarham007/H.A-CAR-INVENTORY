import type { Metadata } from 'next';
import { SellCarWizard } from '@/components/forms/SellCarWizard';

export const metadata: Metadata = { title: 'Sell Your Car', description: 'List your vehicle on H.A Car Inventory in minutes and reach buyers worldwide.' };

export default function SellPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <h1 className="font-display mb-2 text-2xl font-bold text-white">Sell Your Car</h1>
      <p className="mb-8 text-sm text-charcoal-400">List your vehicle in a few guided steps. It stays a draft until you publish.</p>
      <SellCarWizard />
    </div>
  );
}
