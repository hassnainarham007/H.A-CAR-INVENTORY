'use client';

import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import Link from 'next/link';

export default function AccountPage() {
  const { user, loading, logout } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.push('/login');
  }, [loading, user, router]);

  if (loading || !user) {
    return <div className="mx-auto max-w-3xl px-4 py-12 text-sm text-charcoal-400">Loading your account…</div>;
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <h1 className="font-display mb-6 text-2xl font-bold text-white">My Account</h1>

      <Card className="mb-6 p-6">
        <p className="text-sm text-charcoal-400">Signed in as</p>
        <p className="text-lg font-semibold text-white">{user.profile?.displayName || user.email}</p>
        <p className="text-sm text-charcoal-400">{user.email}</p>
      </Card>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Link href="/favorites"><Card className="p-5 hover:border-charcoal-600"><p className="font-semibold text-white">Saved Vehicles</p><p className="text-sm text-charcoal-400">Vehicles you&apos;ve favorited</p></Card></Link>
        <Link href="/compare"><Card className="p-5 hover:border-charcoal-600"><p className="font-semibold text-white">Compare List</p><p className="text-sm text-charcoal-400">Vehicles you&apos;re comparing</p></Card></Link>
        {(user.accountType === 'SELLER' || user.accountType === 'DEALER' || user.accountType === 'DEALER_EMPLOYEE') && (
          <Link href="/seller/dashboard"><Card className="p-5 hover:border-charcoal-600"><p className="font-semibold text-white">Seller Dashboard</p><p className="text-sm text-charcoal-400">Manage your listings</p></Card></Link>
        )}
      </div>

      <Button variant="outline" className="mt-8" onClick={() => logout().then(() => router.push('/'))}>
        Log out
      </Button>
    </div>
  );
}
