import type { Metadata } from 'next';
import { CompareTable } from '@/components/vehicles/CompareTable';

export const metadata: Metadata = { title: 'Compare Vehicles', description: 'Compare price, specs, and features side by side across multiple vehicles.' };

export default function ComparePage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="font-display mb-2 text-2xl font-bold text-white">Compare Vehicles</h1>
      <p className="mb-6 text-sm text-charcoal-400">Add vehicles from any listing page to compare them here, side by side.</p>
      <CompareTable />
    </div>
  );
}
