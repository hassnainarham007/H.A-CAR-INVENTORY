import type { Metadata } from 'next';
import Link from 'next/link';
import { getDealersSafe } from '@/lib/api/getDealersSafe';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { EmptyState } from '@/components/ui/EmptyState';

export const metadata: Metadata = {
  title: 'Verified Dealers',
  description: 'Browse verified vehicle dealerships on H.A Car Inventory.',
};

export default async function DealersPage() {
  const dealers = await getDealersSafe();

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
      <h1 className="font-display mb-2 text-2xl font-bold text-white">Verified Dealers</h1>
      <p className="mb-8 text-sm text-charcoal-400">Every dealer listed here has passed H.A Car Inventory&apos;s verification process.</p>

      {dealers.length === 0 ? (
        <EmptyState title="No verified dealers yet" description="Check back soon — dealer onboarding is in progress." />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {dealers.map((d) => (
            <Link key={d.id} href={`/dealer/${d.id}`}>
              <Card className="p-5 transition-colors hover:border-charcoal-600">
                <div className="mb-2 flex items-center justify-between">
                  <h2 className="font-semibold text-white">{d.legalName}</h2>
                  <Badge tone="verified">✓ Verified</Badge>
                </div>
                <p className="text-sm text-charcoal-400">
                  {d.activeListingCount} active listing{d.activeListingCount === 1 ? '' : 's'}
                  {Number(d.ratingAvg) > 0 && <> · {Number(d.ratingAvg).toFixed(1)}★ ({d.ratingCount})</>}
                </p>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
