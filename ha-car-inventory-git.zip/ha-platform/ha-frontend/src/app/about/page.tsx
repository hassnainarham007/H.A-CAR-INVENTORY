import type { Metadata } from 'next';

export const metadata: Metadata = { title: 'About Us', description: 'Learn about H.A Car Inventory, a global automotive marketplace based in Phalia, Punjab, Pakistan.' };

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-display mb-4 text-3xl font-bold text-white">About H.A Car Inventory</h1>
      <p className="mb-4 text-charcoal-300">
        H.A Car Inventory is a global automotive marketplace connecting buyers with verified vehicle sellers and
        dealerships, founded by Hassnain Arham and based in Phalia, Punjab, Pakistan.
      </p>
      <p className="text-charcoal-300">
        Our mission is to make buying and selling vehicles — across borders and currencies — as transparent and
        trustworthy as buying from a neighbor.
      </p>
    </div>
  );
}
