import Image from 'next/image';
import Link from 'next/link';
import { ShieldCheck, Globe2, Users } from 'lucide-react';
import { HeroSearch } from '@/components/home/HeroSearch';
import { VehicleCard } from '@/components/vehicles/VehicleCard';
import { getVehiclesSafe } from '@/lib/api/getVehiclesSafe';

export default async function HomePage() {
  const { data: featured } = await getVehiclesSafe({ limit: 6, sortBy: 'publishedAt', order: 'desc' });

  return (
    <>
      {/* ---- Hero ---- */}
      <section className="relative flex min-h-[34rem] items-center justify-center overflow-hidden border-b border-charcoal-800">
        <Image
          src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=1920"
          alt=""
          fill
          priority
          className="object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal-950 via-charcoal-950/70 to-charcoal-950/30" />

        <div className="relative z-10 flex flex-col items-center gap-6 px-4 py-20 text-center">
          <h1 className="font-display max-w-3xl text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl">
            Find Your Next Car <span className="text-brass-400">With Confidence.</span>
          </h1>
          <p className="max-w-xl text-base text-charcoal-300 sm:text-lg">
            Explore verified vehicles from trusted sellers and automotive businesses around the world.
          </p>
          <HeroSearch />
        </div>
      </section>

      {/* ---- Trust strip ---- */}
      <section className="border-b border-charcoal-800 bg-charcoal-900">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-6 px-4 py-8 sm:grid-cols-3 sm:px-6 lg:px-8">
          <TrustItem icon={<ShieldCheck className="h-5 w-5" />} title="Verified Listings" description="VIN-checked and seller-verified vehicles you can trust." />
          <TrustItem icon={<Globe2 className="h-5 w-5" />} title="Global Marketplace" description="Buy and sell across Pakistan, the US, UAE, Europe, and beyond." />
          <TrustItem icon={<Users className="h-5 w-5" />} title="Trusted Sellers" description="Private sellers and dealerships, all held to the same standard." />
        </div>
      </section>

      {/* ---- Featured inventory ---- */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h2 className="font-display text-2xl font-bold text-white">Featured Vehicles</h2>
            <p className="mt-1 text-sm text-charcoal-400">Newly listed and recently verified.</p>
          </div>
          <Link href="/cars" className="text-sm font-medium text-brass-400 hover:text-brass-300">
            View all inventory →
          </Link>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((vehicle) => (
            <VehicleCard key={vehicle.id} vehicle={vehicle} />
          ))}
        </div>
      </section>

      {/* ---- Body-type shortcuts (SEO landing pages) ---- */}
      <section className="border-t border-charcoal-800 bg-charcoal-900">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
          <h2 className="font-display mb-6 text-2xl font-bold text-white">Shop by Body Type</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-6">
            {['SUV', 'Sedan', 'Coupe', 'Pickup Truck', 'Electric', 'Luxury'].map((type) => (
              <Link
                key={type}
                href={`/cars?bodyType=${encodeURIComponent(type)}`}
                className="flex items-center justify-center rounded-lg border border-charcoal-700 bg-charcoal-800 px-4 py-6 text-center text-sm font-medium text-charcoal-200 transition-colors hover:border-brass-500 hover:text-brass-400"
              >
                {type}
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

function TrustItem({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-brass-500/15 text-brass-400">{icon}</span>
      <div>
        <p className="text-sm font-semibold text-white">{title}</p>
        <p className="text-xs text-charcoal-400">{description}</p>
      </div>
    </div>
  );
}
