import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { FavoritesProvider } from '@/context/FavoritesContext';
import { CompareProvider } from '@/context/CompareContext';
import { AuthProvider } from '@/context/AuthContext';
import { AiAssistantWidget } from '@/components/ai/AiAssistantWidget';

const inter = Inter({ subsets: ['latin'], variable: '--font-sans', display: 'swap' });

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://hacarinventory.com';
const SITE_NAME = process.env.NEXT_PUBLIC_SITE_NAME ?? 'H.A Car Inventory';

// Title template applies to every page unless a page sets its own `title`
// (see app/cars/page.tsx for an example) — one of the core technical-SEO
// requirements from the brief.
export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: `${SITE_NAME} — Find Your Next Car With Confidence`, template: `%s | ${SITE_NAME}` },
  description:
    'Explore verified vehicles from trusted sellers and automotive businesses around the world. Browse, compare, and buy with confidence on H.A Car Inventory.',
  openGraph: {
    type: 'website',
    siteName: SITE_NAME,
    url: SITE_URL,
    title: `${SITE_NAME} — Find Your Next Car With Confidence`,
    description: 'A global automotive marketplace for verified vehicles, trusted sellers, and dealerships worldwide.',
  },
  twitter: {
    card: 'summary_large_image',
    title: `${SITE_NAME} — Find Your Next Car With Confidence`,
    description: 'A global automotive marketplace for verified vehicles, trusted sellers, and dealerships worldwide.',
  },
  robots: { index: true, follow: true },
};

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: SITE_NAME,
  url: SITE_URL,
  email: 'hassnainarham007@gmail.com',
  address: { '@type': 'PostalAddress', addressLocality: 'Phalia', addressRegion: 'Punjab', addressCountry: 'PK' },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className={inter.variable}>
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd) }}
        />
        <AuthProvider>
          <FavoritesProvider>
            <CompareProvider>
              <div className="flex min-h-screen flex-col">
                <Header />
                <main className="flex-1">{children}</main>
                <Footer />
              </div>
              <AiAssistantWidget />
            </CompareProvider>
          </FavoritesProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
