import type { Metadata } from 'next';
import { FinancingCalculator } from '@/components/financing/FinancingCalculator';

export const metadata: Metadata = { title: 'Financing Calculator', description: 'Estimate your monthly car payment based on price, down payment, trade-in, and loan terms.' };

export default function FinancingPage({ searchParams }: { searchParams: Record<string, string | undefined> }) {
  const initialPrice = searchParams.price ? Math.round(Number(searchParams.price) / 100) : 30000;

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="font-display mb-2 text-2xl font-bold text-white">Financing Calculator</h1>
      <p className="mb-6 text-sm text-charcoal-400">Estimate your monthly payment before you contact a seller.</p>
      <FinancingCalculator initialPrice={initialPrice} />
    </div>
  );
}
