'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import { ApiClientError } from '@/lib/api/client';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

export default function LoginPage() {
  const { login } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(email, password);
      router.push('/account');
    } catch (err) {
      // Deliberately generic — mirrors the backend's own enumeration-resistant
      // error message (AuthService.login), so the UI never leaks which field was wrong.
      setError(err instanceof ApiClientError ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-4 py-12">
      <h1 className="font-display mb-1 text-2xl font-bold text-white">Log in</h1>
      <p className="mb-6 text-sm text-charcoal-400">Welcome back to H.A Car Inventory.</p>

      <Card className="p-6">
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <Input label="Email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input label="Password" type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />

          {error && <p role="alert" className="text-sm text-red-400">{error}</p>}

          {/* "Forgot password?" intentionally omitted: the backend has
              password_resets and email_verifications tables (migration 002)
              but no AuthService methods or endpoints implemented yet for
              either flow. A link to a page with no working backend behind
              it is worse than no link — see BACKEND_README.md "Deliberately
              scaffolded" list. Build this once POST /auth/forgot-password
              and /auth/reset-password exist. */}

          <Button type="submit" isLoading={loading} className="mt-2">Log in</Button>
        </form>
      </Card>

      <p className="mt-6 text-center text-sm text-charcoal-400">
        Don&apos;t have an account?{' '}
        <Link href="/register" className="font-medium text-brass-400 hover:text-brass-300">Create one</Link>
      </p>
    </div>
  );
}
