'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import { ApiClientError } from '@/lib/api/client';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

// Mirrors the backend's password policy exactly (RegisterDto): 8+ chars,
// upper + lower + digit. Client-side validation is a UX convenience only —
// the backend re-validates independently and is the real source of truth.
function validatePassword(password: string): string | null {
  if (password.length < 8) return 'Password must be at least 8 characters.';
  if (!/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/\d/.test(password)) {
    return 'Password must contain an uppercase letter, a lowercase letter, and a number.';
  }
  return null;
}

export default function RegisterPage() {
  const { register } = useAuth();
  const router = useRouter();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const passwordError = validatePassword(password);
    if (passwordError) {
      setError(passwordError);
      return;
    }
    setError(null);
    setLoading(true);
    try {
      await register(email, password, firstName, lastName);
      router.push('/account');
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-4 py-12">
      <h1 className="font-display mb-1 text-2xl font-bold text-white">Create your account</h1>
      <p className="mb-6 text-sm text-charcoal-400">Join H.A Car Inventory to save vehicles, message sellers, and more.</p>

      <Card className="p-6">
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-3">
            <Input label="First name" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
            <Input label="Last name" value={lastName} onChange={(e) => setLastName(e.target.value)} />
          </div>
          <Input label="Email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input
            label="Password"
            type="password"
            required
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <p className="-mt-2 text-xs text-charcoal-500">At least 8 characters, with an uppercase letter, a lowercase letter, and a number.</p>

          {error && <p role="alert" className="text-sm text-red-400">{error}</p>}

          <Button type="submit" isLoading={loading} className="mt-2">Create account</Button>

          <p className="text-center text-xs text-charcoal-500">
            By creating an account you agree to our{' '}
            <Link href="/terms" className="underline hover:text-charcoal-300">Terms</Link> and{' '}
            <Link href="/privacy" className="underline hover:text-charcoal-300">Privacy Policy</Link>.
          </p>
        </form>
      </Card>

      <p className="mt-6 text-center text-sm text-charcoal-400">
        Already have an account?{' '}
        <Link href="/login" className="font-medium text-brass-400 hover:text-brass-300">Log in</Link>
      </p>
    </div>
  );
}
