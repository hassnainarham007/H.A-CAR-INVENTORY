import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { getVehicleByIdSafe, getVehiclesSafe } from '@/lib/api/getVehiclesSafe';
import { vehiclesApi } from '@/lib/api/vehicles';
import { VehicleGallery } from '@/components/vehicles/VehicleGallery';
import { VehicleSpecs } from '@/components/vehicles/VehicleSpecs';
import { StickyContactPanel } from '@/components/vehicles/StickyContactPanel';
import { VehicleCard } from '@/components/vehicles/VehicleCard';
import { Badge } from '@/components/ui/Badge';
import { formatMoney } from '@/lib/utils/money';
import { formatRelativeDate } from '@/lib/utils/format';

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://hacarinventory.com';

// The trailing segment of the slug is always the canonical vehicle ID
// (see lib/utils/format.ts vehicleUrl) — everything before it is SEO text
// only and is never trusted for the lookup.
function idFromSlug(slug: string): string {
  const parts = slug.split('-');
  return parts[parts.length - 1] ?? slug;
}

interface PageProps {
  params: { slug: string };
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const vehicle = await getVehicleByIdSafe(idFromSlug(params.slug));
  if (!vehicle) return {};

  const title = `${vehicle.year} ${vehicle.make.name} ${vehicle.model.name} for Sale`;
  const description = `${vehicle.year} ${vehicle.make.name} ${vehicle.model.name} — ${formatMoney(vehicle.priceAmount, vehicle.priceCurrency)}, ${vehicle.mileage ?? '—'} ${vehicle.mileageUnit}, ${vehicle.condition.name}. Located in ${vehicle.locationLabel}.`;
  const image = vehicle.images[0]?.url;

  return {
    title,
    description,
    alternates: { canonical: `${SITE_URL}/vehicle/${params.slug}` },
    openGraph: { title, description, images: image ? [image] : [], type: 'website' },
    twitter: { card: 'summary_large_image', title, description, images: image ? [image] : [] },
  };
}

export default async function VehicleDetailPage({ params }: PageProps) {
  const id = idFromSlug(params.slug);
  const vehicle = await getVehicleByIdSafe(id);
  if (!vehicle) notFound();

  const similar = await vehiclesApi.similar(id).catch(async () => (await getVehiclesSafe({ limit: 3 })).data);

  const vehicleJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Vehicle',
    name: `${vehicle.year} ${vehicle.make.name} ${vehicle.model.name}`,
    brand: { '@type': 'Brand', name: vehicle.make.name },
    model: vehicle.model.name,
    vehicleModelDate: String(vehicle.year),
    mileageFromOdometer: vehicle.mileage ? { '@type': 'QuantitativeValue', value: vehicle.mileage, unitCode: vehicle.mileageUnit === 'KM' ? 'KMT' : 'SMI' } : undefined,
    fuelType: vehicle.fuelType.name,
    vehicleTransmission: vehicle.transmission.name,
    offers: {
      '@type': 'Offer',
      price: (Number(vehicle.priceAmount) / 100).toFixed(2),
      priceCurrency: vehicle.priceCurrency,
      availability: vehicle.status === 'ACTIVE' ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
    },
  };

  const breadcrumbJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Cars', item: `${SITE_URL}/cars` },
      { '@type': 'ListItem', position: 2, name: vehicle.make.name, item: `${SITE_URL}/cars?make=${vehicle.make.slug}` },
      { '@type': 'ListItem', position: 3, name: `${vehicle.year} ${vehicle.model.name}`, item: `${SITE_URL}/vehicle/${params.slug}` },
    ],
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(vehicleJsonLd) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }} />

      <nav className="mb-4 text-xs text-charcoal-400">
        <Link href="/cars" className="hover:text-white">Cars</Link> ·{' '}
        <Link href={`/cars?make=${vehicle.make.slug}`} className="hover:text-white">{vehicle.make.name}</Link> ·{' '}
        <span className="text-charcoal-300">{vehicle.year} {vehicle.model.name}</span>
      </nav>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="mb-4 flex items-start justify-between gap-4">
            <div>
              <h1 className="font-display text-2xl font-bold text-white sm:text-3xl">
                {vehicle.year} {vehicle.make.name} {vehicle.model.name}
              </h1>
              <p className="mt-1 text-sm text-charcoal-400">{formatRelativeDate(vehicle.publishedAt)} · {vehicle.viewCount} views</p>
            </div>
            {vehicle.verificationStatus === 'VERIFIED' && <Badge tone="verified">✓ Verified</Badge>}
          </div>

          <VehicleGallery images={vehicle.images} title={`${vehicle.year} ${vehicle.make.name} ${vehicle.model.name}`} />

          <Section title="Overview">
            <p className="text-sm leading-relaxed text-charcoal-300">{vehicle.description ?? 'No description provided by the seller.'}</p>
          </Section>

          <Section title="Specifications">
            <VehicleSpecs vehicle={vehicle} />
          </Section>

          <Section title="Vehicle History">
            <p className="text-sm text-charcoal-400">
              {vehicle.verificationStatus === 'VERIFIED'
                ? 'This vehicle has passed H.A Car Inventory verification. Full history report available on request.'
                : 'Vehicle history has not been independently verified yet.'}
            </p>
          </Section>

          <Section title="Inspection">
            <p className="text-sm text-charcoal-400">No inspection report uploaded yet. Buyers can request a third-party inspection before purchase.</p>
          </Section>

          <Section title="Documents">
            <p className="text-sm text-charcoal-400">Registration and title documents are shared directly by the seller after an inquiry is opened.</p>
          </Section>

          <Section title="Shipping & Import">
            <p className="text-sm text-charcoal-400">International shipping and import-duty estimates are calculated per destination — contact the seller for a quote.</p>
          </Section>

          <Section title="Financing">
            <p className="text-sm text-charcoal-400">
              Estimate your monthly payment for this vehicle using our{' '}
              <Link href={`/financing?price=${vehicle.priceAmount}&currency=${vehicle.priceCurrency}`} className="text-brass-400 hover:underline">
                financing calculator
              </Link>.
            </p>
          </Section>
        </div>

        <div>
          <StickyContactPanel vehicle={vehicle} />
        </div>
      </div>

      {similar.length > 0 && (
        <section className="mt-14">
          <h2 className="font-display mb-5 text-xl font-bold text-white">Similar Vehicles</h2>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {similar.map((v) => (
              <VehicleCard key={v.id} vehicle={v} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-8 border-t border-charcoal-800 pt-6">
      <h2 className="mb-3 text-lg font-semibold text-white">{title}</h2>
      {children}
    </div>
  );
}
