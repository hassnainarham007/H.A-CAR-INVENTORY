import type { Metadata } from 'next';
import { Card } from '@/components/ui/Card';

export const metadata: Metadata = { title: 'Contact', description: 'Get in touch with the H.A Car Inventory team.' };

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-12 sm:px-6">
      <h1 className="font-display mb-6 text-3xl font-bold text-white">Contact Us</h1>
      <Card className="p-6">
        <dl className="flex flex-col gap-3 text-sm">
          <div><dt className="text-charcoal-400">Founder</dt><dd className="text-white">Hassnain Arham</dd></div>
          <div><dt className="text-charcoal-400">Location</dt><dd className="text-white">Phalia, Punjab, Pakistan</dd></div>
          <div><dt className="text-charcoal-400">Email</dt><dd><a href="mailto:hassnainarham007@gmail.com" className="text-brass-400 hover:underline">hassnainarham007@gmail.com</a></dd></div>
        </dl>
      </Card>
    </div>
  );
}
