import { Skeleton } from '@/components/ui/Skeleton';

export default function CarsLoading() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <Skeleton className="mb-6 h-8 w-48" />
      <div className="flex flex-col gap-8 lg:flex-row">
        <div className="hidden w-64 flex-shrink-0 flex-col gap-4 lg:flex">
          {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}
        </div>
        <div className="grid flex-1 grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-72 w-full" />)}
        </div>
      </div>
    </div>
  );
}
