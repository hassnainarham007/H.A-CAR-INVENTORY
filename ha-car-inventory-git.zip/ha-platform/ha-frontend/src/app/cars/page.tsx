import type { Metadata } from 'next';
import { VehicleFiltersSidebar } from '@/components/vehicles/VehicleFiltersSidebar';
import { VehicleResults } from '@/components/vehicles/VehicleResults';
import { getVehiclesSafe } from '@/lib/api/getVehiclesSafe';
import type { VehicleFilters } from '@/lib/types/vehicle';
import { MAKE_SLUG_TO_ID, BODY_TYPE_TO_ID, FUEL_TYPE_TO_ID, TRANSMISSION_TO_ID, dollarsToMinorUnits } from '@/lib/utils/taxonomy';

export const metadata: Metadata = {
  title: 'Browse Cars for Sale',
  description: 'Search thousands of verified vehicles from trusted sellers and dealerships worldwide. Filter by make, model, price, year, and more.',
};

const SORT_MAP: Record<string, Pick<VehicleFilters, 'sortBy' | 'order'>> = {
  recommended: { sortBy: 'publishedAt', order: 'desc' },
  newest: { sortBy: 'createdAt', order: 'desc' },
  'price-asc': { sortBy: 'price', order: 'asc' },
  'price-desc': { sortBy: 'price', order: 'desc' },
  mileage: { sortBy: 'mileage', order: 'asc' },
  year: { sortBy: 'year', order: 'desc' },
};

interface CarsPageProps {
  searchParams: Record<string, string | undefined>;
}

export default async function CarsPage({ searchParams }: CarsPageProps) {
  const sort = SORT_MAP[searchParams.sort ?? 'recommended'] ?? SORT_MAP.recommended;

  const { data: vehicles, meta } = await getVehiclesSafe({
    // make/bodyType/fuel/transmission arrive as human-readable strings from
    // HeroSearch and VehicleFiltersSidebar — the API filters on numeric IDs,
    // so these MUST be resolved here (previously they weren't resolved at
    // all, so picking a make or body type silently did nothing).
    makeId: searchParams.make ? MAKE_SLUG_TO_ID[searchParams.make] : undefined,
    bodyTypeId: searchParams.bodyType ? BODY_TYPE_TO_ID[searchParams.bodyType] : undefined,
    fuelTypeId: searchParams.fuel ? FUEL_TYPE_TO_ID[searchParams.fuel] : undefined,
    transmissionId: searchParams.transmission ? TRANSMISSION_TO_ID[searchParams.transmission] : undefined,
    // priceMin/priceMax come from the UI in whole dollars; the API and DB
    // store minor units (cents) — previously passed straight through
    // unconverted, so a "$30,000 max" filter was actually querying for
    // "$300 max" against the backend.
    priceMin: dollarsToMinorUnits(searchParams.priceMin),
    priceMax: dollarsToMinorUnits(searchParams.priceMax),
    yearMin: searchParams.yearMin ? Number(searchParams.yearMin) : undefined,
    yearMax: searchParams.yearMax ? Number(searchParams.yearMax) : undefined,
    mileageMax: searchParams.mileageMax ? Number(searchParams.mileageMax) : undefined,
    verificationStatus: searchParams.verified === 'true' ? 'VERIFIED' : undefined,
    page: searchParams.page ? Number(searchParams.page) : 1,
    limit: 12,
    ...sort,
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="font-display mb-6 text-2xl font-bold text-white">Browse Cars</h1>
      <div className="flex flex-col gap-8 lg:flex-row">
        <VehicleFiltersSidebar />
        <div className="flex-1">
          <VehicleResults vehicles={vehicles} totalItems={meta.totalItems} />
        </div>
      </div>
    </div>
  );
}
