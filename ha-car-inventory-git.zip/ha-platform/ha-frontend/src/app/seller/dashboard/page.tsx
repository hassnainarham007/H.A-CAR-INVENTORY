'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { vehiclesApi } from '@/lib/api/vehicles';
import type { Vehicle } from '@/lib/types/vehicle';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { formatMoney } from '@/lib/utils/money';
import { EmptyState } from '@/components/ui/EmptyState';

const STATUS_TONE: Record<string, 'neutral' | 'verified' | 'warning'> = {
  ACTIVE: 'verified',
  DRAFT: 'neutral',
  PENDING_REVIEW: 'warning',
  ARCHIVED: 'neutral',
  SOLD: 'neutral',
};

// Calls GET /vehicles/mine — a dedicated endpoint that returns every status
// (DRAFT/PENDING_REVIEW/ACTIVE/ARCHIVED/...) for the caller's own seller or
// dealer record. list()/findAll() always filter to ACTIVE-only, which is
// correct for public search but was previously the only option, so a
// seller's own drafts were invisible even to themselves — fixed.
export default function SellerDashboardPage() {
  const { user, accessToken, loading } = useAuth();
  const router = useRouter();
  const [vehicles, setVehicles] = useState<Vehicle[] | null>(null);

  useEffect(() => {
    if (!loading && !user) router.push('/login');
  }, [loading, user, router]);

  useEffect(() => {
    if (!accessToken) return;
    vehiclesApi
      .mine(accessToken)
      .then((res) => setVehicles(res.data))
      .catch(() => setVehicles([]));
  }, [accessToken]);

  if (loading || !user) return <div className="mx-auto max-w-6xl px-4 py-12 text-sm text-charcoal-400">Loading…</div>;

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Seller Dashboard</h1>
          <p className="text-sm text-charcoal-400">Manage your listings, leads, and profile.</p>
        </div>
        <Link href="/sell"><Button>+ Add Vehicle</Button></Link>
      </div>

      <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <StatCard label="Active Listings" value={vehicles?.filter((v) => v.status === 'ACTIVE').length ?? '—'} />
        <StatCard label="Total Views" value={vehicles?.reduce((sum, v) => sum + Number(v.viewCount), 0) ?? '—'} />
        <StatCard label="Leads" value="—" note="Wire up once /leads ships" />
        <StatCard label="Messages" value="—" note="Wire up once messaging ships" />
      </div>

      <h2 className="mb-3 text-lg font-semibold text-white">Your Inventory</h2>
      {vehicles === null && <p className="text-sm text-charcoal-400">Loading inventory…</p>}
      {vehicles !== null && vehicles.length === 0 && (
        <EmptyState title="No listings yet" description="Add your first vehicle to start reaching buyers." action={<Link href="/sell" className="text-sm font-medium text-brass-400">+ Add Vehicle</Link>} />
      )}
      {vehicles && vehicles.length > 0 && (
        <div className="flex flex-col divide-y divide-charcoal-800 overflow-hidden rounded-xl2 border border-charcoal-800">
          {vehicles.map((v) => (
            <div key={v.id} className="flex items-center justify-between gap-4 bg-charcoal-900 p-4">
              <div>
                <p className="font-medium text-white">{v.year} {v.make.name} {v.model.name}</p>
                <p className="text-xs text-charcoal-400">{formatMoney(v.priceAmount, v.priceCurrency)} · {v.viewCount} views</p>
              </div>
              <Badge tone={STATUS_TONE[v.status] ?? 'neutral'}>{v.status.replace('_', ' ')}</Badge>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, note }: { label: string; value: string | number; note?: string }) {
  return (
    <Card className="p-4">
      <p className="text-xs text-charcoal-400">{label}</p>
      <p className="text-2xl font-bold text-white">{value}</p>
      {note && <p className="mt-1 text-[10px] text-charcoal-500">{note}</p>}
    </Card>
  );
}
