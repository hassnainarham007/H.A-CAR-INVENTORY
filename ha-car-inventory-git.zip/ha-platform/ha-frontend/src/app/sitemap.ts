import type { MetadataRoute } from 'next';
import { getVehiclesSafe } from '@/lib/api/getVehiclesSafe';
import { vehicleUrl } from '@/lib/utils/format';

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://hacarinventory.com';

const STATIC_ROUTES = ['', '/cars', '/sell', '/financing', '/compare', '/dealers', '/about', '/contact', '/guides', '/privacy', '/terms'];

// Dynamic sitemap: static marketing/utility pages + every ACTIVE vehicle
// listing, fetched fresh at build/revalidation time. Next.js serves this at
// /sitemap.xml automatically — no manual XML to maintain.
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const staticEntries: MetadataRoute.Sitemap = STATIC_ROUTES.map((path) => ({
    url: `${SITE_URL}${path}`,
    lastModified: new Date(),
    changeFrequency: path === '' || path === '/cars' ? 'hourly' : 'weekly',
    priority: path === '' ? 1 : 0.7,
  }));

  let vehicleEntries: MetadataRoute.Sitemap = [];
  try {
    const { data: vehicles } = await getVehiclesSafe({ limit: 100, sortBy: 'publishedAt', order: 'desc' });
    vehicleEntries = vehicles.map((v) => ({
      url: `${SITE_URL}${vehicleUrl(v.make.name, v.model.name, v.year, v.id)}`,
      lastModified: new Date(v.updatedAt),
      changeFrequency: 'daily',
      priority: 0.8,
    }));
  } catch {
    // Sitemap generation should never hard-fail the build if the backend is
    // briefly unreachable — ship the static routes rather than nothing.
  }

  return [...staticEntries, ...vehicleEntries];
}
