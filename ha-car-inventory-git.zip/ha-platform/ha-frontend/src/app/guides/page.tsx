import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Car Buying & Selling Guides',
  description: 'Guides for buying and selling vehicles on H.A Car Inventory.',
};

// Honest placeholder, not a fake list of fake articles with fake dates —
// an empty state that says exactly what it is, matching the rest of this
// project's pattern for unbuilt-but-linked features.
export default function GuidesPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 text-center sm:px-6">
      <h1 className="font-display mb-3 text-2xl font-bold text-white">Guides</h1>
      <p className="text-sm text-charcoal-400">
        Car buying and selling guides are coming soon. In the meantime, the{' '}
        <a href="/financing" className="text-brass-400 hover:underline">financing calculator</a> and{' '}
        <a href="/cars" className="text-brass-400 hover:underline">browse page</a> are both fully working.
      </p>
    </div>
  );
}
