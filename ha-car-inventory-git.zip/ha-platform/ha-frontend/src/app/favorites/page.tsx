'use client';

import { useEffect, useState } from 'react';
import { useFavorites } from '@/context/FavoritesContext';
import { getVehicleByIdSafe } from '@/lib/api/getVehiclesSafe';
import type { Vehicle } from '@/lib/types/vehicle';
import { VehicleCard } from '@/components/vehicles/VehicleCard';
import { EmptyState } from '@/components/ui/EmptyState';
import { Skeleton } from '@/components/ui/Skeleton';
import Link from 'next/link';

export default function FavoritesPage() {
  const { favoriteIds, isFavorited, toggleFavorite } = useFavorites();
  const [vehicles, setVehicles] = useState<Vehicle[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([...favoriteIds].map((id) => getVehicleByIdSafe(id))).then((results) => {
      if (!cancelled) setVehicles(results.filter((v): v is Vehicle => v !== null));
    });
    return () => {
      cancelled = true;
    };
  }, [favoriteIds]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="font-display mb-6 text-2xl font-bold text-white">Saved Vehicles</h1>

      {vehicles === null && (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-72 w-full" />)}
        </div>
      )}

      {vehicles !== null && vehicles.length === 0 && (
        <EmptyState
          title="No saved vehicles yet"
          description="Tap the heart icon on any listing to save it here for later."
          action={<Link href="/cars" className="text-sm font-medium text-brass-400 hover:text-brass-300">Browse Cars →</Link>}
        />
      )}

      {vehicles !== null && vehicles.length > 0 && (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {vehicles.map((v) => (
            <VehicleCard key={v.id} vehicle={v} isFavorited={isFavorited(v.id)} onToggleFavorite={toggleFavorite} />
          ))}
        </div>
      )}
    </div>
  );
}
