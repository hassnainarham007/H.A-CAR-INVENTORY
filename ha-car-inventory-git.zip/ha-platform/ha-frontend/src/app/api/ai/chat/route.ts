import { NextRequest, NextResponse } from 'next/server';

// Server-side proxy to the backend's AI module (POST /api/v1/ai/chat, spec'd
// in the backend brief but not yet implemented there — see
// docs/BACKEND_README.md "AI Assistant" section for what it needs).
//
// This route exists as a stable frontend contract: the widget always calls
// THIS route, never the backend directly, so swapping providers or adding
// auth/rate-limiting later never touches client code. Right now it returns
// an honest "not connected yet" response — per the brief's explicit
// instruction not to fake real AI answers, this NEVER invents inventory,
// prices, or specs.
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  if (!body?.message || typeof body.message !== 'string') {
    return NextResponse.json({ error: 'A "message" string is required.' }, { status: 400 });
  }

  const backendUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  if (backendUrl) {
    try {
      const res = await fetch(`${backendUrl}/ai/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        const data = await res.json();
        return NextResponse.json(data);
      }
    } catch {
      // Backend AI endpoint not reachable/not built yet — fall through to the honest placeholder below.
    }
  }

  return NextResponse.json({
    reply:
      "H.A Auto Assistant isn't connected to live inventory search yet — this is a UI preview. " +
      'Once the backend AI module ships, this same message box will answer using real, current inventory.',
    connected: false,
  });
}
