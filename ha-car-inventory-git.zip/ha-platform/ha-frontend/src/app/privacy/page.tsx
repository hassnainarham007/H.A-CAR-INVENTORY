import type { Metadata } from 'next';

export const metadata: Metadata = { title: 'Privacy Policy', robots: { index: true, follow: true } };

// TEMPLATE — this is placeholder legal text, not a lawyer-reviewed policy.
// Ship this to production only after a lawyer reviews it against your
// actual data practices (what you collect, which processors you use —
// Stripe, your email provider, etc. — and your jurisdiction's requirements,
// e.g. Pakistan's PECA/data rules and GDPR if you serve EU users).
export default function PrivacyPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 text-sm leading-relaxed text-charcoal-300 sm:px-6">
      <h1 className="font-display mb-2 text-3xl font-bold text-white">Privacy Policy</h1>
      <p className="mb-8 text-xs text-charcoal-500">
        Last updated: placeholder — this page is a template and has not been reviewed by a lawyer. Do not treat it as your real policy.
      </p>

      <h2 className="mt-8 mb-2 text-lg font-semibold text-white">Information we collect</h2>
      <p>Account details you provide (name, email, phone), listing details you submit, and usage data such as pages viewed and searches performed.</p>

      <h2 className="mt-8 mb-2 text-lg font-semibold text-white">How we use it</h2>
      <p>To operate the marketplace: showing your listings to buyers, connecting buyers and sellers, and improving search relevance.</p>

      <h2 className="mt-8 mb-2 text-lg font-semibold text-white">Third parties</h2>
      <p>We use payment processors and hosting providers to run the service. We do not sell personal data to advertisers.</p>

      <h2 className="mt-8 mb-2 text-lg font-semibold text-white">Contact</h2>
      <p>Questions about this policy: <a href="mailto:hassnainarham007@gmail.com" className="text-brass-400 hover:underline">hassnainarham007@gmail.com</a></p>
    </div>
  );
}
