import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getDealerByIdSafe } from '@/lib/api/getDealersSafe';
import { VehicleCard } from '@/components/vehicles/VehicleCard';
import { Badge } from '@/components/ui/Badge';
import { EmptyState } from '@/components/ui/EmptyState';

interface PageProps { params: { id: string } }

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const dealer = await getDealerByIdSafe(params.id);
  if (!dealer) return {};
  return { title: dealer.legalName, description: `${dealer.legalName} — verified dealer on H.A Car Inventory.` };
}

export default async function DealerProfilePage({ params }: PageProps) {
  const dealer = await getDealerByIdSafe(params.id);
  if (!dealer) notFound();

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="mb-8 flex items-center gap-3">
        <h1 className="font-display text-2xl font-bold text-white">{dealer.legalName}</h1>
        <Badge tone="verified">✓ Verified Dealer</Badge>
      </div>
      <p className="mb-8 text-sm text-charcoal-400">
        {dealer.activeListingCount} active listing{dealer.activeListingCount === 1 ? '' : 's'}
        {Number(dealer.ratingAvg) > 0 && <> · {Number(dealer.ratingAvg).toFixed(1)}★ ({dealer.ratingCount} reviews)</>}
      </p>

      <h2 className="mb-4 text-lg font-semibold text-white">Inventory</h2>
      {dealer.vehicles.length === 0 ? (
        <EmptyState title="No active listings right now" description="This dealer doesn't have any published vehicles at the moment." />
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {dealer.vehicles.map((v) => <VehicleCard key={v.id} vehicle={v} />)}
        </div>
      )}
    </div>
  );
}
