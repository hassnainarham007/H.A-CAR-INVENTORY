import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center px-4 text-center">
      <h1 className="font-display text-3xl font-bold text-white">404</h1>
      <p className="mt-2 text-sm text-charcoal-400">We couldn&apos;t find that page — it may have been sold or removed.</p>
      <Link href="/cars" className="mt-6 text-sm font-medium text-brass-400 hover:text-brass-300">Browse Inventory →</Link>
    </div>
  );
}
