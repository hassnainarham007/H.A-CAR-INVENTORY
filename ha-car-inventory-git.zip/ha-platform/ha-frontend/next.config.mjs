/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  output: 'standalone', // keeps the production Docker image small
  images: {
    // Add your real CDN/S3 host here once object storage is live —
    // matches the S3-compatible storage the backend's upload module targets.
    remotePatterns: [
      { protocol: 'https', hostname: 'images.unsplash.com' },
      { protocol: 'https', hostname: '*.amazonaws.com' },
    ],
    formats: ['image/avif', 'image/webp'],
  },
  eslint: { ignoreDuringBuilds: false },
};

export default nextConfig;
