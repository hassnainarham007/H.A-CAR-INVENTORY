# H.A Car Inventory — Frontend

**Stack:** Next.js 14 (App Router) + React + TypeScript + Tailwind CSS.
**Talks to:** the NestJS backend built earlier for this project (`ha-backend`), via a typed API service layer.

---

## 1. What's actually implemented vs. scaffolded

The brief specified ~25 pages and 26 feature sections. As with the backend
delivery, this is honest about what's real vs. what's a documented next
step — building all 25 pages as hollow shells would violate the brief's own
"do not create a superficial demo" instruction.

**Fully implemented, real functionality:**
- Design system: original brand palette (charcoal + brass, not generic
  blue-SaaS), dark theme, `Button`/`Badge`/`Card`/`Input`/`Select`/
  `Skeleton`/`EmptyState` primitives, responsive header/footer.
- **Homepage** — hero with functional search (routes to `/cars` with query
  params), trust strip, featured inventory, body-type shortcuts.
- **`/cars`** — URL-driven filters (make, body type, fuel, transmission,
  price/year/mileage range, verified-only), sort, grid/list toggle,
  pagination via the real `vehiclesApi.list()`, loading skeleton, empty state.
- **`/vehicle/[slug]`** — image gallery, full spec table, sticky contact
  panel (call/email/WhatsApp/test-drive/save/share/report), similar
  vehicles, and **real SEO**: per-page metadata, canonical URL, Open Graph/
  Twitter cards, `Vehicle` + `BreadcrumbList` JSON-LD structured data.
- **`/compare`** — add up to 4 vehicles from any listing card, full
  comparison table, localStorage-backed.
- **`/favorites`** — save/unsave from any card, localStorage-backed with
  the exact API swap-in point documented for when accounts are live.
- **`/financing`** — real amortization math (not a static mockup), clear
  "estimate only" disclaimer, pre-fills from a vehicle's price via query param.
- **AI Assistant widget** — floating chat UI with suggested prompts,
  message history, calls a real `/api/ai/chat` route. That route proxies to
  the backend's (not-yet-built) AI module and — per the brief's explicit
  instruction not to fake AI answers — returns an honest "not connected
  yet" message instead of a scripted fake response.
- **Auth** — `/login` and `/register`, both wired to the real backend
  `/auth/*` endpoints (same password policy, same error messages, same
  account-lockout behavior as the backend already enforces).
- **`/account`** — minimal protected page (redirects to `/login` if signed out).
- **`/seller/dashboard`** — real inventory list, pulled from the actual
  `vehiclesApi.list()` call, with a stat strip flagging which numbers
  (leads, messages) need backend endpoints that don't exist yet.
- **`/sell`** — a 10-step wizard UI matching the brief's flow. Steps 1-3,
  6, 7, 9, 10 (vehicle info, specs, condition, pricing, seller info,
  preview, publish) **actually call `POST /vehicles` and publish the
  listing**. Steps 4/5/8 (photos, documents, verification) are shown as
  clearly-labeled "not connected yet" placeholders — see §3.
- SEO infrastructure: dynamic `sitemap.xml` (static routes + every active
  vehicle), `robots.txt`, title templates, Organization JSON-LD sitewide.
- Loading state (`/cars/loading.tsx`) and a styled 404 page.

**Deliberately scaffolded as a clear next step, not faked:**
Dealer profile pages, seller "Add Vehicle" beyond what `/sell` covers,
messaging UI, admin dashboard, blog/guides content pages, "cars by
make/model/body-type/country/city" SEO landing pages, account sub-pages
(saved searches, recently viewed, notifications), localization beyond the
default English/USD, cookie consent UI, and the drag-and-drop image
uploader (blocked on the backend's S3 upload module — see
`BACKEND_README.md`).

---

## 2. Running it locally

```bash
cp .env.example .env.local
npm install
npm run dev
# http://localhost:3000
```

By default, pages try the real backend (`NEXT_PUBLIC_API_BASE_URL`, see
`ha-backend`'s `docker compose up`). If it's unreachable, listing and detail
pages **fall back to realistic sample data** (`src/data/sample-vehicles.ts`)
so the frontend is fully explorable on its own — this fallback lives only in
`lib/api/getVehiclesSafe.ts` and should be deleted once the backend is
deployed everywhere, not relied on in production.

```bash
npm run typecheck   # tsc --noEmit
npm run build        # production build (standalone output, see Dockerfile)
```

---

## 3. Known gaps worth your attention

| Gap | Why it's flagged, not silently patched |
|---|---|
| Image upload (Sell flow steps 4-5) | Needs the backend's S3-compatible upload module, which isn't built. A fake "drag and drop" that uploads nowhere would be worse than an honest placeholder. |
| Seller dashboard "Leads"/"Messages" counts | Backend has no `/leads` or messaging endpoints yet — shown as `—` rather than a fabricated number. |
| `vehiclesApi.list()` for a logged-in seller | `VehiclesService.findAll` (backend) currently only returns `ACTIVE` vehicles publicly, even for the owner. The seller dashboard needs it to also return the caller's own `DRAFT`/`PENDING_REVIEW` listings — flagged in `BACKEND_README.md`'s open-flag list, not silently assumed. |
| Auth token storage | `AuthContext` stores JWTs in `localStorage` for simplicity — vulnerable to XSS token theft. Production hardening: move to httpOnly cookies set by a Route Handler proxy. Flagged directly in the code comment, not hidden. |
| Model dropdown in `/sell` | Hardcoded to one sample model per make — needs a real `GET /vehicle-models?makeId=` endpoint (trivial addition to the backend's taxonomy tables, not yet exposed as an endpoint). |
| Currency/locale switching | Types and `formatMoney()` support all 8 currencies from the schema; there's no UI switcher yet. Straightforward to add — a `Select` in the header writing to a context, same pattern as `FavoritesContext`. |

---

## 4. Folder structure

```
src/
  app/                 Next.js App Router pages (one folder per route)
  components/
    ui/                Design-system primitives (Button, Card, Input...)
    layout/             Header, Footer
    home/                Hero search
    vehicles/           Card, filters, gallery, specs, compare table...
    forms/              SellCarWizard
    ai/                 AI Assistant widget
  context/              FavoritesContext, CompareContext, AuthContext
  lib/
    api/                Typed fetch client + per-resource service modules
    types/              TypeScript types matching the backend contract
    utils/              money (never floats), formatting, slugs, cn()
  data/                 Realistic sample inventory for dev/offline use
```

Adding a new page that needs backend data follows the same 3-step pattern
every existing page uses: (1) add/extend a `lib/api/*.ts` service function,
(2) add any new types to `lib/types/`, (3) build the page as a server
component calling that function (see `app/cars/page.tsx`) or a client
component using the matching context (see `app/favorites/page.tsx`).
